-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_entity_instance_198`
--

LOCK TABLES `cxm_entity_instance_198` WRITE;
/*!40000 ALTER TABLE `cxm_entity_instance_198` DISABLE KEYS */;
INSERT INTO `cxm_entity_instance_198` VALUES (1,1,1,'Account',1,'SuperAdmin','public',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'testing',NULL,NULL,'SuperAdmin','2015-04-11 11:32:56','SuperAdmin','2015-04-06 12:17:59','SuperAdmin','2015-04-06 12:17:59',NULL),(2,1,1,'Contact',2,'awebb','public',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_',NULL,NULL,NULL,NULL,'awebb','2015-04-06 12:48:01','awebb','2015-04-06 12:48:01',NULL),(3,1,1,'Sales',2,'awebb','public',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_',NULL,NULL,NULL,NULL,'awebb','2015-04-06 12:55:41','awebb','2015-04-06 12:55:41',NULL),(4,1,1,'Sales',3,'awebb','public',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_Test_test_',NULL,NULL,NULL,NULL,'awebb','2015-04-06 13:17:03','awebb','2015-04-06 13:17:03',NULL),(6,1,1,'Account',1,'SuperAdmin','public',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'THis is test note to confirm data changes.',NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-11 12:43:00','SuperAdmin','2015-04-11 12:43:00',NULL),(7,1,1,'Contact',3,'SuperAdmin','public',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Test Note',NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-11 22:56:03','SuperAdmin','2015-04-11 22:56:03',NULL),(8,1,1,'Leads',3,'SuperAdmin','public',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Test  Leads Notes',NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-11 23:13:11','SuperAdmin','2015-04-11 23:13:11',NULL),(9,1,1,'Account',2,'SuperAdmin','public',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Note',NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-13 13:27:23','SuperAdmin','2015-04-13 13:27:23',NULL),(10,1,1,'Account',3,'SuperAdmin','public',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'test\r\ntest\r\ntest\r\ntest',NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-15 14:49:08','SuperAdmin','2015-04-15 14:49:08',NULL),(11,1,1,'Account',6,'SuperAdmin','public',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'test',NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-15 14:51:35','SuperAdmin','2015-04-15 14:51:35',NULL),(12,1,1,'Account',4,'SuperAdmin','public',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'test',NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-15 14:54:54','SuperAdmin','2015-04-15 14:54:54',NULL),(13,1,1,'Contact',1,'SuperAdmin','public',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'testsetestset',NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-15 16:01:59','SuperAdmin','2015-04-15 16:01:59',NULL),(14,1,1,'Contact',4,'SuperAdmin','public',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'testestest',NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-16 11:48:13','SuperAdmin','2015-04-16 11:48:13',NULL),(15,1,1,'Leads',2,'SuperAdmin','public',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'testestest',NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-16 12:21:27','SuperAdmin','2015-04-16 12:21:27',NULL),(16,1,1,'Account',7,'SuperAdmin','public',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'working',NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-18 21:38:57','SuperAdmin','2015-04-18 21:38:57',NULL),(17,1,1,'Contact',5,'SuperAdmin','public',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'testing123123',NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-18 21:40:49','SuperAdmin','2015-04-18 21:40:49',NULL),(18,1,1,'Leads',3,'SuperAdmin','public',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Test Leads Notes Again',NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-20 19:04:45','SuperAdmin','2015-04-20 19:04:45',NULL);
/*!40000 ALTER TABLE `cxm_entity_instance_198` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:10
