-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_entity_instance_160`
--

LOCK TABLES `cxm_entity_instance_160` WRITE;
/*!40000 ALTER TABLE `cxm_entity_instance_160` DISABLE KEYS */;
INSERT INTO `cxm_entity_instance_160` VALUES (7,1,1,'TicketSimple',1,'SuperAdmin','public',NULL,NULL,'04/10/2015','10:54','10:15','0','','TICKET_STATUS06','12','1','04/13/2015','',NULL,'0.00','0',NULL,NULL,'','',NULL,'SuperAdmin','2015-04-13 09:48:21','SuperAdmin','2015-04-10 10:54:51','SuperAdmin','2015-04-13 10:15:09',NULL),(8,1,1,'TicketSimple',1,'SuperAdmin','public',NULL,NULL,'04/10/2015','10:56','10:57','0','','TICKET_STATUS06','','1','04/10/2015','',NULL,'0.02','0',NULL,NULL,'','',NULL,NULL,NULL,'SuperAdmin','2015-04-10 10:57:01','SuperAdmin','2015-04-10 10:57:18',NULL),(9,1,1,'TicketSimple',1,'SuperAdmin','public',NULL,NULL,'04/10/2015','13:11','10:13','0','','TICKET_STATUS06','12','1','04/13/2015','',NULL,'0.00','0',NULL,NULL,'','',NULL,'SuperAdmin','2015-04-13 10:15:13','SuperAdmin','2015-04-10 13:12:13','SuperAdmin','2015-04-13 10:13:34',NULL),(10,1,1,'TicketSimple',5,'SuperAdmin','public',NULL,NULL,'04/10/2015','22:19','22:22','0','ACTION_2','TICKET_STATUS06','10','5','04/10/2015','',NULL,'0.05','0',NULL,NULL,'worked on...','testing edit',NULL,'SuperAdmin','2015-04-16 14:25:35','SuperAdmin','2015-04-10 22:17:29','SuperAdmin','2015-04-10 22:19:34',NULL),(11,1,1,'TicketSimple',1,'SuperAdmin','public',NULL,NULL,'04/12/2015','12:01','09:58','0','','TICKET_STATUS06','10','1','04/13/2015','0',NULL,'21.95','0',NULL,NULL,'','',NULL,NULL,NULL,'SuperAdmin','2015-04-12 11:59:29','SuperAdmin','2015-04-13 09:58:38',NULL),(12,1,1,'TicketSimple',1,'SuperAdmin','public',NULL,NULL,'04/12/2015','12:02','12:02','0','','TICKET_STATUS06','','1','04/12/2015','0',NULL,'0.00','0',NULL,NULL,'','',NULL,NULL,NULL,'SuperAdmin','2015-04-12 12:00:09','SuperAdmin','2015-04-12 12:00:27',NULL),(13,1,1,'TicketSimple',1,'SuperAdmin','public',NULL,NULL,'04/12/2015','12:21','12:22','0','','TICKET_STATUS06','','1','04/12/2015','0',NULL,'0.02','0',NULL,NULL,'','',NULL,NULL,NULL,'SuperAdmin','2015-04-12 12:19:34','SuperAdmin','2015-04-12 12:19:56',NULL),(14,1,1,'TicketSimple',3,'SuperAdmin','public',NULL,NULL,'04/12/2015','18:19','18:19','0','ACTION_1','TICKET_STATUS06','10','3','04/12/2015','0',NULL,'0.00','0',NULL,NULL,'Could not find the quick brown fox','Went to the woods and found him',NULL,NULL,NULL,'SuperAdmin','2015-04-12 18:17:36','SuperAdmin','2015-04-12 18:17:36',NULL),(15,1,1,'TicketSimple',6,'SuperAdmin','public',NULL,NULL,'04/12/2015','12:08','12:31','0','','TICKET_STATUS06','10','6','04/13/2015','0',NULL,'0.38','0',NULL,NULL,'','',NULL,NULL,NULL,'SuperAdmin','2015-04-12 23:31:09','SuperAdmin','2015-04-12 23:52:56',NULL),(16,1,1,'TicketSimple',8,'SuperAdmin','public',NULL,NULL,'04/16/2015','10:44','13:23','0','ACTION_1','TICKET_STATUS06','11','8','04/16/2015','0',NULL,'2.65','0',NULL,NULL,'test','test',NULL,NULL,NULL,'SuperAdmin','2015-04-16 10:45:16','SuperAdmin','2015-04-16 13:21:10',NULL),(17,1,1,'TicketSimple',8,'SuperAdmin','public',NULL,NULL,'04/16/2015','12:53','15:19','0','','TICKET_STATUS06','10','8','04/17/2015','0',NULL,'2.43','0',NULL,NULL,'','',NULL,NULL,NULL,'SuperAdmin','2015-04-16 12:52:15','SuperAdmin','2015-04-17 15:19:15',NULL),(18,1,1,'TicketSimple',5,'SuperAdmin','public',NULL,NULL,'04/16/2015','14:56','14:57','0','ACTION_1','TICKET_STATUS06','11','5','04/16/2015','0',NULL,'0.02','0',NULL,NULL,'','',NULL,NULL,NULL,'SuperAdmin','2015-04-16 14:54:53','SuperAdmin','2015-04-16 14:54:53',NULL),(19,1,1,'TicketSimple',5,'SuperAdmin','public',NULL,NULL,'04/16/2015','15:01','15:02','0','','TICKET_STATUS06','11','5','04/16/2015','0',NULL,'0.02','0',NULL,NULL,'','',NULL,'SuperAdmin','2015-04-16 14:59:22','SuperAdmin','2015-04-16 14:59:22','SuperAdmin','2015-04-16 14:59:38',NULL),(20,1,1,'TicketSimple',5,'SuperAdmin','public',NULL,NULL,'04/16/2015','15:24','15:25','0','ACTION_1','TICKET_STATUS06','12','5','04/16/2015','0',NULL,'0.02','0',NULL,NULL,'','',NULL,NULL,NULL,'SuperAdmin','2015-04-16 15:21:57','SuperAdmin','2015-04-16 15:22:21',NULL),(21,1,1,'TicketSimple',7,'SuperAdmin','public',NULL,NULL,'04/17/2015','16:08','16:08','0','ACTION_2','TICKET_STATUS06','11','7','04/17/2015','0',NULL,'0.00','0',NULL,NULL,'','',NULL,NULL,NULL,'SuperAdmin','2015-04-17 16:08:36','SuperAdmin','2015-05-08 16:55:58',NULL),(22,1,1,'TicketSimple',10,'SuperAdmin','public',NULL,NULL,'04/19/2015','22:34','22:35','0','ACTION_1','TICKET_STATUS06','11','10','04/19/2015','0',NULL,'0.02','0',NULL,NULL,'test','test',NULL,NULL,NULL,'SuperAdmin','2015-04-19 22:31:55','SuperAdmin','2015-04-19 22:31:55',NULL),(23,1,1,'TicketSimple',3,'SuperAdmin','public',NULL,NULL,'04/27/2015','08:10','','0','','TICKET_STATUS02','10','3','','0',NULL,'','',NULL,NULL,'We purchased one of our draft beers under the wrong category on 4/10/2015, and it is therefore not depleting from our \r\ninventory.  \r\nI didn’t know if it was possible to get the purchase changed over, I know it has been almost a month \r\nL\r\n but we just got \r\nto \r\nthe bottom of it.  I have attached a copy of the purchase order so it would be easy to find.  The beer we need changed is the \r\nLeinenkugal, \r\nand we should have purchased it as Leinenkeugal Seasonal.  I appreciate your help, and hope we can get it \r\nchanged \r\nbecause we have a whole other keg!  Thank you!','This is to check the length of resolution that is being displayed properly and how much is truncated normally.',NULL,NULL,NULL,'SuperAdmin','2015-04-27 19:38:31','SuperAdmin','2015-05-17 05:00:39',NULL);
/*!40000 ALTER TABLE `cxm_entity_instance_160` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:09
