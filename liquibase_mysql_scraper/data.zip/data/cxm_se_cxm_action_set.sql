-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_action_set`
--

LOCK TABLES `cxm_action_set` WRITE;
/*!40000 ALTER TABLE `cxm_action_set` DISABLE KEYS */;
INSERT INTO `cxm_action_set` VALUES (1,1,'1BusinessDayPriorSendAutomatedEmailToParticipants_1',1,'1BusinessDayPriorSendAutomatedEmailToParticipants_1_1','','false',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-09-12 15:04:29'),(1,1,'1BusinessDayPriorSendAutomatedEmailToParticipants_1',2,'1BusinessDayPriorSendAutomatedEmailToParticipants_1_2','\0','Entity',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-09-12 15:04:29'),(1,1,'Call1Completed_1',1,'Call1Completed_1_1','\0','false',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-09-13 16:48:04'),(1,1,'CreateTicketFromIncomingEmail_1',1,'CreateTicketFromIncomingEmail_1_1','\0','false',NULL,NULL,0,'RU_MINUTE','SuperAdmin',NULL,'SuperAdmin','2015-04-24 16:33:24'),(1,1,'IfActivityIsDeletedOrCancelled_1',1,'IfActivityIsDeletedOrCancelled_1_1','\0','Both',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-04-28 10:20:45'),(1,1,'IfActivityIsDeletedOrCancelled_1',2,'IfActivityIsDeletedOrCancelled_1_2','\0','User',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-04-28 10:20:45'),(1,1,'IFActivityIsRescheduled_1',1,'IFActivityIsRescheduled_1_1','\0','Entity',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-02-27 21:38:03'),(1,1,'Lead6DayNotification_1',1,'Lead6DayNotification_1_1','\0','false',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-06-27 11:39:13'),(1,1,'Lead6DayNotification_1',2,'Lead6DayNotification_1_2','\0','false',NULL,NULL,1,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-06-27 11:39:13'),(1,1,'leadHasNotBeenMadeIntoSO22DaysAfterReceivingLead1_1',1,'leadHasNotBeenMadeIntoSO22DaysAfterReceivingLead1_1_1','\0',NULL,NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin',NULL),(1,1,'NewLeadAssigned_1',1,'NewLeadAssigned_1_1','\0','false',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-09-13 11:30:34'),(1,1,'NewLeadAssigned_1',2,'NewLeadAssigned_1_2','\0','false',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-09-13 11:30:34'),(1,1,'NewLeadAssigned_1',3,'NewLeadAssigned_1_3','\0','false',NULL,NULL,3,'RU_MINUTE','SuperAdmin',NULL,'SuperAdmin','2014-09-13 11:30:34'),(1,1,'NewLeadCreated_1',1,'NewLeadCreated_1_1','\0','false',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-10-13 15:03:31'),(1,1,'NewLeadCreated_1',2,'NewLeadCreated_1_2','\0','false',NULL,NULL,1,'RU_MINUTE','SuperAdmin',NULL,'SuperAdmin','2014-10-13 15:03:31'),(1,1,'OnLeadRejectedReassigned_1',1,'OnLeadRejectedReassigned_1_1','\0','false',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-05-22 11:36:09'),(1,1,'WhenADemoIsScheduled_1',1,'WhenADemoIsScheduled_1_1','\0','Both',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-02-28 14:58:14'),(1,1,'WhenADemoIsScheduled_1',2,'WhenADemoIsScheduled_1_2','\0','User',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-02-28 14:58:14'),(1,1,'WhenTicketAssignedIndividual_1',1,'WhenTicketAssignedIndividual_1_1','\0','false',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-08-27 12:35:13'),(1,1,'WhenTicketAssignedIndividual_1',2,'WhenTicketAssignedIndividual_1_2','\0','false',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-08-27 12:35:13'),(1,1,'WhenTicketAssignedSynergy_1',1,'WhenTicketAssignedSynergy_1_1','\0','false',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-08-27 12:31:24'),(1,1,'WhenTicketAssignedSynergy_1',2,'WhenTicketAssignedSynergy_1_2','\0','false',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-08-27 12:31:24'),(1,1,'WhenTicketClosed_1',1,'WhenTicketClosed_1_1','\0','false',NULL,NULL,0,'','SuperAdmin',NULL,'SuperAdmin','2015-05-14 19:57:28'),(1,1,'WhenTicketNew_1',1,'WhenTicketNew_1_1','\0','false',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-08-28 12:00:44'),(1,1,'WhenTicketOnHold_1',1,'WhenTicketOnHold_1_1','\0','false',NULL,NULL,0,'RU_DAY','SuperAdmin',NULL,'SuperAdmin','2014-08-28 12:20:11');
/*!40000 ALTER TABLE `cxm_action_set` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:05
