-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_criteria`
--

LOCK TABLES `cxm_criteria` WRITE;
/*!40000 ALTER TABLE `cxm_criteria` DISABLE KEYS */;
INSERT INTO `cxm_criteria` VALUES (19,1,1,'contactForAcctTicketSimpleCriteria','Contact','parentInstanceId','=','TicketSimple::account',1,'','','SuperAdmin',NULL,'SuperAdmin',NULL),(23,1,1,'managerListCriteria','v_manager_list','*','','',1,'','\0','SuperAdmin',NULL,'SuperAdmin',NULL),(24,1,1,'salesPersonListCriteria','v_salesperson_list','*','','',1,'','\0','SuperAdmin',NULL,'SuperAdmin',NULL),(25,1,1,'supportListCriteria','v_customerservice_users','*','','',1,'','\0','SuperAdmin',NULL,'SuperAdmin',NULL),(26,1,1,'userListCriteria','v_user_list','*','','',1,'','\0','SuperAdmin',NULL,'SuperAdmin',NULL),(27,1,1,'userCalendarTypeCriteria','v_calendarsettinguid','USER_ID','=','CxmUser.user_id',1,'','\0',NULL,NULL,NULL,NULL),(58,1,1,'campaignListCriteria','Campaign','*','','',1,'','','SuperAdmin',NULL,'SuperAdmin',NULL),(59,1,1,'providerListCriteria','Provider','*','','',1,'','','SuperAdmin',NULL,'SuperAdmin',NULL),(60,1,1,'groupListCriteria','cxm_group','*','','',1,'','\0','SuperAdmin',NULL,'SuperAdmin',NULL),(68,1,1,'accountPrimContactCriteria','Contact','parentInstanceId','=','Account.instanceId',1,' and ','','SuperAdmin',NULL,'SuperAdmin',NULL),(69,1,1,'accountPrimContactCriteria','Contact','parentModName','=','Account',2,'','','SuperAdmin',NULL,'SuperAdmin',NULL),(200,1,1,'defaultCalendarTypeCriteria','v_calendarsettingforuser','user_uname','=','CxmUser.user_uname',1,'','\0',NULL,NULL,NULL,NULL),(210,1,1,'customerserviceUserCriteria','v_customerservice_users','*','','',1,'','\0',NULL,NULL,NULL,NULL),(211,1,1,'customerserviceMgrCriteria','v_customerservice_mgrs','*','','',1,'','\0',NULL,NULL,NULL,NULL),(214,1,1,'countyCriteria','v_countylist','*','','',1,'','\0',NULL,NULL,NULL,NULL),(216,1,1,'groupCriteria','v_user_groups','*',NULL,NULL,1,NULL,'\0',NULL,NULL,NULL,NULL),(222,1,1,'accountProfileInterestCriteria','v_modules','*',NULL,NULL,1,NULL,'\0',NULL,NULL,NULL,NULL),(224,1,1,'contactForAcctSalesCriteria','Contact','parentInstanceId','=','Sales::accountInSales',1,'','','SuperAdmin',NULL,'SuperAdmin',NULL),(229,1,1,'leadsActivityCriteria','v_allactionbytype','parentInstanceId','=','Leads.instanceId',1,'AND','\0',NULL,NULL,NULL,NULL),(330,1,1,'leadsActivityCriteria','v_allactionbytype','parentModuleUname','=','Leads',2,'','\0',NULL,NULL,NULL,NULL),(332,1,1,'salesOppMgrGridCriteria','SalesOppMgr','','','SalesOppMgr::tempStage',1,'','',NULL,NULL,NULL,NULL),(336,1,1,'mySalesCriteria','v_salesmaingrid','opportunityStatus','=','OPPORTUNITY1',1,' OR ','\0',NULL,NULL,NULL,NULL),(337,1,1,'mySalesCriteria','v_salesmaingrid','opportunityStatus','=','OPPORTUNITY5',2,' OR ','\0',NULL,NULL,NULL,NULL),(338,1,1,'mySalesCriteria','v_salesmaingrid','opportunityStatus','=','OPPORTUNITY6',3,'','\0',NULL,NULL,NULL,NULL),(345,1,1,'myAccountCriteria','v_acctmaingrid','status','=','AS_ACTIVE',1,'','','SuperAdmin',NULL,'SuperAdmin',NULL),(346,1,1,'productListCriteria','Product','*','','',1,'','','SuperAdmin',NULL,'SuperAdmin',NULL),(354,1,1,'accgroupselectioncriteria','v_grouplist','MODULE_UNAME','like','Account',1,NULL,'\0',NULL,NULL,NULL,NULL),(355,1,1,'contgroupselectioncriteria','v_grouplist','MODULE_UNAME','like','Contact',1,NULL,'\0',NULL,NULL,NULL,NULL),(357,1,1,'reassignCriteria','v_reassign_users','*','','',1,'','\0',NULL,NULL,NULL,NULL),(358,1,1,'stdResolutionCriteria','v_activestdproblems','*','','',1,'','\0',NULL,NULL,NULL,NULL),(359,1,1,'todoTasksCriteria1','TodoTasks','','','TodoTasks::actType',1,'','',NULL,NULL,NULL,NULL),(365,1,1,'leadStageByStatusGridCriteria','v_leadsdashboardbystage','leadParentStage','=','LeadsDashboard::tempStage',1,'','\0',NULL,NULL,NULL,NULL),(368,1,1,'homePageListCriteria','v_homepagelist','*','','',1,'','\0',NULL,NULL,NULL,NULL),(369,1,1,'dashboardEmailUser','v_dashboard_email','user_name','=','MyDashboard::userId',1,'','\0',NULL,NULL,NULL,NULL),(370,1,1,'dashboardEmailSentUser','v_dashboard_email_sent','user_name','=','MyDashboard::userId',1,'','\0',NULL,NULL,NULL,NULL),(376,1,1,'ticketIndvListCriteria','v_userList','*','','',1,'','\0','SuperAdmin',NULL,'SuperAdmin',NULL);
/*!40000 ALTER TABLE `cxm_criteria` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:13
