-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_plot`
--

LOCK TABLES `cxm_plot` WRITE;
/*!40000 ALTER TABLE `cxm_plot` DISABLE KEYS */;
INSERT INTO `cxm_plot` VALUES (1,1,'acctBarPlot','ClusteredColumns','','',5,'true:false:true:false',NULL,'',NULL,'x','y','Account','Total Sales',NULL,NULL,'accountData','acctcYearData',NULL,NULL,NULL,NULL),(1,1,'plot1','Pie','','',5,'true:false:true:false','','',NULL,'x','y','X axis','Y axis',NULL,NULL,'campAnalysisData','analysisData',NULL,NULL,NULL,NULL),(1,1,'plot1line','StackedLines','','',5,'false:false:true:false',NULL,'',NULL,'x','y','Campaign','Cost',NULL,NULL,'campAnalysisData','Budget',NULL,NULL,NULL,NULL),(1,1,'plot2','Pie','','',5,'true:false:true:false',NULL,'',NULL,'x','y','Campaign','Amount',NULL,NULL,'campaignData','Potential',NULL,NULL,NULL,NULL),(1,1,'plot3','ClusteredColumns','','',5,'true:false:true:false',NULL,'',NULL,'x','y','Campaign','Amount',NULL,NULL,'campaignData','Actual',NULL,NULL,NULL,NULL),(1,1,'plot4','ClusteredColumns','','',5,'true:false:true:false',NULL,'',NULL,'x','y','Campaign','Amount',NULL,NULL,'campaignData','Actual',NULL,NULL,NULL,NULL),(1,1,'plot5','StackedLines','','',5,'true:false:true:false',NULL,'',NULL,'x','y','Campaign','Count',NULL,NULL,'campWinData','Won',NULL,NULL,NULL,NULL),(1,1,'plot6','ClusteredColumns','','',5,'true:false:true:false',NULL,'',NULL,'x','y','Campaign','Amount',NULL,NULL,'campaignData','Loss',NULL,NULL,NULL,NULL),(1,1,'prodTypeBarPlot','ClusteredColumns','','',5,'true:false:true:false',NULL,'',NULL,'x','y','Product Type','Total Sales',NULL,NULL,'prodTypeData','cyrTotal',NULL,NULL,NULL,NULL),(1,1,'salesSalesStagePlot','Pie','','',5,'true:false:true:false',NULL,'',NULL,'x','y','X axis','Amount',NULL,NULL,'salesSalesStage_lvalue','salesSalesStage_scount',NULL,NULL,NULL,NULL),(1,1,'salesWonLossPie','Pie','','',5,'true:false:true:false',NULL,'',NULL,'x','y','X axis','Amount',NULL,NULL,'salesType','salesCnt',NULL,NULL,NULL,NULL),(1,1,'sd2potbarplot','StackedColumns','','',10,'true:false:true:false',NULL,'',NULL,'x','y','Close Date','Amount',NULL,NULL,'monthData','Negotiation',NULL,NULL,NULL,NULL),(1,1,'sdbarplot','ClusteredColumns','','',5,'true:false:true:false',NULL,'',NULL,'x','y','Sales Person','Y axis',NULL,NULL,'spersonData','PotentialSales',NULL,NULL,NULL,NULL),(1,1,'sdpieplot','Pie','','',5,'true:false:true:false',NULL,'',NULL,'x','y','X axis','Amount',NULL,NULL,'PiePersonData','PieSales',NULL,NULL,NULL,NULL),(1,1,'ticketSimpleStatusBarPlot','ClusteredColumns','','',5,'true:false:true:false',NULL,'',NULL,'x','y','Ticket Status','Number of Tickets',NULL,NULL,'ticketSimpleStatusData','ticketSimpleStatusCountData',NULL,NULL,NULL,NULL),(1,1,'ticketSimpleUrgencyBarPlot','ClusteredColumns','','',5,'true:false:true:false',NULL,'',NULL,'x','y','Priority','Number of Tickets',NULL,NULL,'ticketSimpleUrgencyData','ticketSimpleUrgencyCountData',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `cxm_plot` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:11
