-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_rule_criteria`
--

LOCK TABLES `cxm_rule_criteria` WRITE;
/*!40000 ALTER TABLE `cxm_rule_criteria` DISABLE KEYS */;
INSERT INTO `cxm_rule_criteria` VALUES (1,1,'1BusinessDayPriorSendAutomatedEmailToParticipants',1,'activity','activityType',NULL,NULL,'AT_SALES','IN','AND','\0','','','SuperAdmin','2014-09-12 15:04:29','SuperAdmin','2014-09-12 15:04:29'),(1,1,'1BusinessDayPriorSendAutomatedEmailToParticipants',2,'activity','activitySubType',NULL,NULL,'AT2_DEMO','IN','',NULL,'','','SuperAdmin','2014-09-12 15:04:29','SuperAdmin','2014-09-12 15:04:29'),(1,1,'Call1Completed',1,'activity','status',NULL,NULL,'ACT_STATUS_COMPLETED','changeTo','AND',NULL,'','','SuperAdmin','2014-09-13 16:48:04','SuperAdmin','2014-09-13 16:48:04'),(1,1,'Call1Completed',2,'activity','activitySubType',NULL,NULL,'AT2_CALL1','IN','AND',NULL,'','','SuperAdmin','2014-09-13 16:48:04','SuperAdmin','2014-09-13 16:48:04'),(1,1,'Call1Completed',3,'activity','activityType',NULL,NULL,'AT_LEADCC','IN','AND',NULL,'','','SuperAdmin','2014-09-13 16:48:04','SuperAdmin','2014-09-13 16:48:04'),(1,1,'IfActivityIsDeletedOrCancelled',1,'activity','activityType',NULL,NULL,'AT_SALES','IN','AND','\0','','','SuperAdmin','2014-04-28 10:20:45','SuperAdmin','2014-04-28 10:20:45'),(1,1,'IfActivityIsDeletedOrCancelled',2,'activity','activitySubType',NULL,NULL,'AT2_DEMO','IN','AND',NULL,'','','SuperAdmin','2014-04-28 10:20:45','SuperAdmin','2014-04-28 10:20:45'),(1,1,'IfActivityIsDeletedOrCancelled',3,'activity','status',NULL,NULL,'ACT_STATUS_CANCELED','IN','','\0','','','SuperAdmin','2014-04-28 10:20:45','SuperAdmin','2014-04-28 10:20:45'),(1,1,'IFActivityIsRescheduled',1,'activity','activityType',NULL,NULL,'AT_SALES','IN','AND','\0','','','SuperAdmin','2014-02-27 21:38:03','SuperAdmin','2014-02-27 21:38:03'),(1,1,'IFActivityIsRescheduled',2,'activity','activitySubType',NULL,NULL,'AT2_DEMO','IN','AND',NULL,'','','SuperAdmin','2014-02-27 21:38:03','SuperAdmin','2014-02-27 21:38:03'),(1,1,'IFActivityIsRescheduled',3,'activity','fromDate',NULL,NULL,NULL,'valuechange','OR',NULL,NULL,NULL,'SuperAdmin','2014-02-27 21:38:03','SuperAdmin','2014-02-27 21:38:03'),(1,1,'IFActivityIsRescheduled',4,'activity','thruDate',NULL,NULL,NULL,'valuechange','',NULL,NULL,NULL,'SuperAdmin','2014-02-27 21:38:03','SuperAdmin','2014-02-27 21:38:03'),(1,1,'Lead6DayNotification',1,'Leads','createDate',NULL,NULL,'5','>','AND',NULL,'difference','current','SuperAdmin','2014-06-27 11:39:13','SuperAdmin','2014-06-27 11:39:13'),(1,1,'Lead6DayNotification',2,'Leads','RecordsCreated',NULL,NULL,'Yes','<>','AND','\0','','','SuperAdmin','2014-06-27 11:39:13','SuperAdmin','2014-06-27 11:39:13'),(1,1,'Lead6DayNotification',3,'Leads','leadStatus',NULL,NULL,'LS_REJECTED,LS_STOP_ALL,LS_STOP','NOT IN','',NULL,'','','SuperAdmin','2014-06-27 11:39:13','SuperAdmin','2014-06-27 11:39:13'),(1,1,'NewLeadAssigned',1,'Leads','leadStatus',NULL,NULL,'LS_ASSIGNED,LS_REASSIGNED','IN','AND',NULL,'','','SuperAdmin','2014-09-13 11:30:34','SuperAdmin','2014-09-13 11:30:34'),(1,1,'NewLeadAssigned',2,'Leads','AssignedTo',NULL,NULL,'22','changeTo','',NULL,'','','SuperAdmin','2014-09-13 11:30:34','SuperAdmin','2014-09-13 11:30:34'),(1,1,'OnLeadRejectedReassigned',1,'Leads','leadStatus',NULL,NULL,'LS_REASSIGNED','changeTo','OR',NULL,'','','SuperAdmin','2014-05-22 11:36:09','SuperAdmin','2014-05-22 11:36:09'),(1,1,'OnLeadRejectedReassigned',2,'Leads','leadStatus',NULL,NULL,'LS_REJECTED','changeTo','OR',NULL,'','','SuperAdmin','2014-05-22 11:36:09','SuperAdmin','2014-05-22 11:36:09'),(1,1,'OnLeadRejectedReassigned',3,'Leads','leadStatus',NULL,NULL,'LS_STOP_ALL','changeTo','OR',NULL,'','','SuperAdmin','2014-05-22 11:36:09','SuperAdmin','2014-05-22 11:36:09'),(1,1,'OnLeadRejectedReassigned',4,'Leads','leadStatus',NULL,NULL,'LS_STOP','changeTo','',NULL,'','','SuperAdmin','2014-05-22 11:36:09','SuperAdmin','2014-05-22 11:36:09'),(1,1,'WhenADemoIsScheduled',1,'activity','activityType',NULL,NULL,'AT_SALES','IN','AND',NULL,'','','SuperAdmin','2014-02-28 14:58:14','SuperAdmin','2014-02-28 14:58:14'),(1,1,'WhenADemoIsScheduled',2,'activity','activitySubType',NULL,NULL,'AT2_DEMO','IN','',NULL,'','','SuperAdmin','2014-02-28 14:58:14','SuperAdmin','2014-02-28 14:58:14'),(1,1,'WhenTicketClosed',1,'TicketSimple','status',NULL,NULL,'TICKET_STATUS06','changeTo','AND','\0','','','SuperAdmin','2015-05-14 19:57:28','SuperAdmin','2015-05-14 19:57:28'),(1,1,'WhenTicketClosed',2,'TicketSimple','source',NULL,NULL,'TS_SSPORTAL','IN','AND','\0','','','SuperAdmin','2015-05-14 19:57:28','SuperAdmin','2015-05-14 19:57:28'),(1,1,'WhenTicketClosed',3,'TicketSimple','urgency',NULL,NULL,'CRITICAL','NOT IN','','\0','','','SuperAdmin','2015-05-14 19:57:28','SuperAdmin','2015-05-14 19:57:28'),(1,1,'WhenTicketNew',1,'TicketSimple','status',NULL,NULL,'TICKET_STATUS01','IN','AND','\0','','','SuperAdmin','2014-08-28 12:00:44','SuperAdmin','2014-08-28 12:00:44'),(1,1,'WhenTicketNew',2,'TicketSimple','source',NULL,NULL,'TS_SSPORTAL','IN','AND',NULL,'','','SuperAdmin','2014-08-28 12:00:44','SuperAdmin','2014-08-28 12:00:44'),(1,1,'WhenTicketNew',3,'TicketSimple','urgency',NULL,NULL,'CRITICAL','NOT IN','',NULL,'','','SuperAdmin','2014-08-28 12:00:44','SuperAdmin','2014-08-28 12:00:44'),(1,1,'WhenTicketOnHold',1,'TicketSimple','status',NULL,NULL,'TICKET_STATUS04','changeTo','',NULL,'','','SuperAdmin','2014-08-28 12:20:11','SuperAdmin','2014-08-28 12:20:11');
/*!40000 ALTER TABLE `cxm_rule_criteria` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:15
