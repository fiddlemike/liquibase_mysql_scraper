-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_rule`
--

LOCK TABLES `cxm_rule` WRITE;
/*!40000 ALTER TABLE `cxm_rule` DISABLE KEYS */;
INSERT INTO `cxm_rule` VALUES (1,1,'1BusinessDayPriorSendAutomatedEmailToParticipants','1BusinessDayPriorSendAutomatedEmailToParticipants','ENTITY_RULE','activity','1 business day prior: Send automated email to participants.',NULL,'1BusinessDayPriorSendAutomatedEmailToParticipants',NULL,'1BusinessDayPriorSendAutomatedEmailToParticipants_1','1BusinessDayPriorSendAutomatedEmailToParticipants_0','SuperAdmin',NULL,'SuperAdmin','2014-09-12 15:04:29'),(1,1,'Call1Completed','Call1Completed','ENTITY_RULE','activity','When Activity of type Lead Cold Call and subtype of Call 1 completed, created Call 2',NULL,'Call1Completed',NULL,'Call1Completed_1','Call1Completed_0','SuperAdmin',NULL,'SuperAdmin','2014-09-13 16:48:03'),(1,1,'CreateTicketFromIncomingEmail','CreateTicketFromIncomingEmail','ENTITY_RULE','incomingEmail','Create a Ticket when an Incoming Email is received',NULL,'CreateTicketFromIncomingEmail',NULL,'CreateTicketFromIncomingEmail_1','CreateTicketFromIncomingEmail_0','SuperAdmin',NULL,'SuperAdmin','2015-04-24 16:33:24'),(1,1,'IfActivityIsDeletedOrCancelled','IfActivityIsDeletedOrCancelled','ENTITY_RULE','activity','If activity is deleted or canceled on the same day send notification to CXM users. Also on the same day send automated email to CXM users to confirm that the activity was canceled. Confirmation should include original date/time',NULL,'IfActivityIsDeletedOrCancelled',NULL,'IfActivityIsDeletedOrCancelled_1','IfActivityIsDeletedOrCancelled_0','SuperAdmin',NULL,'SuperAdmin','2014-04-28 10:20:45'),(1,1,'IFActivityIsRescheduled','IFActivityIsRescheduled','ENTITY_RULE','activity','IF activity is rescheduled - Same day send automated email Reminder for scheduled demo.',NULL,'IFActivityIsRescheduled',NULL,'IFActivityIsRescheduled_1','IFActivityIsRescheduled_0','SuperAdmin',NULL,'SuperAdmin','2014-02-27 21:38:03'),(1,1,'Lead6DayNotification','Lead6DayNotification','ENTITY_RULE','Leads','lead has not been made into a SO/Account/Contact after 6 days',NULL,'Lead6DayNotification',NULL,'Lead6DayNotification_1','Lead6DayNotification_0','SuperAdmin',NULL,'SuperAdmin','2014-06-27 11:39:13'),(1,1,'NewLeadAssigned','NewLeadAssigned','ENTITY_RULE','Leads','New Lead is Assigned to the Account Manager',NULL,'NewLeadAssigned',NULL,'NewLeadAssigned_1','NewLeadAssigned_0','SuperAdmin',NULL,'SuperAdmin','2014-09-13 11:30:34'),(1,1,'NewLeadCreated','NewLeadCreated','ENTITY_RULE','Leads','NewLeadCreated',NULL,'NewLeadCreated',NULL,'NewLeadCreated_1','NewLeadCreated_0','SuperAdmin',NULL,'SuperAdmin','2014-10-13 15:03:31'),(1,1,'OnLeadRejectedReassigned','OnLeadRejectedReassigned','ENTITY_RULE','Leads','OnLeadRejectedReassigned',NULL,'OnLeadRejectedReassigned',NULL,'OnLeadRejectedReassigned_1','OnLeadRejectedReassigned_0','SuperAdmin',NULL,'SuperAdmin','2014-05-22 11:36:09'),(1,1,'WhenADemoIsScheduled','WhenADemoIsScheduled','ENTITY_RULE','activity','When an activity is created on CXM calendar (Activity Type = Sales, Sub-Type = Demo) Sent Email to all participants.',NULL,'WhenADemoIsScheduled',NULL,'WhenADemoIsScheduled_1','WhenADemoIsScheduled_0','SuperAdmin',NULL,'SuperAdmin','2014-02-28 14:58:14'),(1,1,'WhenTicketAssignedIndividual','WhenTicketAssignedIndividual','ENTITY_RULE','TicketSimple','WhenTicketAssignedIndividual not synergy',NULL,'WhenTicketAssignedIndividual','select instance_id from cxm_entity_instance_67 where entity_value_70 = \'INDIVIDUAL\' and entity_value_17 is not null and ENTITY_VALUE_23 = \'TS_INTERNAL\'','WhenTicketAssignedIndividual_1','WhenTicketAssignedIndividual_0','SuperAdmin',NULL,'SuperAdmin','2014-08-27 12:35:13'),(1,1,'WhenTicketAssignedSynergy','WhenTicketAssignedSynergy','ENTITY_RULE','TicketSimple','WhenTicketAssignedSynergy',NULL,'WhenTicketAssignedSynergy','select instance_id from cxm_entity_instance_67 where entity_value_70 = \'INDIVIDUAL\' and entity_value_17 = 19 and entity_value_23 = \'TS_INTERNAL\'','WhenTicketAssignedSynergy_1','WhenTicketAssignedSynergy_0','SuperAdmin',NULL,'SuperAdmin','2014-08-27 12:31:24'),(1,1,'WhenTicketClosed','WhenTicketClosed','ENTITY_RULE','TicketSimple','WhenTicketClosed',NULL,'WhenTicketClosed',NULL,'WhenTicketClosed_1','WhenTicketClosed_0','SuperAdmin',NULL,'SuperAdmin','2015-05-14 19:57:28'),(1,1,'WhenTicketNew','WhenTicketNew','ENTITY_RULE','TicketSimple','WhenTicketNew',NULL,'WhenTicketNew',NULL,'WhenTicketNew_1','WhenTicketNew_0','SuperAdmin',NULL,'SuperAdmin','2014-08-28 12:00:44'),(1,1,'WhenTicketOnHold','WhenTicketOnHold','ENTITY_RULE','TicketSimple','WhenTicketOnHold',NULL,'WhenTicketOnHold',NULL,'WhenTicketOnHold_1','WhenTicketOnHold_0','SuperAdmin',NULL,'SuperAdmin','2014-08-28 12:20:11');
/*!40000 ALTER TABLE `cxm_rule` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:10
