-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_email_action`
--

LOCK TABLES `cxm_email_action` WRITE;
/*!40000 ALTER TABLE `cxm_email_action` DISABLE KEYS */;
INSERT INTO `cxm_email_action` VALUES (1,1,'1BusinessDayPriorSendAutomatedEmailToParticipants_1_2','1 business day prior','','\0','\0','\0','',NULL,26,'CXM Demo Appointment Tomorrow','<div style','','SendGrid','SuperAdmin',NULL,'SuperAdmin','2014-09-12 15:04:29'),(1,1,'IfActivityIsDeletedOrCancelled_1_1','activity is deleted or cancelled','','\0','\0','\0','',NULL,30,'activity is deleted or cancelled','<div style','','SendGrid','SuperAdmin',NULL,'SuperAdmin','2014-04-28 10:20:45'),(1,1,'IFActivityIsRescheduled_1_1','activity is rescheduled','','\0','\0','\0','',NULL,29,'activity is rescheduled','<div style','','SendGrid','SuperAdmin',NULL,'SuperAdmin','2014-02-27 21:38:03'),(1,1,'Lead6DayNotification_1_1','Lead#1','','','\0','\0','\0',NULL,17,'CRM Referral','<p align','','SendGrid','SuperAdmin',NULL,'SuperAdmin','2014-06-27 11:39:13'),(1,1,'NewLeadAssigned_1_1','Account Manager Assigned','','','\0','\0','\0',NULL,17,'CXM Referral','<div style','','SendGrid','SuperAdmin',NULL,'SuperAdmin','2014-09-13 11:30:34'),(1,1,'NewLeadAssigned_1_2','New Lead Information','','\0','\0','\0','\0','tfryer',16,'New Lead Assigned','<font color','','SendGrid','SuperAdmin',NULL,'SuperAdmin','2014-09-13 11:30:34'),(1,1,'NewLeadCreated_1_2','new lead email template 0','','','\0','\0','\0',NULL,75,'Thank You','<p align','','SendGrid','SuperAdmin',NULL,'SuperAdmin','2014-10-13 15:03:31'),(1,1,'WhenADemoIsScheduled_1_1','Activity Type = SalesSub-Type = Demo','','\0','\0','\0','',NULL,27,'CXM Demo Confirmation','<div style','','SendGrid','SuperAdmin',NULL,'SuperAdmin','2014-02-28 14:58:14'),(1,1,'WhenTicketAssignedIndividual_1_1','TicketAssigned','','\0','\0','\0','',NULL,74,'TicketAssigned','<!-- 	[if gte mso 9]><xml> <o:OfficeDocumentSettings> <o:RelyOnVML/> <o:AllowPNG/> </o:OfficeDocumentSettings> </xml><![endif] --> <span style','','SendGrid','SuperAdmin',NULL,'SuperAdmin','2014-08-27 12:35:13'),(1,1,'WhenTicketAssignedSynergy_1_1','TicketAssignedSynergy','','\0','\0','\0','',NULL,73,'TicketAssignedSynergy','<span style=\",&quot; Calibri&quot; font-family: &quot; line-height: 115%; sans-serif&quot;\"><font size=\"3\"><font size=\"3\"><span style=\",&quot; Calibri&quot; font-family: &quot; line-height: 115%; sans-serif&quot;\"><font size=\"3\">Hi {[TicketSimple:assignedTo]}, &lt;p&gt;Ticket {[TicketSimple:ticketID]} has been assigned to you, the basic details of this ticket are included below&lt;/p&gt; &lt;/p&gt; {[TicketSimple:urgency]}&lt;/p&gt;&lt;p&gt;{[TicketSimple:typeCall]}&lt;/p&gt;&lt;p&gt;{[TicketSimple:account]} {[TicketSimple:contact]}&lt;/p&gt;&lt;p&gt;{[TicketSimple:probDesc]}&lt;/p&gt;</font></span>\n<br>\n&nbsp;\n<br>\n</font></font></span><span style=\",&quot; Calibri&quot; font-family: &quot; line-height: 115%; sans-serif&quot;\"></span><span style=\",&quot; Calibri&quot; font-family: &quot; line-height: 115%; sans-serif&quot;\"><font size=\"3\"><span style=\",&quot; Calibri&quot; font-family: &quot; line-height: 115%; sans-serif&quot;\"><font size=\"3\">{[TicketSimple:userId]} </font></span></font></span>','','SendGrid','SuperAdmin',NULL,'SuperAdmin','2014-08-27 12:31:24'),(1,1,'WhenTicketClosed_1_1','TicketClosed','','\0','\0','\0','\0','CXMAdmin',70,'CXM Support Ticket {[TicketSimple:ticketID]} Closed! Yea!!!','','','SMTP','SuperAdmin',NULL,'SuperAdmin','2015-05-14 19:57:28'),(1,1,'WhenTicketNew_1_1','NewTicket','','\0','\0','\0','',NULL,64,'NewTicket','<p class','','SendGrid','SuperAdmin',NULL,'SuperAdmin','2014-08-28 12:00:45'),(1,1,'WhenTicketOnHold_1_1','TicketOnHold','','\0','\0','\0','\0','tsmith',72,'TicketOnHold','Hi, Thank you again for your support and patience! We had to place your ticket on hold. Give me a little time to talk with the support team and find out the situation. I will give you an update as soon as I understand why you ticket was placed on-hold. <br> <br> Tim Smith','','SendGrid','SuperAdmin',NULL,'SuperAdmin','2014-08-28 12:20:11');
/*!40000 ALTER TABLE `cxm_email_action` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:09
