-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_activity_participants`
--

LOCK TABLES `cxm_activity_participants` WRITE;
/*!40000 ALTER TABLE `cxm_activity_participants` DISABLE KEYS */;
INSERT INTO `cxm_activity_participants` VALUES (1,1,'User',1,'/','Viewed','admin12@creedenz.com','SuperAdmin','2015-04-03 14:44:45','SuperAdmin','2015-04-03 14:46:17'),(2,2,'User',1,'/','Viewed','admin12@creedenz.com','SuperAdmin','2015-04-03 14:50:54','SuperAdmin','2015-04-21 10:37:15'),(3,3,'User',1,'/','/','admin12@creedenz.com','SuperAdmin','2015-04-03 14:55:53','SuperAdmin','2015-04-03 14:55:53'),(4,4,'User',3,'/','Viewed','awebb@cxmcrm.com','awebb','2015-04-10 00:49:25','awebb','2015-04-10 00:49:27'),(6,6,'User',1,'/',NULL,NULL,'SuperAdmin','2015-04-21 13:17:23','SuperAdmin','2015-04-21 13:17:23'),(7,7,'User',1,'/',NULL,NULL,'SuperAdmin','2015-04-24 16:06:27','SuperAdmin','2015-04-24 16:06:27'),(10,8,'User',1,'/','Viewed','admin12@creedenz.com','SuperAdmin','2015-05-03 00:50:33','SuperAdmin','2015-05-03 09:13:29');
/*!40000 ALTER TABLE `cxm_activity_participants` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:05
