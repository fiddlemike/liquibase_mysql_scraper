-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_notes`
--

LOCK TABLES `cxm_notes` WRITE;
/*!40000 ALTER TABLE `cxm_notes` DISABLE KEYS */;
INSERT INTO `cxm_notes` VALUES (1,1,1,'TicketSimple',8,'nerw','new notes','SuperAdmin','public',NULL,NULL,NULL,'SuperAdmin','2015-04-16 10:44:05','SuperAdmin','2015-04-16 10:44:05'),(2,1,1,'TicketSimple',10,'Hello','Did you know they are making a Jurrasic World movie? It looks awesome!','SuperAdmin','public',NULL,'SuperAdmin','2015-04-24 10:43:09','SuperAdmin','2015-04-24 10:38:28','SuperAdmin','2015-04-24 10:43:09'),(3,1,1,'TicketSimple',11,'Note 1 Type','Note 1 note','SuperAdmin','public',NULL,'SuperAdmin','2015-04-29 10:45:52','SuperAdmin','2015-04-29 10:45:42','SuperAdmin','2015-04-29 10:45:52'),(4,1,1,'TicketSimple',3,'Test','Test Ticket Data','SuperAdmin','public',NULL,'SuperAdmin','2015-05-03 09:13:18','SuperAdmin','2015-05-03 00:00:21','SuperAdmin','2015-05-03 09:13:18'),(5,1,1,'TicketSimple',13,'','note\n','SuperAdmin','public',NULL,'SuperAdmin','2015-05-04 11:13:27','SuperAdmin','2015-05-04 11:01:17','SuperAdmin','2015-05-04 11:13:27');
/*!40000 ALTER TABLE `cxm_notes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:09
