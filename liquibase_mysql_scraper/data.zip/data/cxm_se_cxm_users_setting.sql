-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_users_setting`
--

LOCK TABLES `cxm_users_setting` WRITE;
/*!40000 ALTER TABLE `cxm_users_setting` DISABLE KEYS */;
INSERT INTO `cxm_users_setting` VALUES (1,1,'alertInterval','time',0,10,'Default time alert',14,'Profile',50,NULL,'00:10','','','','\0','','','','','','\0',NULL,NULL,NULL,NULL),(1,1,'calendarDayViewStartTime','time',0,100,'Calendar Day View Start Time',7,'Calendar',50,NULL,'00:00','','','','\0','','','','','','\0',NULL,NULL,NULL,NULL),(1,1,'cellNumber','phonenumber',0,10,'Cell Number',9,'Contact',50,NULL,'','','','','\0','','','','','','\0',NULL,NULL,NULL,NULL),(1,1,'cellProvider','query',0,100,'Select Cell Provider',10,'Contact',50,NULL,'','providerListCriteria','providerName','domain','\0','','','','','','\0',NULL,NULL,NULL,NULL),(1,1,'defaultCalendarSetting','query',0,0,'Default Calendar View',5,'Calendar',50,NULL,'','userCalendarTypeCriteria','CALENDAR_SETTING_UNAME','CALENDAR_SETTING_UNAME','\0','','','','','','\0',NULL,NULL,NULL,NULL),(1,1,'defaultCalendarTypeForOutlook','query',1,100,'Outlook Sync: Default Calendar',3,'Outlook',50,NULL,'','defaultCalendarTypeCriteria','CALENDAR_UNAME','CALENDAR_UNAME','\0','','','','','','\0',NULL,NULL,NULL,NULL),(1,1,'defaultCalendarView','lookup',0,0,'Default Calendar Display Type',6,'Calendar',50,NULL,'','DEFAULT_CALENDAR_VIEW','','','\0','','','','','','\0',NULL,'2012-12-20 12:50:05',NULL,'2012-12-20 12:50:05'),(1,1,'homePage','query',0,1000,'Default Home Page',14,'Profile',50,NULL,'','homePageListCriteria','display_name','module_uname','\0','','','','','','\0',NULL,NULL,NULL,NULL),(1,1,'lastOutlookSyncTime','',0,0,'',1,'Outlook',0,NULL,'','','','','\0','','','','','','\0',NULL,NULL,NULL,NULL),(1,1,'noOfDaysWeeks','integer',0,31,'No. Of Days/Weeks for Scheduling',8,'Calendar',50,NULL,'','','','','\0','','','','','','\0',NULL,'2012-12-20 12:50:05',NULL,'2012-12-20 12:50:05'),(1,1,'overrideIgnoreFlagForOutookSync','lookup',0,0,'Sync To Outlook (Activity)',2,'Outlook',50,NULL,'','OUTLOOK_SYNC_FLAG','','','\0','','','','','','\0',NULL,NULL,NULL,NULL),(1,1,'resourceCost','float',0,1000,'Cost of Resource per Hour',12,'Profile',50,NULL,'','','','','\0','','','','','','\0',NULL,'2012-12-20 12:50:05',NULL,'2012-12-20 12:50:05'),(1,1,'signature','htmlTextArea',0,100,'Signature',4,'Outlook',50,NULL,'','','','','\0','','','','','','',NULL,NULL,NULL,NULL),(1,1,'userPosition','lookup',0,0,'User Position',11,'Profile',50,NULL,'','USR_POSITION','','','\0','','','','','','\0',NULL,'2012-12-20 12:50:05',NULL,'2012-12-20 12:50:05');
/*!40000 ALTER TABLE `cxm_users_setting` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:11
