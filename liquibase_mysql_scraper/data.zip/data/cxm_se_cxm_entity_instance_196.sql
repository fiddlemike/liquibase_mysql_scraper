-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_entity_instance_196`
--

LOCK TABLES `cxm_entity_instance_196` WRITE;
/*!40000 ALTER TABLE `cxm_entity_instance_196` DISABLE KEYS */;
INSERT INTO `cxm_entity_instance_196` VALUES (3,1,1,NULL,NULL,'CXMAdmin','public',NULL,NULL,'ReceiveSupportEmail','ReceiveSupportEmail','02/11/2015','jcato@rosnet.com','testsupport@rosnet.com','','','Test 3',NULL,'15',NULL,'15-15',NULL,NULL,'Ticket','Test 3   Regards,   Jeremy Cato Project Manager 8500 NW River Park Dr. Pillar 342 | Parkville, MO 64152 V 816.746.4100 | F 816.746.4101 | C 816.813.4405  ',NULL,NULL,NULL,NULL,'CXMAdmin','2015-03-10 16:15:08','CXMAdmin','2015-03-10 16:15:08',NULL),(4,1,1,NULL,NULL,'CXMAdmin','public',NULL,NULL,'ReceiveSupportEmail','ReceiveSupportEmail','02/11/2015','testsupport@rosnet.com','testsupport@rosnet.com','','','Microsoft Outlook Test Message',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'This is an e-mail message sent automatically by Microsoft Outlook while testing the settings for your account.',NULL,NULL,NULL,NULL,'CXMAdmin','2015-03-10 16:15:08','CXMAdmin','2015-03-10 16:15:08',NULL),(5,1,1,NULL,NULL,'CXMAdmin','public',NULL,NULL,'ReceiveSupportEmail','ReceiveSupportEmail','02/11/2015','testsupport@rosnet.com','testsupport@rosnet.com','','','Microsoft Outlook Test Message',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'This is an e-mail message sent automatically by Microsoft Outlook while testing the settings for your account.',NULL,NULL,NULL,NULL,'CXMAdmin','2015-03-10 16:15:09','CXMAdmin','2015-03-10 16:15:09',NULL),(6,1,1,NULL,NULL,'CXMAdmin','public',NULL,NULL,'ReceiveSupportEmail','ReceiveSupportEmail','02/11/2015','testsupport@rosnet.com','testsupport@rosnet.com','','','Microsoft Outlook Test Message',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'This is an e-mail message sent automatically by Microsoft Outlook while testing the settings for your account.',NULL,NULL,NULL,NULL,'CXMAdmin','2015-03-10 16:15:09','CXMAdmin','2015-03-10 16:15:09',NULL),(7,1,1,NULL,NULL,'CXMAdmin','public',NULL,NULL,'ReceiveSupportEmail','ReceiveSupportEmail','02/11/2015','testsupport@rosnet.com','testsupport@rosnet.com','','','Microsoft Outlook Test Message',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'This is an e-mail message sent automatically by Microsoft Outlook while testing the settings for your account.',NULL,NULL,NULL,NULL,'CXMAdmin','2015-03-10 16:15:09','CXMAdmin','2015-03-10 16:15:09',NULL);
/*!40000 ALTER TABLE `cxm_entity_instance_196` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:09
