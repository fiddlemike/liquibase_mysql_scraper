-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_distribution_queue`
--

LOCK TABLES `cxm_distribution_queue` WRITE;
/*!40000 ALTER TABLE `cxm_distribution_queue` DISABLE KEYS */;
INSERT INTO `cxm_distribution_queue` VALUES (1,1,1,'2015-03-30 13:40:29','ABL::NewLeadCreated_1_2 30/03/2015 13:40::Leads::7','email','an_email@yahoo.com',NULL,'Thank You','<p align',NULL,'Leads',7,NULL,'','SendGrid','public','error','SuperAdmin','2015-03-30 13:40:29','SuperAdmin','2015-03-30 13:40:29',75),(2,1,1,'2015-03-31 23:27:12','ABL::NewLeadCreated_1_2 31/03/2015 23:27::Leads::1','email','brian@deltapipeline.net',NULL,'Thank You','<p align',NULL,'Leads',1,NULL,'','SendGrid','public','error','SuperAdmin','2015-03-31 23:27:12','SuperAdmin','2015-03-31 23:27:12',75),(3,1,1,'2015-03-31 23:27:12','ABL::NewLeadCreated_1_2 31/03/2015 23:27::Leads::2','email','fangs4ever@deltapipel.net',NULL,'Thank You','<p align',NULL,'Leads',2,NULL,'','SendGrid','public','error','SuperAdmin','2015-03-31 23:27:12','SuperAdmin','2015-03-31 23:27:12',75),(4,1,1,'2015-03-31 23:27:12','ABL::NewLeadCreated_1_2 31/03/2015 23:27::Leads::3','email','lolathelete@deltapipelin.net',NULL,'Thank You','<p align',NULL,'Leads',3,NULL,'','SendGrid','public','error','SuperAdmin','2015-03-31 23:27:12','SuperAdmin','2015-03-31 23:27:12',75),(5,1,1,'2015-04-06 13:14:26','ABL::NewLeadCreated_1_2 06/04/2015 13:14::Leads::3','email','mysteries@yahoo.com',NULL,'Thank You','<p align',NULL,'Leads',3,NULL,'','SendGrid','public','error','SuperAdmin','2015-04-06 13:14:26','SuperAdmin','2015-04-06 13:14:26',75);
/*!40000 ALTER TABLE `cxm_distribution_queue` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:07
