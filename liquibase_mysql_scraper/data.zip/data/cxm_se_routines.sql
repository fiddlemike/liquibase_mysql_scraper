-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary table structure for view `v_accountallcompletedactivity`
--

DROP TABLE IF EXISTS `v_accountallcompletedactivity`;
/*!50001 DROP VIEW IF EXISTS `v_accountallcompletedactivity`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_accountallcompletedactivity` (
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `activityModName` tinyint NOT NULL,
  `activityModId` tinyint NOT NULL,
  `update_date` tinyint NOT NULL,
  `activity_type` tinyint NOT NULL,
  `parent_instance_id` tinyint NOT NULL,
  `parent_module_uname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_sales_dash_actual`
--

DROP TABLE IF EXISTS `v_sales_dash_actual`;
/*!50001 DROP VIEW IF EXISTS `v_sales_dash_actual`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_sales_dash_actual` (
  `instanceId` tinyint NOT NULL,
  `organization_id` tinyint NOT NULL,
  `company_id` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `actualAmt` tinyint NOT NULL,
  `SPName` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_ticketavgrestimebypriority`
--

DROP TABLE IF EXISTS `v_ticketavgrestimebypriority`;
/*!50001 DROP VIEW IF EXISTS `v_ticketavgrestimebypriority`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_ticketavgrestimebypriority` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `row_number` tinyint NOT NULL,
  `priority` tinyint NOT NULL,
  `age` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_salesmaingrid`
--

DROP TABLE IF EXISTS `v_salesmaingrid`;
/*!50001 DROP VIEW IF EXISTS `v_salesmaingrid`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_salesmaingrid` (
  `displayFieldName` tinyint NOT NULL,
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `opportunityName` tinyint NOT NULL,
  `amountPerUnitPotential` tinyint NOT NULL,
  `ActualAmount` tinyint NOT NULL,
  `closedate` tinyint NOT NULL,
  `salesperson` tinyint NOT NULL,
  `closeDatePotential` tinyint NOT NULL,
  `opportunityStatusKey` tinyint NOT NULL,
  `opportunityStatus` tinyint NOT NULL,
  `leadSource` tinyint NOT NULL,
  `opportunityStep` tinyint NOT NULL,
  `leadStage` tinyint NOT NULL,
  `probability` tinyint NOT NULL,
  `SO_No` tinyint NOT NULL,
  `accountInSales` tinyint NOT NULL,
  `accNameUrl` tinyint NOT NULL,
  `contactInSales` tinyint NOT NULL,
  `pconNameUrl` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `primaryContact` tinyint NOT NULL,
  `salesRanking` tinyint NOT NULL,
  `salesRankingImage` tinyint NOT NULL,
  `phone` tinyint NOT NULL,
  `state` tinyint NOT NULL,
  `last_action` tinyint NOT NULL,
  `last_email` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_lastemail`
--

DROP TABLE IF EXISTS `v_lastemail`;
/*!50001 DROP VIEW IF EXISTS `v_lastemail`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_lastemail` (
  `organization_id` tinyint NOT NULL,
  `company_id` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `last_action` tinyint NOT NULL,
  `last_action_type` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_contactlastactivity`
--

DROP TABLE IF EXISTS `v_contactlastactivity`;
/*!50001 DROP VIEW IF EXISTS `v_contactlastactivity`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_contactlastactivity` (
  `last_action` tinyint NOT NULL,
  `last_action_type` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_myticketsimplegrpgrid`
--

DROP TABLE IF EXISTS `v_myticketsimplegrpgrid`;
/*!50001 DROP VIEW IF EXISTS `v_myticketsimplegrpgrid`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_myticketsimplegrpgrid` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `ticketID` tinyint NOT NULL,
  `recdDate` tinyint NOT NULL,
  `recdTime` tinyint NOT NULL,
  `ticketTitle` tinyint NOT NULL,
  `assignedType` tinyint NOT NULL,
  `assignedTo` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `ticketType` tinyint NOT NULL,
  `urgency` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `pconName` tinyint NOT NULL,
  `pconNameUrl` tinyint NOT NULL,
  `phone` tinyint NOT NULL,
  `email` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_allactionbytype`
--

DROP TABLE IF EXISTS `v_allactionbytype`;
/*!50001 DROP VIEW IF EXISTS `v_allactionbytype`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_allactionbytype` (
  `organization_id` tinyint NOT NULL,
  `company_id` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `last_action` tinyint NOT NULL,
  `last_action_type` tinyint NOT NULL,
  `detail` tinyint NOT NULL,
  `adate` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `instanceId` tinyint NOT NULL,
  `moduleUname` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_salesoppmgrresultsgrid`
--

DROP TABLE IF EXISTS `v_salesoppmgrresultsgrid`;
/*!50001 DROP VIEW IF EXISTS `v_salesoppmgrresultsgrid`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_salesoppmgrresultsgrid` (
  `parentName` tinyint NOT NULL,
  `parentNameUrl` tinyint NOT NULL,
  `primcontactName` tinyint NOT NULL,
  `oppId` tinyint NOT NULL,
  `oppName` tinyint NOT NULL,
  `SalesPerson` tinyint NOT NULL,
  `SO_No` tinyint NOT NULL,
  `DateCreated` tinyint NOT NULL,
  `EstCloseDate` tinyint NOT NULL,
  `EstAmount` tinyint NOT NULL,
  `EstProb` tinyint NOT NULL,
  `closedate` tinyint NOT NULL,
  `closeamount` tinyint NOT NULL,
  `Account` tinyint NOT NULL,
  `contact` tinyint NOT NULL,
  `primcontact` tinyint NOT NULL,
  `opportunityStatus` tinyint NOT NULL,
  `SalesStage` tinyint NOT NULL,
  `LeadStage` tinyint NOT NULL,
  `SalesStageName` tinyint NOT NULL,
  `LeadStageName` tinyint NOT NULL,
  `region` tinyint NOT NULL,
  `lsource` tinyint NOT NULL,
  `opptype` tinyint NOT NULL,
  `campaign` tinyint NOT NULL,
  `updateDate` tinyint NOT NULL,
  `salesParent` tinyint NOT NULL,
  `PARENT_MODULE_UNAME` tinyint NOT NULL,
  `PARENT_INSTANCE_ID` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `instanceId` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_salesdashboardbystage`
--

DROP TABLE IF EXISTS `v_salesdashboardbystage`;
/*!50001 DROP VIEW IF EXISTS `v_salesdashboardbystage`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_salesdashboardbystage` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `ACCESS` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `row_num` tinyint NOT NULL,
  `salesStage` tinyint NOT NULL,
  `salesStatus` tinyint NOT NULL,
  `leadStageCount` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `avgTime` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_campanalysisresultsgrid`
--

DROP TABLE IF EXISTS `v_campanalysisresultsgrid`;
/*!50001 DROP VIEW IF EXISTS `v_campanalysisresultsgrid`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_campanalysisresultsgrid` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `PARENT_INSTANCE_ID` tinyint NOT NULL,
  `PARENT_MODULE_UNAME` tinyint NOT NULL,
  `CampaignName` tinyint NOT NULL,
  `CampaignNameUrl` tinyint NOT NULL,
  `Stat` tinyint NOT NULL,
  `Type` tinyint NOT NULL,
  `Budget` tinyint NOT NULL,
  `Actual` tinyint NOT NULL,
  `StartDate` tinyint NOT NULL,
  `StopDate` tinyint NOT NULL,
  `EstTarget` tinyint NOT NULL,
  `CampaignManager` tinyint NOT NULL,
  `CampaignManagerName` tinyint NOT NULL,
  `SalesOpportunities` tinyint NOT NULL,
  `EstPotentialValue` tinyint NOT NULL,
  `ActualValue` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `TypeLKEY` tinyint NOT NULL,
  `StatusLKEY` tinyint NOT NULL,
  `rev` tinyint NOT NULL,
  `closeso` tinyint NOT NULL,
  `totaldays` tinyint NOT NULL,
  `cr` tinyint NOT NULL,
  `ave` tinyint NOT NULL,
  `rpm` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_grouplist`
--

DROP TABLE IF EXISTS `v_grouplist`;
/*!50001 DROP VIEW IF EXISTS `v_grouplist`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_grouplist` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `MODULE_UNAME` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_ticketsforaccount`
--

DROP TABLE IF EXISTS `v_ticketsforaccount`;
/*!50001 DROP VIEW IF EXISTS `v_ticketsforaccount`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_ticketsforaccount` (
  `ticketTitle` tinyint NOT NULL,
  `ticketId` tinyint NOT NULL,
  `severity` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `typeCall` tinyint NOT NULL,
  `urgency` tinyint NOT NULL,
  `pconNameUrl` tinyint NOT NULL,
  `phone` tinyint NOT NULL,
  `email` tinyint NOT NULL,
  `acctName` tinyint NOT NULL,
  `recdDate` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_allemail`
--

DROP TABLE IF EXISTS `v_allemail`;
/*!50001 DROP VIEW IF EXISTS `v_allemail`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_allemail` (
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `update_date` tinyint NOT NULL,
  `last_action` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_homepagelist`
--

DROP TABLE IF EXISTS `v_homepagelist`;
/*!50001 DROP VIEW IF EXISTS `v_homepagelist`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_homepagelist` (
  `module_uname` tinyint NOT NULL,
  `display_name` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_ticketsimpletopcustbypriority`
--

DROP TABLE IF EXISTS `v_ticketsimpletopcustbypriority`;
/*!50001 DROP VIEW IF EXISTS `v_ticketsimpletopcustbypriority`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_ticketsimpletopcustbypriority` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `row_number` tinyint NOT NULL,
  `numTickets` tinyint NOT NULL,
  `priority` tinyint NOT NULL,
  `parentName` tinyint NOT NULL,
  `parentNameUrl` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_dashboard_email_sorted`
--

DROP TABLE IF EXISTS `v_dashboard_email_sorted`;
/*!50001 DROP VIEW IF EXISTS `v_dashboard_email_sorted`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_dashboard_email_sorted` (
  `row_num` tinyint NOT NULL,
  `instanceId` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `organization_id` tinyint NOT NULL,
  `company_id` tinyint NOT NULL,
  `subject` tinyint NOT NULL,
  `sdate` tinyint NOT NULL,
  `email_name` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `securityLevel` tinyint NOT NULL,
  `user_id` tinyint NOT NULL,
  `user_name` tinyint NOT NULL,
  `sent_time` tinyint NOT NULL,
  `email_from` tinyint NOT NULL,
  `email_to` tinyint NOT NULL,
  `moduleUname` tinyint NOT NULL,
  `emailType` tinyint NOT NULL,
  `entity_type` tinyint NOT NULL,
  `reply` tinyint NOT NULL,
  `replyAll` tinyint NOT NULL,
  `forward` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_campaignanalysischarts`
--

DROP TABLE IF EXISTS `v_campaignanalysischarts`;
/*!50001 DROP VIEW IF EXISTS `v_campaignanalysischarts`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_campaignanalysischarts` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `PARENT_INSTANCE_ID` tinyint NOT NULL,
  `PARENT_MODULE_UNAME` tinyint NOT NULL,
  `CampaignName` tinyint NOT NULL,
  `Budget` tinyint NOT NULL,
  `Actual` tinyint NOT NULL,
  `EstPotentialValue` tinyint NOT NULL,
  `ActualValue` tinyint NOT NULL,
  `Status` tinyint NOT NULL,
  `EstTarget` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `security_level` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_accountallemails`
--

DROP TABLE IF EXISTS `v_accountallemails`;
/*!50001 DROP VIEW IF EXISTS `v_accountallemails`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_accountallemails` (
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `emailModName` tinyint NOT NULL,
  `emailModId` tinyint NOT NULL,
  `update_date` tinyint NOT NULL,
  `last_action` tinyint NOT NULL,
  `parent_instance_id` tinyint NOT NULL,
  `parent_module_uname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_campaignanalysisroi`
--

DROP TABLE IF EXISTS `v_campaignanalysisroi`;
/*!50001 DROP VIEW IF EXISTS `v_campaignanalysisroi`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_campaignanalysisroi` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `PARENT_INSTANCE_ID` tinyint NOT NULL,
  `PARENT_MODULE_UNAME` tinyint NOT NULL,
  `CampaignName` tinyint NOT NULL,
  `Budget` tinyint NOT NULL,
  `Actual` tinyint NOT NULL,
  `EstTarget` tinyint NOT NULL,
  `EstPotentialValue` tinyint NOT NULL,
  `ActualValue` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `security_level` tinyint NOT NULL,
  `ROI` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_util_views`
--

DROP TABLE IF EXISTS `v_util_views`;
/*!50001 DROP VIEW IF EXISTS `v_util_views`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_util_views` (
  `view_name` tinyint NOT NULL,
  `reference` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_tickettopcustbyage`
--

DROP TABLE IF EXISTS `v_tickettopcustbyage`;
/*!50001 DROP VIEW IF EXISTS `v_tickettopcustbyage`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_tickettopcustbyage` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `row_number` tinyint NOT NULL,
  `Age` tinyint NOT NULL,
  `parentName` tinyint NOT NULL,
  `parentNameUrl` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_util_storedproc`
--

DROP TABLE IF EXISTS `v_util_storedproc`;
/*!50001 DROP VIEW IF EXISTS `v_util_storedproc`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_util_storedproc` (
  `sp_name` tinyint NOT NULL,
  `reference` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_acctmaingrid`
--

DROP TABLE IF EXISTS `v_acctmaingrid`;
/*!50001 DROP VIEW IF EXISTS `v_acctmaingrid`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_acctmaingrid` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `accMgr` tinyint NOT NULL,
  `accountType` tinyint NOT NULL,
  `accountName` tinyint NOT NULL,
  `displayFieldName` tinyint NOT NULL,
  `industry` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `website1` tinyint NOT NULL,
  `last_action` tinyint NOT NULL,
  `last_email` tinyint NOT NULL,
  `ctname` tinyint NOT NULL,
  `ctnameurl` tinyint NOT NULL,
  `ctphone` tinyint NOT NULL,
  `ctemail` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `email` tinyint NOT NULL,
  `securityLevel` tinyint NOT NULL,
  `state` tinyint NOT NULL,
  `mainphone` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_leadsleadstatus`
--

DROP TABLE IF EXISTS `v_leadsleadstatus`;
/*!50001 DROP VIEW IF EXISTS `v_leadsleadstatus`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_leadsleadstatus` (
  `parentModuleUname` tinyint NOT NULL,
  `parentinstanceId` tinyint NOT NULL,
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `security_level` tinyint NOT NULL,
  `create_user` tinyint NOT NULL,
  `leadStatus` tinyint NOT NULL,
  `startDate` tinyint NOT NULL,
  `endDate` tinyint NOT NULL,
  `noOfDays` tinyint NOT NULL,
  `lstage` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_contactallemails`
--

DROP TABLE IF EXISTS `v_contactallemails`;
/*!50001 DROP VIEW IF EXISTS `v_contactallemails`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_contactallemails` (
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `emailModName` tinyint NOT NULL,
  `emailModId` tinyint NOT NULL,
  `update_date` tinyint NOT NULL,
  `last_action` tinyint NOT NULL,
  `parent_instance_id` tinyint NOT NULL,
  `parent_module_uname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_history_activity`
--

DROP TABLE IF EXISTS `v_history_activity`;
/*!50001 DROP VIEW IF EXISTS `v_history_activity`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_history_activity` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `ACTIVITY_NAME` tinyint NOT NULL,
  `ACTIVITY_TYPE` tinyint NOT NULL,
  `RESULT` tinyint NOT NULL,
  `DESCRIPTION` tinyint NOT NULL,
  `THRU_DATE` tinyint NOT NULL,
  `FROM_DATE` tinyint NOT NULL,
  `STATUS` tinyint NOT NULL,
  `PRIORITY` tinyint NOT NULL,
  `NOTES` tinyint NOT NULL,
  `OWNER` tinyint NOT NULL,
  `ACCESS` tinyint NOT NULL,
  `SECURITY_LEVEL` tinyint NOT NULL,
  `moduleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_userlist`
--

DROP TABLE IF EXISTS `v_userlist`;
/*!50001 DROP VIEW IF EXISTS `v_userlist`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_userlist` (
  `organization_id` tinyint NOT NULL,
  `company_id` tinyint NOT NULL,
  `instanceId` tinyint NOT NULL,
  `name` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_sales_dashboard`
--

DROP TABLE IF EXISTS `v_sales_dashboard`;
/*!50001 DROP VIEW IF EXISTS `v_sales_dashboard`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_sales_dashboard` (
  `INSTANCE_ID` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `PARENT_MODULE_UNAME` tinyint NOT NULL,
  `PARENT_INSTANCE_ID` tinyint NOT NULL,
  `closeamount` tinyint NOT NULL,
  `EstAmount` tinyint NOT NULL,
  `count` tinyint NOT NULL,
  `closedate` tinyint NOT NULL,
  `EstCloseDate` tinyint NOT NULL,
  `DateCreated` tinyint NOT NULL,
  `Status` tinyint NOT NULL,
  `SalesPersonID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_myticketsimpleindvgrid`
--

DROP TABLE IF EXISTS `v_myticketsimpleindvgrid`;
/*!50001 DROP VIEW IF EXISTS `v_myticketsimpleindvgrid`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_myticketsimpleindvgrid` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `ticketID` tinyint NOT NULL,
  `recdDate` tinyint NOT NULL,
  `recdTime` tinyint NOT NULL,
  `ticketTitle` tinyint NOT NULL,
  `assignedType` tinyint NOT NULL,
  `assignedTo` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `ticketType` tinyint NOT NULL,
  `urgency` tinyint NOT NULL,
  `pconName` tinyint NOT NULL,
  `pconNameUrl` tinyint NOT NULL,
  `phone` tinyint NOT NULL,
  `email` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `state` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_util_criteria`
--

DROP TABLE IF EXISTS `v_util_criteria`;
/*!50001 DROP VIEW IF EXISTS `v_util_criteria`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_util_criteria` (
  `CRITERIA_NAME` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_campaignmgrgrid`
--

DROP TABLE IF EXISTS `v_campaignmgrgrid`;
/*!50001 DROP VIEW IF EXISTS `v_campaignmgrgrid`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_campaignmgrgrid` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `PARENT_INSTANCE_ID` tinyint NOT NULL,
  `PARENT_MODULE_UNAME` tinyint NOT NULL,
  `CampaignName` tinyint NOT NULL,
  `CampaignNameUrl` tinyint NOT NULL,
  `Stat` tinyint NOT NULL,
  `Type` tinyint NOT NULL,
  `Budget` tinyint NOT NULL,
  `Actual` tinyint NOT NULL,
  `StartDate` tinyint NOT NULL,
  `StopDate` tinyint NOT NULL,
  `EstTarget` tinyint NOT NULL,
  `CampaignManager` tinyint NOT NULL,
  `CampaignManagerName` tinyint NOT NULL,
  `SalesOpportunities` tinyint NOT NULL,
  `EstPotentialValue` tinyint NOT NULL,
  `ActualValue` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `CREATE_USER` tinyint NOT NULL,
  `UPDATE_USER` tinyint NOT NULL,
  `CREATE_DATE` tinyint NOT NULL,
  `UPDATE_DATE` tinyint NOT NULL,
  `TypeLKEY` tinyint NOT NULL,
  `StatusLKEY` tinyint NOT NULL,
  `rev` tinyint NOT NULL,
  `closeso` tinyint NOT NULL,
  `totaldays` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_sales_personcnt`
--

DROP TABLE IF EXISTS `v_sales_personcnt`;
/*!50001 DROP VIEW IF EXISTS `v_sales_personcnt`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_sales_personcnt` (
  `INSTANCE_ID` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `PARENT_MODULE_UNAME` tinyint NOT NULL,
  `PARENT_INSTANCE_ID` tinyint NOT NULL,
  `closeamount` tinyint NOT NULL,
  `EstAmount` tinyint NOT NULL,
  `closedate` tinyint NOT NULL,
  `EstCloseDate` tinyint NOT NULL,
  `DateCreated` tinyint NOT NULL,
  `Status` tinyint NOT NULL,
  `count` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_customerservice_users`
--

DROP TABLE IF EXISTS `v_customerservice_users`;
/*!50001 DROP VIEW IF EXISTS `v_customerservice_users`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_customerservice_users` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `UName` tinyint NOT NULL,
  `Name` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_accountmaxactivity`
--

DROP TABLE IF EXISTS `v_accountmaxactivity`;
/*!50001 DROP VIEW IF EXISTS `v_accountmaxactivity`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_accountmaxactivity` (
  `parent_module_uname` tinyint NOT NULL,
  `parent_instance_id` tinyint NOT NULL,
  `update_date` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_manager_list`
--

DROP TABLE IF EXISTS `v_manager_list`;
/*!50001 DROP VIEW IF EXISTS `v_manager_list`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_manager_list` (
  `organization_id` tinyint NOT NULL,
  `company_id` tinyint NOT NULL,
  `USER_ID` tinyint NOT NULL,
  `FIRST_NAME` tinyint NOT NULL,
  `last_name` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_history_audit`
--

DROP TABLE IF EXISTS `v_history_audit`;
/*!50001 DROP VIEW IF EXISTS `v_history_audit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_history_audit` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `AUDIT_LEVEL` tinyint NOT NULL,
  `SESSION_ID` tinyint NOT NULL,
  `DATE_TIME_GROUP` tinyint NOT NULL,
  `USER_UNAME` tinyint NOT NULL,
  `USER_IP` tinyint NOT NULL,
  `USER_ACTION` tinyint NOT NULL,
  `APPLICATION_NAME` tinyint NOT NULL,
  `TYPE_OF_EVENT` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `PARENT_ENTITY_TYPE` tinyint NOT NULL,
  `PARENT_ENTITY_ID` tinyint NOT NULL,
  `ACTION_STATUS` tinyint NOT NULL,
  `TIME_TAKEN` tinyint NOT NULL,
  `attribute_name` tinyint NOT NULL,
  `attrValue` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_customerservice_mgrs`
--

DROP TABLE IF EXISTS `v_customerservice_mgrs`;
/*!50001 DROP VIEW IF EXISTS `v_customerservice_mgrs`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_customerservice_mgrs` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `Name` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_allcompletedactivity`
--

DROP TABLE IF EXISTS `v_allcompletedactivity`;
/*!50001 DROP VIEW IF EXISTS `v_allcompletedactivity`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_allcompletedactivity` (
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `activityModName` tinyint NOT NULL,
  `activityModId` tinyint NOT NULL,
  `update_date` tinyint NOT NULL,
  `activity_type` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_countylist`
--

DROP TABLE IF EXISTS `v_countylist`;
/*!50001 DROP VIEW IF EXISTS `v_countylist`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_countylist` (
  `name` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_rpt_tickets_simple`
--

DROP TABLE IF EXISTS `v_rpt_tickets_simple`;
/*!50001 DROP VIEW IF EXISTS `v_rpt_tickets_simple`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_rpt_tickets_simple` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `ticketID` tinyint NOT NULL,
  `recdDate` tinyint NOT NULL,
  `recdTime` tinyint NOT NULL,
  `dateNeeded` tinyint NOT NULL,
  `timeNeeded` tinyint NOT NULL,
  `ticketTitle` tinyint NOT NULL,
  `severity` tinyint NOT NULL,
  `ticketStatus` tinyint NOT NULL,
  `ticketType` tinyint NOT NULL,
  `urgency` tinyint NOT NULL,
  `category` tinyint NOT NULL,
  `assignedTo` tinyint NOT NULL,
  `touchPoint` tinyint NOT NULL,
  `ticketMgr` tinyint NOT NULL,
  `pconid` tinyint NOT NULL,
  `account` tinyint NOT NULL,
  `contact` tinyint NOT NULL,
  `updateDate` tinyint NOT NULL,
  `createDate` tinyint NOT NULL,
  `compDate` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_salesaccountcontactlist`
--

DROP TABLE IF EXISTS `v_salesaccountcontactlist`;
/*!50001 DROP VIEW IF EXISTS `v_salesaccountcontactlist`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_salesaccountcontactlist` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `security_level` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `contactType` tinyint NOT NULL,
  `email` tinyint NOT NULL,
  `full_name` tinyint NOT NULL,
  `business` tinyint NOT NULL,
  `cell` tinyint NOT NULL,
  `title` tinyint NOT NULL,
  `ext` tinyint NOT NULL,
  `PARENT_MODULE_UNAME` tinyint NOT NULL,
  `PARENT_INSTANCE_ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_calendarsettingforuser`
--

DROP TABLE IF EXISTS `v_calendarsettingforuser`;
/*!50001 DROP VIEW IF EXISTS `v_calendarsettingforuser`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_calendarsettingforuser` (
  `calendar_uname` tinyint NOT NULL,
  `user_uname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_calendarsettinguid`
--

DROP TABLE IF EXISTS `v_calendarsettinguid`;
/*!50001 DROP VIEW IF EXISTS `v_calendarsettinguid`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_calendarsettinguid` (
  `user_id` tinyint NOT NULL,
  `calendar_setting_uname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_tickettopcustbyopencases`
--

DROP TABLE IF EXISTS `v_tickettopcustbyopencases`;
/*!50001 DROP VIEW IF EXISTS `v_tickettopcustbyopencases`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_tickettopcustbyopencases` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `row_number` tinyint NOT NULL,
  `numTickets` tinyint NOT NULL,
  `parentName` tinyint NOT NULL,
  `parentNameUrl` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_ticket_parts`
--

DROP TABLE IF EXISTS `v_ticket_parts`;
/*!50001 DROP VIEW IF EXISTS `v_ticket_parts`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_ticket_parts` (
  `instanceId` tinyint NOT NULL,
  `TTId` tinyint NOT NULL,
  `TaskId` tinyint NOT NULL,
  `pcode` tinyint NOT NULL,
  `pdesc` tinyint NOT NULL,
  `pnum` tinyint NOT NULL,
  `psn1` tinyint NOT NULL,
  `psn2` tinyint NOT NULL,
  `totalCost` tinyint NOT NULL,
  `psla` tinyint NOT NULL,
  `prma` tinyint NOT NULL,
  `billable` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `security_level` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_util_eventlist`
--

DROP TABLE IF EXISTS `v_util_eventlist`;
/*!50001 DROP VIEW IF EXISTS `v_util_eventlist`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_util_eventlist` (
  `module_uname` tinyint NOT NULL,
  `event_name` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_leads`
--

DROP TABLE IF EXISTS `v_leads`;
/*!50001 DROP VIEW IF EXISTS `v_leads`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_leads` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `ACCESS` tinyint NOT NULL,
  `PARENT_MODULE_UNAME` tinyint NOT NULL,
  `PARENT_INSTANCE_ID` tinyint NOT NULL,
  `Account` tinyint NOT NULL,
  `Address` tinyint NOT NULL,
  `AssignedDate` tinyint NOT NULL,
  `AssignedTo` tinyint NOT NULL,
  `City` tinyint NOT NULL,
  `email` tinyint NOT NULL,
  `firstName` tinyint NOT NULL,
  `lastName` tinyint NOT NULL,
  `leadStatus` tinyint NOT NULL,
  `RecordsCreated` tinyint NOT NULL,
  `leadRanking` tinyint NOT NULL,
  `leadRankingImage` tinyint NOT NULL,
  `last_action` tinyint NOT NULL,
  `last_email` tinyint NOT NULL,
  `Phone` tinyint NOT NULL,
  `ReceivedDate` tinyint NOT NULL,
  `source` tinyint NOT NULL,
  `State` tinyint NOT NULL,
  `SalesStage` tinyint NOT NULL,
  `salesStageStatus` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `scriptCall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_contactmaingrid`
--

DROP TABLE IF EXISTS `v_contactmaingrid`;
/*!50001 DROP VIEW IF EXISTS `v_contactmaingrid`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_contactmaingrid` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `firstName` tinyint NOT NULL,
  `lastName` tinyint NOT NULL,
  `accountInContact` tinyint NOT NULL,
  `displayFieldName` tinyint NOT NULL,
  `department` tinyint NOT NULL,
  `title` tinyint NOT NULL,
  `business` tinyint NOT NULL,
  `mobile` tinyint NOT NULL,
  `email1` tinyint NOT NULL,
  `contactRole` tinyint NOT NULL,
  `accMgrId` tinyint NOT NULL,
  `manager` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `ACCESS` tinyint NOT NULL,
  `last_action` tinyint NOT NULL,
  `last_email` tinyint NOT NULL,
  `securityLevel` tinyint NOT NULL,
  `state` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_reassign_users`
--

DROP TABLE IF EXISTS `v_reassign_users`;
/*!50001 DROP VIEW IF EXISTS `v_reassign_users`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_reassign_users` (
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `lkey` tinyint NOT NULL,
  `lvalue` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_salesclosedoppcurrmonth`
--

DROP TABLE IF EXISTS `v_salesclosedoppcurrmonth`;
/*!50001 DROP VIEW IF EXISTS `v_salesclosedoppcurrmonth`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_salesclosedoppcurrmonth` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `opportunityName` tinyint NOT NULL,
  `row_number` tinyint NOT NULL,
  `sumAmount` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_user_groups`
--

DROP TABLE IF EXISTS `v_user_groups`;
/*!50001 DROP VIEW IF EXISTS `v_user_groups`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_user_groups` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `name` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_leadsdashboardbystage`
--

DROP TABLE IF EXISTS `v_leadsdashboardbystage`;
/*!50001 DROP VIEW IF EXISTS `v_leadsdashboardbystage`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_leadsdashboardbystage` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `ACCESS` tinyint NOT NULL,
  `leadParentStage` tinyint NOT NULL,
  `leadStage` tinyint NOT NULL,
  `leadStageCount` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `percentage` tinyint NOT NULL,
  `avgLeadTime` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_util_event`
--

DROP TABLE IF EXISTS `v_util_event`;
/*!50001 DROP VIEW IF EXISTS `v_util_event`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_util_event` (
  `EVENT_NAME` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_salesperson_list`
--

DROP TABLE IF EXISTS `v_salesperson_list`;
/*!50001 DROP VIEW IF EXISTS `v_salesperson_list`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_salesperson_list` (
  `organization_id` tinyint NOT NULL,
  `company_id` tinyint NOT NULL,
  `USER_ID` tinyint NOT NULL,
  `USER_UNAME` tinyint NOT NULL,
  `FIRST_NAME` tinyint NOT NULL,
  `LAST_NAME` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_calendarsettingforoutlook`
--

DROP TABLE IF EXISTS `v_calendarsettingforoutlook`;
/*!50001 DROP VIEW IF EXISTS `v_calendarsettingforoutlook`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_calendarsettingforoutlook` (
  `calendar_uname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_util_grids`
--

DROP TABLE IF EXISTS `v_util_grids`;
/*!50001 DROP VIEW IF EXISTS `v_util_grids`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_util_grids` (
  `GRID_UNAME` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_lastactivity`
--

DROP TABLE IF EXISTS `v_lastactivity`;
/*!50001 DROP VIEW IF EXISTS `v_lastactivity`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_lastactivity` (
  `last_action` tinyint NOT NULL,
  `last_action_type` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_dashboard_email_sent`
--

DROP TABLE IF EXISTS `v_dashboard_email_sent`;
/*!50001 DROP VIEW IF EXISTS `v_dashboard_email_sent`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_dashboard_email_sent` (
  `row_num` tinyint NOT NULL,
  `instanceId` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `organization_id` tinyint NOT NULL,
  `company_id` tinyint NOT NULL,
  `subject` tinyint NOT NULL,
  `sdate` tinyint NOT NULL,
  `email_name` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `securityLevel` tinyint NOT NULL,
  `user_id` tinyint NOT NULL,
  `user_name` tinyint NOT NULL,
  `sent_time` tinyint NOT NULL,
  `email_from` tinyint NOT NULL,
  `email_to` tinyint NOT NULL,
  `moduleUname` tinyint NOT NULL,
  `emailType` tinyint NOT NULL,
  `entity_type` tinyint NOT NULL,
  `reply` tinyint NOT NULL,
  `replyAll` tinyint NOT NULL,
  `forward` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_util_lookup`
--

DROP TABLE IF EXISTS `v_util_lookup`;
/*!50001 DROP VIEW IF EXISTS `v_util_lookup`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_util_lookup` (
  `criteria_name` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_ticketsimplemaingrid`
--

DROP TABLE IF EXISTS `v_ticketsimplemaingrid`;
/*!50001 DROP VIEW IF EXISTS `v_ticketsimplemaingrid`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_ticketsimplemaingrid` (
  `row_num` tinyint NOT NULL,
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `ticketID` tinyint NOT NULL,
  `recdDate` tinyint NOT NULL,
  `recdTime` tinyint NOT NULL,
  `ticketTitle` tinyint NOT NULL,
  `completeTime` tinyint NOT NULL,
  `assignedTo` tinyint NOT NULL,
  `assignedToIndividual` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `typeCall` tinyint NOT NULL,
  `urgency` tinyint NOT NULL,
  `account` tinyint NOT NULL,
  `pconName` tinyint NOT NULL,
  `pconNameUrl` tinyint NOT NULL,
  `phone` tinyint NOT NULL,
  `email` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `state` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_salesopenopportunities`
--

DROP TABLE IF EXISTS `v_salesopenopportunities`;
/*!50001 DROP VIEW IF EXISTS `v_salesopenopportunities`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_salesopenopportunities` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `opportunityName` tinyint NOT NULL,
  `row_number` tinyint NOT NULL,
  `sumAmount` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_accountlastactivity`
--

DROP TABLE IF EXISTS `v_accountlastactivity`;
/*!50001 DROP VIEW IF EXISTS `v_accountlastactivity`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_accountlastactivity` (
  `last_action` tinyint NOT NULL,
  `last_action_type` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_contactmaxactivity`
--

DROP TABLE IF EXISTS `v_contactmaxactivity`;
/*!50001 DROP VIEW IF EXISTS `v_contactmaxactivity`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_contactmaxactivity` (
  `parent_module_uname` tinyint NOT NULL,
  `parent_instance_id` tinyint NOT NULL,
  `update_date` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_ticket_line_items`
--

DROP TABLE IF EXISTS `v_ticket_line_items`;
/*!50001 DROP VIEW IF EXISTS `v_ticket_line_items`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_ticket_line_items` (
  `instanceId` tinyint NOT NULL,
  `ttid` tinyint NOT NULL,
  `TaskId` tinyint NOT NULL,
  `ttdate` tinyint NOT NULL,
  `ttstart` tinyint NOT NULL,
  `ttstop` tinyint NOT NULL,
  `tttotal` tinyint NOT NULL,
  `ttaction` tinyint NOT NULL,
  `ttstatus` tinyint NOT NULL,
  `ttworkby` tinyint NOT NULL,
  `fname` tinyint NOT NULL,
  `lname` tinyint NOT NULL,
  `ttproblem` tinyint NOT NULL,
  `ttresolution` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `security_level` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_sales_report`
--

DROP TABLE IF EXISTS `v_sales_report`;
/*!50001 DROP VIEW IF EXISTS `v_sales_report`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_sales_report` (
  `INSTANCE_ID` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `PARENT_MODULE_UNAME` tinyint NOT NULL,
  `PARENT_INSTANCE_ID` tinyint NOT NULL,
  `oppName` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `account_status` tinyint NOT NULL,
  `EstProb` tinyint NOT NULL,
  `closeamount` tinyint NOT NULL,
  `EstAmount` tinyint NOT NULL,
  `closedate` tinyint NOT NULL,
  `EstCloseDate` tinyint NOT NULL,
  `DateCreated` tinyint NOT NULL,
  `SO_No` tinyint NOT NULL,
  `NOTES` tinyint NOT NULL,
  `last_action` tinyint NOT NULL,
  `ManagerId` tinyint NOT NULL,
  `OPSTAGE` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_ticketsimpleavgrestimebypriority`
--

DROP TABLE IF EXISTS `v_ticketsimpleavgrestimebypriority`;
/*!50001 DROP VIEW IF EXISTS `v_ticketsimpleavgrestimebypriority`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_ticketsimpleavgrestimebypriority` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `row_number` tinyint NOT NULL,
  `priority` tinyint NOT NULL,
  `age` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_salescloseddealleader`
--

DROP TABLE IF EXISTS `v_salescloseddealleader`;
/*!50001 DROP VIEW IF EXISTS `v_salescloseddealleader`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_salescloseddealleader` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `row_number` tinyint NOT NULL,
  `SalesPerson` tinyint NOT NULL,
  `sumAmount` tinyint NOT NULL,
  `numRecords` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_contactlastemail`
--

DROP TABLE IF EXISTS `v_contactlastemail`;
/*!50001 DROP VIEW IF EXISTS `v_contactlastemail`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_contactlastemail` (
  `last_action` tinyint NOT NULL,
  `last_action_type` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_groupmembers`
--

DROP TABLE IF EXISTS `v_groupmembers`;
/*!50001 DROP VIEW IF EXISTS `v_groupmembers`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_groupmembers` (
  `GROUP_ID` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `addedBy` tinyint NOT NULL,
  `addedDate` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `instanceId` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_maxactivity`
--

DROP TABLE IF EXISTS `v_maxactivity`;
/*!50001 DROP VIEW IF EXISTS `v_maxactivity`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_maxactivity` (
  `activityModName` tinyint NOT NULL,
  `activityModId` tinyint NOT NULL,
  `update_date` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_modules`
--

DROP TABLE IF EXISTS `v_modules`;
/*!50001 DROP VIEW IF EXISTS `v_modules`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_modules` (
  `MODULE_UNAME` tinyint NOT NULL,
  `displayModule` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_salesclosedopportunities`
--

DROP TABLE IF EXISTS `v_salesclosedopportunities`;
/*!50001 DROP VIEW IF EXISTS `v_salesclosedopportunities`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_salesclosedopportunities` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `opportunityName` tinyint NOT NULL,
  `row_number` tinyint NOT NULL,
  `sumAmount` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_salesoppresultsgrid`
--

DROP TABLE IF EXISTS `v_salesoppresultsgrid`;
/*!50001 DROP VIEW IF EXISTS `v_salesoppresultsgrid`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_salesoppresultsgrid` (
  `parentName` tinyint NOT NULL,
  `primcontactName` tinyint NOT NULL,
  `oppName` tinyint NOT NULL,
  `SalesPerson` tinyint NOT NULL,
  `SO_No` tinyint NOT NULL,
  `DateCreated` tinyint NOT NULL,
  `SalesStageName` tinyint NOT NULL,
  `LeadStageName` tinyint NOT NULL,
  `EstCloseDate` tinyint NOT NULL,
  `EstAmount` tinyint NOT NULL,
  `EstProb` tinyint NOT NULL,
  `closedate` tinyint NOT NULL,
  `closeamount` tinyint NOT NULL,
  `Account` tinyint NOT NULL,
  `contact` tinyint NOT NULL,
  `primcontact` tinyint NOT NULL,
  `opportunityStatus` tinyint NOT NULL,
  `SalesStage` tinyint NOT NULL,
  `LeadStage` tinyint NOT NULL,
  `region` tinyint NOT NULL,
  `lsource` tinyint NOT NULL,
  `opptype` tinyint NOT NULL,
  `campaign` tinyint NOT NULL,
  `updateDate` tinyint NOT NULL,
  `salesParent` tinyint NOT NULL,
  `SalesPersonID` tinyint NOT NULL,
  `ManagerId` tinyint NOT NULL,
  `SalesMgr` tinyint NOT NULL,
  `PARENT_MODULE_UNAME` tinyint NOT NULL,
  `PARENT_INSTANCE_ID` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `instanceId` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_dashboard_email`
--

DROP TABLE IF EXISTS `v_dashboard_email`;
/*!50001 DROP VIEW IF EXISTS `v_dashboard_email`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_dashboard_email` (
  `row_num` tinyint NOT NULL,
  `instanceId` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `organization_id` tinyint NOT NULL,
  `company_id` tinyint NOT NULL,
  `subject` tinyint NOT NULL,
  `sdate` tinyint NOT NULL,
  `email_name` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `securityLevel` tinyint NOT NULL,
  `user_id` tinyint NOT NULL,
  `user_name` tinyint NOT NULL,
  `sent_time` tinyint NOT NULL,
  `email_from` tinyint NOT NULL,
  `email_to` tinyint NOT NULL,
  `moduleUname` tinyint NOT NULL,
  `emailType` tinyint NOT NULL,
  `entity_type` tinyint NOT NULL,
  `reply` tinyint NOT NULL,
  `replyAll` tinyint NOT NULL,
  `forward` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_activestdproblems`
--

DROP TABLE IF EXISTS `v_activestdproblems`;
/*!50001 DROP VIEW IF EXISTS `v_activestdproblems`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_activestdproblems` (
  `instanceId` tinyint NOT NULL,
  `title` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_salesopenoppcurrmonth`
--

DROP TABLE IF EXISTS `v_salesopenoppcurrmonth`;
/*!50001 DROP VIEW IF EXISTS `v_salesopenoppcurrmonth`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_salesopenoppcurrmonth` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `opportunityName` tinyint NOT NULL,
  `row_number` tinyint NOT NULL,
  `sumAmount` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_accountmaxemails`
--

DROP TABLE IF EXISTS `v_accountmaxemails`;
/*!50001 DROP VIEW IF EXISTS `v_accountmaxemails`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_accountmaxemails` (
  `parent_module_uname` tinyint NOT NULL,
  `parent_instance_id` tinyint NOT NULL,
  `update_date` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_salesoppstages`
--

DROP TABLE IF EXISTS `v_salesoppstages`;
/*!50001 DROP VIEW IF EXISTS `v_salesoppstages`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_salesoppstages` (
  `parentModuleUname` tinyint NOT NULL,
  `parentinstanceId` tinyint NOT NULL,
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `security_level` tinyint NOT NULL,
  `opportunityStep` tinyint NOT NULL,
  `startDate` tinyint NOT NULL,
  `endDate` tinyint NOT NULL,
  `noOfDays` tinyint NOT NULL,
  `sstatus` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_ticketsimpletopcustbyage`
--

DROP TABLE IF EXISTS `v_ticketsimpletopcustbyage`;
/*!50001 DROP VIEW IF EXISTS `v_ticketsimpletopcustbyage`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_ticketsimpletopcustbyage` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `row_number` tinyint NOT NULL,
  `Age` tinyint NOT NULL,
  `parentName` tinyint NOT NULL,
  `parentNameUrl` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_ticketsimpletopcustbyopencases`
--

DROP TABLE IF EXISTS `v_ticketsimpletopcustbyopencases`;
/*!50001 DROP VIEW IF EXISTS `v_ticketsimpletopcustbyopencases`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_ticketsimpletopcustbyopencases` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `row_number` tinyint NOT NULL,
  `numTickets` tinyint NOT NULL,
  `parentName` tinyint NOT NULL,
  `parentNameUrl` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_campaignanalysiswinloss`
--

DROP TABLE IF EXISTS `v_campaignanalysiswinloss`;
/*!50001 DROP VIEW IF EXISTS `v_campaignanalysiswinloss`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_campaignanalysiswinloss` (
  `instanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `PARENT_INSTANCE_ID` tinyint NOT NULL,
  `PARENT_MODULE_UNAME` tinyint NOT NULL,
  `CampaignName` tinyint NOT NULL,
  `Win` tinyint NOT NULL,
  `Loss` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `security_level` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_user_list`
--

DROP TABLE IF EXISTS `v_user_list`;
/*!50001 DROP VIEW IF EXISTS `v_user_list`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_user_list` (
  `organization_id` tinyint NOT NULL,
  `company_id` tinyint NOT NULL,
  `USER_ID` tinyint NOT NULL,
  `FIRST_NAME` tinyint NOT NULL,
  `last_name` tinyint NOT NULL,
  `USER_UNAME` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_contactmaxemails`
--

DROP TABLE IF EXISTS `v_contactmaxemails`;
/*!50001 DROP VIEW IF EXISTS `v_contactmaxemails`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_contactmaxemails` (
  `parent_module_uname` tinyint NOT NULL,
  `parent_instance_id` tinyint NOT NULL,
  `update_date` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_contactallcompletedactivity`
--

DROP TABLE IF EXISTS `v_contactallcompletedactivity`;
/*!50001 DROP VIEW IF EXISTS `v_contactallcompletedactivity`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_contactallcompletedactivity` (
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `activityModName` tinyint NOT NULL,
  `activityModId` tinyint NOT NULL,
  `update_date` tinyint NOT NULL,
  `activity_type` tinyint NOT NULL,
  `parent_instance_id` tinyint NOT NULL,
  `parent_module_uname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_allactions`
--

DROP TABLE IF EXISTS `v_allactions`;
/*!50001 DROP VIEW IF EXISTS `v_allactions`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_allactions` (
  `organization_id` tinyint NOT NULL,
  `company_id` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `last_action` tinyint NOT NULL,
  `last_action_type` tinyint NOT NULL,
  `detail` tinyint NOT NULL,
  `adate` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `instanceId` tinyint NOT NULL,
  `moduleUname` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_util_pageview`
--

DROP TABLE IF EXISTS `v_util_pageview`;
/*!50001 DROP VIEW IF EXISTS `v_util_pageview`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_util_pageview` (
  `pageview_uname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_salesopp_list`
--

DROP TABLE IF EXISTS `v_salesopp_list`;
/*!50001 DROP VIEW IF EXISTS `v_salesopp_list`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_salesopp_list` (
  `INSTANCE_ID` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `PARENT_MODULE_UNAME` tinyint NOT NULL,
  `PARENT_INSTANCE_ID` tinyint NOT NULL,
  `oppName` tinyint NOT NULL,
  `Account` tinyint NOT NULL,
  `contact` tinyint NOT NULL,
  `closeamount` tinyint NOT NULL,
  `EstAmount` tinyint NOT NULL,
  `closedate` tinyint NOT NULL,
  `EstCloseDate` tinyint NOT NULL,
  `DateCreated` tinyint NOT NULL,
  `opportunityStatus` tinyint NOT NULL,
  `opptype` tinyint NOT NULL,
  `SalesStage` tinyint NOT NULL,
  `LeadStage` tinyint NOT NULL,
  `EstProb` tinyint NOT NULL,
  `region` tinyint NOT NULL,
  `lsource` tinyint NOT NULL,
  `campaign` tinyint NOT NULL,
  `SO_No` tinyint NOT NULL,
  `primcontact` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `SalesPersonID` tinyint NOT NULL,
  `ManagerId` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_history_email`
--

DROP TABLE IF EXISTS `v_history_email`;
/*!50001 DROP VIEW IF EXISTS `v_history_email`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_history_email` (
  `subject` tinyint NOT NULL,
  `sdate` tinyint NOT NULL,
  `email_name` tinyint NOT NULL,
  `instanceId` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `owner` tinyint NOT NULL,
  `access` tinyint NOT NULL,
  `security_level` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_rpt_salesopp`
--

DROP TABLE IF EXISTS `v_rpt_salesopp`;
/*!50001 DROP VIEW IF EXISTS `v_rpt_salesopp`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_rpt_salesopp` (
  `INSTANCE_ID` tinyint NOT NULL,
  `ORGANIZATION_ID` tinyint NOT NULL,
  `COMPANY_ID` tinyint NOT NULL,
  `PARENT_MODULE_UNAME` tinyint NOT NULL,
  `PARENT_INSTANCE_ID` tinyint NOT NULL,
  `oppName` tinyint NOT NULL,
  `oppDate` tinyint NOT NULL,
  `probability` tinyint NOT NULL,
  `potClose` tinyint NOT NULL,
  `amountpot` tinyint NOT NULL,
  `notes` tinyint NOT NULL,
  `leadstage` tinyint NOT NULL,
  `leadsource` tinyint NOT NULL,
  `salestage` tinyint NOT NULL,
  `prodType` tinyint NOT NULL,
  `accName` tinyint NOT NULL,
  `salesperson` tinyint NOT NULL,
  `safname` tinyint NOT NULL,
  `salname` tinyint NOT NULL,
  `contact` tinyint NOT NULL,
  `primary2contact` tinyint NOT NULL,
  `cofname` tinyint NOT NULL,
  `colname` tinyint NOT NULL,
  `phonenum` tinyint NOT NULL,
  `email` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_accountlastemail`
--

DROP TABLE IF EXISTS `v_accountlastemail`;
/*!50001 DROP VIEW IF EXISTS `v_accountlastemail`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_accountlastemail` (
  `last_action` tinyint NOT NULL,
  `last_action_type` tinyint NOT NULL,
  `parentModuleUname` tinyint NOT NULL,
  `parentInstanceId` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `v_accountallcompletedactivity`
--

/*!50001 DROP TABLE IF EXISTS `v_accountallcompletedactivity`*/;
/*!50001 DROP VIEW IF EXISTS `v_accountallcompletedactivity`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_accountallcompletedactivity` AS select `ac`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ac`.`COMPANY_ID` AS `COMPANY_ID`,`ac`.`activityModName` AS `activityModName`,`ac`.`activityModId` AS `activityModId`,`ac`.`update_date` AS `update_date`,`ac`.`activity_type` AS `activity_type`,`ac`.`activityModId` AS `parent_instance_id`,`ac`.`activityModName` AS `parent_module_uname` from `v_allcompletedactivity` `ac` where (`ac`.`activityModName` = 'Account') union select `ac`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ac`.`COMPANY_ID` AS `COMPANY_ID`,`ac`.`activityModName` AS `activityModName`,`ac`.`activityModId` AS `activityModId`,`ac`.`update_date` AS `update_date`,`ac`.`activity_type` AS `activity_type`,`s`.`PARENT_INSTANCE_ID` AS `parent_instance_id`,`s`.`PARENT_MODULE_UNAME` AS `parent_module_uname` from (`v_allcompletedactivity` `ac` join `cxm_entity_instance_2` `s` on(((`ac`.`activityModId` = `s`.`INSTANCE_ID`) and (`ac`.`activityModName` = 'Sales') and (`s`.`PARENT_MODULE_UNAME` = 'Account')))) union select `ac`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ac`.`COMPANY_ID` AS `COMPANY_ID`,`ac`.`activityModName` AS `activityModName`,`ac`.`activityModId` AS `activityModId`,`ac`.`update_date` AS `update_date`,`ac`.`activity_type` AS `activity_type`,`c`.`PARENT_INSTANCE_ID` AS `parent_instance_id`,`c`.`PARENT_MODULE_UNAME` AS `parent_module_uname` from (`v_allcompletedactivity` `ac` join `cxm_entity_instance_3` `c` on(((`ac`.`activityModId` = `c`.`INSTANCE_ID`) and (`ac`.`activityModName` = 'Contact') and (`c`.`PARENT_MODULE_UNAME` = 'Account')))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_sales_dash_actual`
--

/*!50001 DROP TABLE IF EXISTS `v_sales_dash_actual`*/;
/*!50001 DROP VIEW IF EXISTS `v_sales_dash_actual`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_sales_dash_actual` AS select `vperson`.`USER_ID` AS `instanceId`,`vperson`.`organization_id` AS `organization_id`,`vperson`.`company_id` AS `company_id`,`salesoppurtunity`.`owner` AS `owner`,`salesoppurtunity`.`access` AS `access`,'SalesDashboard' AS `parentModuleUname`,'1' AS `parentInstanceId`,ifnull(sum((`salesoppurtunity`.`closeamount` / `salesoppurtunity`.`count`)),0) AS `actualAmt`,concat(`vperson`.`FIRST_NAME`,' ',`vperson`.`LAST_NAME`) AS `SPName` from (`v_salesperson_list` `vperson` left join `v_sales_dashboard` `salesoppurtunity` on(((`vperson`.`organization_id` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`vperson`.`company_id` = `salesoppurtunity`.`COMPANY_ID`) and (`vperson`.`USER_ID` = `salesoppurtunity`.`SalesPersonID`) and (`salesoppurtunity`.`Status` = 'OPPORTUNITY2') and (year(str_to_date(`salesoppurtunity`.`closedate`,'%m/%d/%Y')) = year(now()))))) group by `vperson`.`USER_ID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_ticketavgrestimebypriority`
--

/*!50001 DROP TABLE IF EXISTS `v_ticketavgrestimebypriority`*/;
/*!50001 DROP VIEW IF EXISTS `v_ticketavgrestimebypriority`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ticketavgrestimebypriority` AS select `ticket`.`INSTANCE_ID` AS `instanceId`,`ticket`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ticket`.`COMPANY_ID` AS `COMPANY_ID`,`ticket`.`OWNER` AS `owner`,`ticket`.`ACCESS` AS `access`,1 AS `row_number`,`ticket`.`ENTITY_VALUE_14` AS `priority`,avg((to_days(`CXM_STR_TO_DATE`(`ticket`.`ORGANIZATION_ID`,`ticket`.`COMPANY_ID`,`ticket`.`ENTITY_VALUE_25`)) - to_days(`CXM_STR_TO_DATE`(`ticket`.`ORGANIZATION_ID`,`ticket`.`COMPANY_ID`,`ticket`.`ENTITY_VALUE_4`)))) AS `age` from `cxm_entity_instance_11` `ticket` where (((`ticket`.`ENTITY_VALUE_8` = 'TICKET_STATUS06') or (`ticket`.`ENTITY_VALUE_8` = 'TICKET_STATUS05')) and (`CXM_STR_TO_DATE`(`ticket`.`ORGANIZATION_ID`,`ticket`.`COMPANY_ID`,`ticket`.`ENTITY_VALUE_25`) between `CXM_STR_TO_DATE`(`ticket`.`ORGANIZATION_ID`,`ticket`.`COMPANY_ID`,date_format((now() - interval 1 year),'%m/%d/%Y')) and now())) group by `ticket`.`ENTITY_VALUE_14` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_salesmaingrid`
--

/*!50001 DROP TABLE IF EXISTS `v_salesmaingrid`*/;
/*!50001 DROP VIEW IF EXISTS `v_salesmaingrid`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_salesmaingrid` AS select distinct `salesoppurtunity`.`ENTITY_VALUE_1` AS `displayFieldName`,`salesoppurtunity`.`INSTANCE_ID` AS `instanceId`,`salesoppurtunity`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`salesoppurtunity`.`COMPANY_ID` AS `COMPANY_ID`,`salesoppurtunity`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`salesoppurtunity`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,`salesoppurtunity`.`ENTITY_VALUE_1` AS `opportunityName`,`salesoppurtunity`.`ENTITY_VALUE_10` AS `amountPerUnitPotential`,`salesoppurtunity`.`ENTITY_VALUE_13` AS `ActualAmount`,`salesoppurtunity`.`ENTITY_VALUE_12` AS `closedate`,`salesoppurtunity`.`ENTITY_VALUE_23` AS `salesperson`,`salesoppurtunity`.`ENTITY_VALUE_9` AS `closeDatePotential`,`salesoppurtunity`.`ENTITY_VALUE_6` AS `opportunityStatusKey`,`salesoppurtunity`.`ENTITY_VALUE_6` AS `opportunityStatus`,`salesoppurtunity`.`ENTITY_VALUE_18` AS `leadSource`,`salesoppurtunity`.`ENTITY_VALUE_16` AS `opportunityStep`,`salesoppurtunity`.`ENTITY_VALUE_15` AS `leadStage`,`salesoppurtunity`.`ENTITY_VALUE_7` AS `probability`,`salesoppurtunity`.`ENTITY_VALUE_22` AS `SO_No`,`salesoppurtunity`.`ENTITY_VALUE_2` AS `accountInSales`,`salesoppurtunity`.`ENTITY_VALUE_2` AS `accNameUrl`,`salesoppurtunity`.`ENTITY_VALUE_3` AS `contactInSales`,`salesoppurtunity`.`ENTITY_VALUE_3` AS `pconNameUrl`,`salesoppurtunity`.`OWNER` AS `owner`,`salesoppurtunity`.`ACCESS` AS `access`,`salesoppurtunity`.`ENTITY_VALUE_24` AS `primaryContact`,`salesoppurtunity`.`ENTITY_VALUE_34` AS `salesRanking`,`GETIMAGEFROMLOOKUP`(`salesoppurtunity`.`ENTITY_VALUE_34`) AS `salesRankingImage`,if(isnull(`pcntc`.`ENTITY_VALUE_12`),convert(concat(`pcntc`.`ENTITY_VALUE_11`,'') using utf8),convert(concat(`pcntc`.`ENTITY_VALUE_11`,`pcntc`.`ENTITY_VALUE_12`) using utf8)) AS `phone`,`pcntc`.`ENTITY_VALUE_56` AS `state`,if((`salesoppurtunity`.`PARENT_MODULE_UNAME` = 'Account'),(select `v_accountlastactivity`.`last_action` from `v_accountlastactivity` where ((`v_accountlastactivity`.`parentModuleUname` = 'Account') and (`v_accountlastactivity`.`parentInstanceId` = `salesoppurtunity`.`PARENT_INSTANCE_ID`)) limit 1),(select `v_contactlastactivity`.`last_action` from `v_contactlastactivity` where ((`v_contactlastactivity`.`parentModuleUname` = 'Contact') and (`v_contactlastactivity`.`parentInstanceId` = `salesoppurtunity`.`PARENT_INSTANCE_ID`)) limit 1)) AS `last_action`,if((`salesoppurtunity`.`PARENT_MODULE_UNAME` = 'Account'),(select `v_accountlastemail`.`last_action` from `v_accountlastemail` where ((`v_accountlastemail`.`parentModuleUname` = 'Account') and (`v_accountlastemail`.`parentInstanceId` = `salesoppurtunity`.`PARENT_INSTANCE_ID`)) limit 1),(select `v_contactlastemail`.`last_action` from `v_contactlastemail` where ((`v_contactlastemail`.`parentModuleUname` = 'Contact') and (`v_contactlastemail`.`parentInstanceId` = `salesoppurtunity`.`PARENT_INSTANCE_ID`)) limit 1)) AS `last_email` from (`cxm_entity_instance_2` `salesoppurtunity` left join `cxm_entity_instance_3` `pcntc` on(((`pcntc`.`INSTANCE_ID` = `salesoppurtunity`.`ENTITY_VALUE_24`) and (`pcntc`.`ORGANIZATION_ID` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`pcntc`.`COMPANY_ID` = `salesoppurtunity`.`COMPANY_ID`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_lastemail`
--

/*!50001 DROP TABLE IF EXISTS `v_lastemail`*/;
/*!50001 DROP VIEW IF EXISTS `v_lastemail`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_lastemail` AS select `a`.`ORGANIZATION_ID` AS `organization_id`,`a`.`COMPANY_ID` AS `company_id`,`ae`.`ENTITY_TYPE` AS `parentModuleUname`,`ae`.`ENTITY_ID` AS `parentInstanceId`,cast(max(`a`.`SENT_DATA_TIME`) as date) AS `last_action`,'Email' AS `last_action_type` from (`cxm_email` `a` join `cxm_email_entity` `ae` on((`a`.`EMAIL_ID` = `ae`.`EMAIL_ID`))) group by `ae`.`ENTITY_TYPE`,`ae`.`ENTITY_ID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_contactlastactivity`
--

/*!50001 DROP TABLE IF EXISTS `v_contactlastactivity`*/;
/*!50001 DROP VIEW IF EXISTS `v_contactlastactivity`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_contactlastactivity` AS select concat((select `cxm_lookup`.`LVALUE` from `cxm_lookup` where ((`cxm_lookup`.`LKEY` = convert(`v_a`.`activity_type` using utf8)) and (`cxm_lookup`.`LTYPE` = 'ACTIVITY_TYPE') and (`cxm_lookup`.`ORGANIZATION_ID` = `v_a`.`ORGANIZATION_ID`) and (`cxm_lookup`.`COMPANY_ID` = `v_a`.`COMPANY_ID`))),':',convert(`CXM_date_format`(`v_a`.`ORGANIZATION_ID`,`v_a`.`COMPANY_ID`,`v_a`.`update_date`) using utf8)) AS `last_action`,'Activity' AS `last_action_type`,`v_m`.`parent_module_uname` AS `parentModuleUname`,`v_m`.`parent_instance_id` AS `parentInstanceId` from (`v_contactallcompletedactivity` `v_a` join `v_contactmaxactivity` `v_m` on(((`v_a`.`update_date` = `v_m`.`update_date`) and (`v_a`.`parent_instance_id` = `v_m`.`parent_instance_id`) and (`v_a`.`parent_module_uname` = `v_m`.`parent_module_uname`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_myticketsimplegrpgrid`
--

/*!50001 DROP TABLE IF EXISTS `v_myticketsimplegrpgrid`*/;
/*!50001 DROP VIEW IF EXISTS `v_myticketsimplegrpgrid`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_myticketsimplegrpgrid` AS select distinct `ticket`.`INSTANCE_ID` AS `instanceId`,`ticket`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ticket`.`COMPANY_ID` AS `COMPANY_ID`,`ticket`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`ticket`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,`ticket`.`ENTITY_VALUE_71` AS `ticketID`,`ticket`.`ENTITY_VALUE_4` AS `recdDate`,`ticket`.`ENTITY_VALUE_21` AS `recdTime`,`ticket`.`ENTITY_VALUE_13` AS `ticketTitle`,`ticket`.`ENTITY_VALUE_70` AS `assignedType`,`ticket`.`ENTITY_VALUE_17` AS `assignedTo`,`ticket`.`ENTITY_VALUE_8` AS `status`,`ticket`.`ENTITY_VALUE_16` AS `ticketType`,`ticket`.`ENTITY_VALUE_14` AS `urgency`,`ticket`.`OWNER` AS `owner`,`ticket`.`ACCESS` AS `access`,concat(`pcntc`.`ENTITY_VALUE_4`,' ',`pcntc`.`ENTITY_VALUE_6`) AS `pconName`,convert(concat(`pcntc`.`ENTITY_VALUE_4`,' ',`pcntc`.`ENTITY_VALUE_6`,'::',`pcntc`.`INSTANCE_ID`,'::Contact') using utf8) AS `pconNameUrl`,convert(concat(`pcntc`.`ENTITY_VALUE_11`,`pcntc`.`ENTITY_VALUE_12`) using utf8) AS `phone`,`ticket`.`ENTITY_VALUE_22` AS `email` from (`cxm_entity_instance_67` `ticket` left join `cxm_entity_instance_3` `pcntc` on(((`pcntc`.`INSTANCE_ID` = `ticket`.`ENTITY_VALUE_1`) and (`pcntc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`pcntc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`)))) where ((`ticket`.`ENTITY_VALUE_8` <> 'TICKET_STATUS06') and (`ticket`.`ENTITY_VALUE_8` <> 'TICKET_STATUS05') and (`ticket`.`ENTITY_VALUE_70` <> 'INDIVIDUAL')) order by `ticket`.`INSTANCE_ID` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_allactionbytype`
--

/*!50001 DROP TABLE IF EXISTS `v_allactionbytype`*/;
/*!50001 DROP VIEW IF EXISTS `v_allactionbytype`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_allactionbytype` AS select `a`.`ORGANIZATION_ID` AS `organization_id`,`a`.`COMPANY_ID` AS `company_id`,`ae`.`INSTANCE_ID` AS `parentInstanceId`,convert(`CXM_DATE_FORMAT`(`a`.`ORGANIZATION_ID`,`a`.`COMPANY_ID`,`a`.`UPDATE_DATE`) using utf8) AS `last_action`,(select `cxm_lookup`.`LVALUE` from `cxm_lookup` where ((`cxm_lookup`.`LKEY` = convert(`a`.`ACTIVITY_TYPE` using utf8)) and (`cxm_lookup`.`LTYPE` = 'ACTIVITY_TYPE') and (`cxm_lookup`.`ORGANIZATION_ID` = `a`.`ORGANIZATION_ID`) and (`cxm_lookup`.`COMPANY_ID` = `a`.`COMPANY_ID`))) AS `last_action_type`,`a`.`ACTIVITY_NAME` AS `detail`,`a`.`FROM_DATE` AS `adate`,`a`.`OWNER` AS `owner`,`a`.`ACCESS` AS `access`,`a`.`ACTIVITY_ID` AS `instanceId`,'activity' AS `moduleUname`,`ae`.`MODULE_UNAME` AS `parentModuleUname` from (`cxm_activity` `a` join `cxm_activity_entity` `ae` on((`a`.`ACTIVITY_ID` = `ae`.`ACTIVITY_ID`))) where ((`a`.`STATUS` = 'ACT_STATUS_COMPLETED') and ((`a`.`FROM_DATE` < now()) or (`a`.`UPDATE_DATE` < now()))) union select `a`.`ORGANIZATION_ID` AS `organization_id`,`a`.`COMPANY_ID` AS `company_id`,`ae`.`ENTITY_ID` AS `parentInstanceId`,convert(`CXM_DATE_FORMAT`(`a`.`ORGANIZATION_ID`,`a`.`COMPANY_ID`,`a`.`SENT_DATA_TIME`) using utf8) AS `last_action`,'Email' AS `last_action_type`,`a`.`SUBJECT` AS `detail`,`a`.`SENT_DATA_TIME` AS `adate`,`a`.`OWNER` AS `owner`,`a`.`ACCESS` AS `access`,`a`.`EMAIL_ID` AS `instanceId`,'emailHistory' AS `moduleUname`,`ae`.`ENTITY_TYPE` AS `parentModuleUname` from (`cxm_email` `a` join `cxm_email_entity` `ae` on((`a`.`EMAIL_ID` = `ae`.`EMAIL_ID`))) union select `a`.`ORGANIZATION_ID` AS `organization_id`,`a`.`COMPANY_ID` AS `company_id`,`a`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,`CXM_DATE_FORMAT`(`a`.`ORGANIZATION_ID`,`a`.`COMPANY_ID`,`a`.`CREATE_DATE`) AS `last_action`,'Note' AS `last_action_type`,substr(`a`.`ENTITY_VALUE_81`,1,40) AS `detail`,`a`.`CREATE_DATE` AS `adate`,`a`.`OWNER` AS `owner`,`a`.`ACCESS` AS `access`,`a`.`INSTANCE_ID` AS `instanceId`,'CustomNotes' AS `moduleUname`,`a`.`PARENT_MODULE_UNAME` AS `parentModuleUname` from `cxm_entity_instance_198` `a` union select `a`.`ORGANIZATION_ID` AS `organization_id`,`a`.`COMPANY_ID` AS `company_id`,`a`.`INSTANCE_ID` AS `parentInstanceId`,`CXM_DATE_FORMAT`(`a`.`ORGANIZATION_ID`,`a`.`COMPANY_ID`,`a`.`UPDATE_DATE`) AS `last_action`,'Note' AS `last_action_type`,substr(`a`.`DETAIL`,1,40) AS `detail`,`a`.`UPDATE_DATE` AS `adate`,`a`.`OWNER` AS `owner`,`a`.`ACCESS` AS `access`,`a`.`NOTES_ID` AS `instanceId`,'notes' AS `moduleUname`,`a`.`MODULE_UNAME` AS `parentModuleUname` from `cxm_notes` `a` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_salesoppmgrresultsgrid`
--

/*!50001 DROP TABLE IF EXISTS `v_salesoppmgrresultsgrid`*/;
/*!50001 DROP VIEW IF EXISTS `v_salesoppmgrresultsgrid`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_salesoppmgrresultsgrid` AS select distinct (case `salesoppurtunity`.`PARENT_MODULE_UNAME` when 'Account' then (select `acc`.`ENTITY_VALUE_2` from `cxm_entity_instance_1` `acc` where ((`acc`.`INSTANCE_ID` = `salesoppurtunity`.`PARENT_INSTANCE_ID`) and (`acc`.`ORGANIZATION_ID` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`acc`.`COMPANY_ID` = `salesoppurtunity`.`COMPANY_ID`))) when 'Contact' then (select concat(`cntc`.`ENTITY_VALUE_4`,' ',`cntc`.`ENTITY_VALUE_6`) from `cxm_entity_instance_3` `cntc` where ((`cntc`.`INSTANCE_ID` = `salesoppurtunity`.`PARENT_INSTANCE_ID`) and (`cntc`.`ORGANIZATION_ID` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`cntc`.`COMPANY_ID` = `salesoppurtunity`.`COMPANY_ID`))) else 'Unassigned' end) AS `parentName`,(case `salesoppurtunity`.`PARENT_MODULE_UNAME` when 'Account' then (select convert(concat(`acc`.`ENTITY_VALUE_2`,'::',`acc`.`INSTANCE_ID`,'::Account') using utf8) from `cxm_entity_instance_1` `acc` where ((`acc`.`INSTANCE_ID` = `salesoppurtunity`.`PARENT_INSTANCE_ID`) and (`acc`.`ORGANIZATION_ID` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`acc`.`COMPANY_ID` = `salesoppurtunity`.`COMPANY_ID`))) when 'Contact' then (select convert(concat(`cntc`.`ENTITY_VALUE_4`,' ',`cntc`.`ENTITY_VALUE_6`,'::',`cntc`.`INSTANCE_ID`,'::Contact') using utf8) from `cxm_entity_instance_3` `cntc` where ((`cntc`.`INSTANCE_ID` = `salesoppurtunity`.`PARENT_INSTANCE_ID`) and (`cntc`.`ORGANIZATION_ID` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`cntc`.`COMPANY_ID` = `salesoppurtunity`.`COMPANY_ID`))) else 'Unassigned' end) AS `parentNameUrl`,`salesoppurtunity`.`ENTITY_VALUE_24` AS `primcontactName`,`salesoppurtunity`.`INSTANCE_ID` AS `oppId`,`salesoppurtunity`.`ENTITY_VALUE_1` AS `oppName`,`salesoppurtunity`.`ENTITY_VALUE_23` AS `SalesPerson`,`salesoppurtunity`.`ENTITY_VALUE_22` AS `SO_No`,`salesoppurtunity`.`ENTITY_VALUE_5` AS `DateCreated`,`salesoppurtunity`.`ENTITY_VALUE_9` AS `EstCloseDate`,`salesoppurtunity`.`ENTITY_VALUE_10` AS `EstAmount`,`salesoppurtunity`.`ENTITY_VALUE_7` AS `EstProb`,`salesoppurtunity`.`ENTITY_VALUE_12` AS `closedate`,`salesoppurtunity`.`ENTITY_VALUE_13` AS `closeamount`,if((`salesoppurtunity`.`PARENT_MODULE_UNAME` = 'Account'),`salesoppurtunity`.`PARENT_INSTANCE_ID`,0) AS `Account`,if((`salesoppurtunity`.`PARENT_MODULE_UNAME` = 'Contact'),`salesoppurtunity`.`PARENT_INSTANCE_ID`,0) AS `contact`,`salesoppurtunity`.`ENTITY_VALUE_24` AS `primcontact`,`salesoppurtunity`.`ENTITY_VALUE_6` AS `opportunityStatus`,`salesoppurtunity`.`ENTITY_VALUE_16` AS `SalesStage`,`salesoppurtunity`.`ENTITY_VALUE_15` AS `LeadStage`,`salesoppurtunity`.`ENTITY_VALUE_16` AS `SalesStageName`,`salesoppurtunity`.`ENTITY_VALUE_15` AS `LeadStageName`,`salesoppurtunity`.`ENTITY_VALUE_4` AS `region`,`salesoppurtunity`.`ENTITY_VALUE_18` AS `lsource`,`salesoppurtunity`.`ENTITY_VALUE_17` AS `opptype`,`salesoppurtunity`.`ENTITY_VALUE_19` AS `campaign`,`salesoppurtunity`.`UPDATE_DATE` AS `updateDate`,`salesoppurtunity`.`PARENT_MODULE_UNAME` AS `salesParent`,`salesoppurtunity`.`PARENT_MODULE_UNAME` AS `PARENT_MODULE_UNAME`,`salesoppurtunity`.`PARENT_INSTANCE_ID` AS `PARENT_INSTANCE_ID`,`salesoppurtunity`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`salesoppurtunity`.`COMPANY_ID` AS `COMPANY_ID`,`salesoppurtunity`.`OWNER` AS `owner`,`salesoppurtunity`.`ACCESS` AS `access`,`salesoppurtunity`.`INSTANCE_ID` AS `instanceId` from `cxm_entity_instance_2` `salesoppurtunity` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_salesdashboardbystage`
--

/*!50001 DROP TABLE IF EXISTS `v_salesdashboardbystage`*/;
/*!50001 DROP VIEW IF EXISTS `v_salesdashboardbystage`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_salesdashboardbystage` AS select `s`.`INSTANCE_ID` AS `instanceId`,`s`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`s`.`COMPANY_ID` AS `COMPANY_ID`,`s`.`ACCESS` AS `ACCESS`,`s`.`OWNER` AS `owner`,1 AS `row_num`,`s`.`ENTITY_VALUE_16` AS `salesStage`,`s`.`ENTITY_VALUE_51` AS `salesStatus`,count(`s`.`ENTITY_VALUE_16`) AS `leadStageCount`,cast(((count(0) * 100) / (select count(0) from `cxm_entity_instance_2` `s`)) as decimal(10,2)) AS `perc`,round(((select sum(if((`cxm_entity_instance_181`.`ENTITY_VALUE_4` = 0),(to_days(curdate()) - to_days(str_to_date(`cxm_entity_instance_181`.`ENTITY_VALUE_2`,'%m/%d/%Y'))),`cxm_entity_instance_181`.`ENTITY_VALUE_4`)) from `cxm_entity_instance_181` where ((convert(`cxm_entity_instance_181`.`ENTITY_VALUE_1` using utf8) = `s`.`ENTITY_VALUE_61`) and (`cxm_entity_instance_181`.`PARENT_MODULE_UNAME` = 'Sales'))) / count(0)),1) AS `avgTime` from `cxm_entity_instance_2` `s` group by `s`.`ENTITY_VALUE_16`,`s`.`ENTITY_VALUE_51` order by (select `cxm_lookup`.`WEIGHT` from `cxm_lookup` where (`cxm_lookup`.`LKEY` = `s`.`ENTITY_VALUE_16`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_campanalysisresultsgrid`
--

/*!50001 DROP TABLE IF EXISTS `v_campanalysisresultsgrid`*/;
/*!50001 DROP VIEW IF EXISTS `v_campanalysisresultsgrid`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_campanalysisresultsgrid` AS select `campaign`.`instanceId` AS `instanceId`,`campaign`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`campaign`.`COMPANY_ID` AS `COMPANY_ID`,`campaign`.`PARENT_INSTANCE_ID` AS `PARENT_INSTANCE_ID`,`campaign`.`PARENT_MODULE_UNAME` AS `PARENT_MODULE_UNAME`,`campaign`.`CampaignName` AS `CampaignName`,`campaign`.`CampaignNameUrl` AS `CampaignNameUrl`,`campaign`.`Stat` AS `Stat`,`campaign`.`Type` AS `Type`,`campaign`.`Budget` AS `Budget`,`campaign`.`Actual` AS `Actual`,`campaign`.`StartDate` AS `StartDate`,`campaign`.`StopDate` AS `StopDate`,`campaign`.`EstTarget` AS `EstTarget`,`campaign`.`CampaignManager` AS `CampaignManager`,`campaign`.`CampaignManagerName` AS `CampaignManagerName`,`campaign`.`SalesOpportunities` AS `SalesOpportunities`,`campaign`.`EstPotentialValue` AS `EstPotentialValue`,`campaign`.`ActualValue` AS `ActualValue`,`campaign`.`owner` AS `owner`,`campaign`.`access` AS `access`,`campaign`.`TypeLKEY` AS `TypeLKEY`,`campaign`.`StatusLKEY` AS `StatusLKEY`,`campaign`.`rev` AS `rev`,`campaign`.`closeso` AS `closeso`,`campaign`.`totaldays` AS `totaldays`,convert(concat(round((ifnull((`campaign`.`SalesOpportunities` / count(`leads`.`INSTANCE_ID`)),0) * 100),2),'%') using utf8) AS `cr`,round(ifnull((`campaign`.`totaldays` / `campaign`.`closeso`),0),2) AS `ave`,round(ifnull((`campaign`.`rev` / `campaign`.`Actual`),0),2) AS `rpm` from (`v_campaignmgrgrid` `campaign` left join `cxm_entity_instance_6` `leads` on(((`leads`.`ENTITY_VALUE_24` = `campaign`.`instanceId`) and (`leads`.`ORGANIZATION_ID` = `campaign`.`ORGANIZATION_ID`) and (`leads`.`COMPANY_ID` = `campaign`.`COMPANY_ID`)))) group by `campaign`.`instanceId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_grouplist`
--

/*!50001 DROP TABLE IF EXISTS `v_grouplist`*/;
/*!50001 DROP VIEW IF EXISTS `v_grouplist`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_grouplist` AS select distinct `g`.`GROUP_ID` AS `instanceId`,`g`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`g`.`COMPANY_ID` AS `COMPANY_ID`,`g`.`GROUP_NAME` AS `name`,`g`.`TYPE` AS `MODULE_UNAME` from `cxm_group` `g` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_ticketsforaccount`
--

/*!50001 DROP TABLE IF EXISTS `v_ticketsforaccount`*/;
/*!50001 DROP VIEW IF EXISTS `v_ticketsforaccount`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ticketsforaccount` AS select `ticket`.`ENTITY_VALUE_13` AS `ticketTitle`,`ticket`.`ENTITY_VALUE_71` AS `ticketId`,`ticket`.`ENTITY_VALUE_11` AS `severity`,`ticket`.`ENTITY_VALUE_8` AS `status`,`ticket`.`ENTITY_VALUE_16` AS `typeCall`,`ticket`.`ENTITY_VALUE_14` AS `urgency`,convert(concat(`pcntc`.`ENTITY_VALUE_4`,' ',`pcntc`.`ENTITY_VALUE_6`,'::',`pcntc`.`INSTANCE_ID`,'::Contact') using utf8) AS `pconNameUrl`,convert(concat(`pcntc`.`ENTITY_VALUE_11`,`pcntc`.`ENTITY_VALUE_12`) using utf8) AS `phone`,`pcntc`.`ENTITY_VALUE_24` AS `email`,`acc`.`ENTITY_VALUE_2` AS `acctName`,`ticket`.`ENTITY_VALUE_4` AS `recdDate`,`ticket`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`acc`.`INSTANCE_ID` AS `parentInstanceId`,`ticket`.`INSTANCE_ID` AS `instanceId`,`ticket`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ticket`.`COMPANY_ID` AS `COMPANY_ID`,`ticket`.`OWNER` AS `owner`,`ticket`.`ACCESS` AS `access` from ((`cxm_entity_instance_67` `ticket` join `cxm_entity_instance_1` `acc` on((`ticket`.`PARENT_INSTANCE_ID` = `acc`.`INSTANCE_ID`))) left join `cxm_entity_instance_3` `pcntc` on(((`pcntc`.`INSTANCE_ID` = `ticket`.`ENTITY_VALUE_1`) and (`pcntc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`pcntc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`)))) where (`ticket`.`PARENT_MODULE_UNAME` = 'Account') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_allemail`
--

/*!50001 DROP TABLE IF EXISTS `v_allemail`*/;
/*!50001 DROP VIEW IF EXISTS `v_allemail`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_allemail` AS select `a`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`a`.`COMPANY_ID` AS `COMPANY_ID`,`ae`.`ENTITY_TYPE` AS `parentModuleUname`,`ae`.`ENTITY_ID` AS `parentInstanceId`,`a`.`UPDATE_DATE` AS `update_date`,`a`.`SENT_DATA_TIME` AS `last_action` from (`cxm_email` `a` join `cxm_email_entity` `ae` on((`a`.`EMAIL_ID` = `ae`.`EMAIL_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_homepagelist`
--

/*!50001 DROP TABLE IF EXISTS `v_homepagelist`*/;
/*!50001 DROP VIEW IF EXISTS `v_homepagelist`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_homepagelist` AS select `c`.`MODULE_UNAME` AS `module_uname`,`c`.`DISPLAY_NAME` AS `display_name` from `cxm_module` `c` where ((`c`.`MODULE_TYPE` = 'entity') and (`c`.`IS_ENABLED` = 1) and (`c`.`MENU_LOCATION` is not null) and (`c`.`MENU_LOCATION` <> '')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_ticketsimpletopcustbypriority`
--

/*!50001 DROP TABLE IF EXISTS `v_ticketsimpletopcustbypriority`*/;
/*!50001 DROP VIEW IF EXISTS `v_ticketsimpletopcustbypriority`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ticketsimpletopcustbypriority` AS select distinct `ticket`.`INSTANCE_ID` AS `instanceId`,`ticket`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ticket`.`COMPANY_ID` AS `COMPANY_ID`,`ticket`.`OWNER` AS `owner`,`ticket`.`ACCESS` AS `access`,`ticket`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`ticket`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,1 AS `row_number`,count(`ticket`.`INSTANCE_ID`) AS `numTickets`,`ticket`.`ENTITY_VALUE_14` AS `priority`,(case `ticket`.`PARENT_MODULE_UNAME` when 'Account' then (select `acc`.`ENTITY_VALUE_2` from `cxm_entity_instance_1` `acc` where ((`acc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`acc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`acc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) when 'Contact' then (select concat(`cntc`.`ENTITY_VALUE_4`,' ',`cntc`.`ENTITY_VALUE_6`) from `cxm_entity_instance_3` `cntc` where ((`cntc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`cntc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`cntc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) else 'Unassigned' end) AS `parentName`,(case `ticket`.`PARENT_MODULE_UNAME` when 'Account' then (select convert(concat(`acc`.`ENTITY_VALUE_2`,'::',`acc`.`INSTANCE_ID`,'::Account') using utf8) from `cxm_entity_instance_1` `acc` where ((`acc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`acc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`acc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) when 'Contact' then (select convert(concat(`cntc`.`ENTITY_VALUE_4`,' ',`cntc`.`ENTITY_VALUE_6`,'::',`cntc`.`INSTANCE_ID`,'::Contact') using utf8) from `cxm_entity_instance_3` `cntc` where ((`cntc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`cntc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`cntc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) else 'Unassigned' end) AS `parentNameUrl` from `cxm_entity_instance_67` `ticket` group by `ticket`.`PARENT_MODULE_UNAME`,`ticket`.`PARENT_INSTANCE_ID`,`ticket`.`ENTITY_VALUE_14` order by count(`ticket`.`INSTANCE_ID`) desc limit 0,5 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_dashboard_email_sorted`
--

/*!50001 DROP TABLE IF EXISTS `v_dashboard_email_sorted`*/;
/*!50001 DROP VIEW IF EXISTS `v_dashboard_email_sorted`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_dashboard_email_sorted` AS select `v_dashboard_email`.`row_num` AS `row_num`,`v_dashboard_email`.`instanceId` AS `instanceId`,`v_dashboard_email`.`parentModuleUname` AS `parentModuleUname`,`v_dashboard_email`.`parentInstanceId` AS `parentInstanceId`,`v_dashboard_email`.`organization_id` AS `organization_id`,`v_dashboard_email`.`company_id` AS `company_id`,`v_dashboard_email`.`subject` AS `subject`,`v_dashboard_email`.`sdate` AS `sdate`,`v_dashboard_email`.`email_name` AS `email_name`,`v_dashboard_email`.`owner` AS `owner`,`v_dashboard_email`.`access` AS `access`,`v_dashboard_email`.`securityLevel` AS `securityLevel`,`v_dashboard_email`.`user_id` AS `user_id`,`v_dashboard_email`.`user_name` AS `user_name`,`v_dashboard_email`.`sent_time` AS `sent_time`,`v_dashboard_email`.`email_from` AS `email_from`,`v_dashboard_email`.`email_to` AS `email_to`,`v_dashboard_email`.`moduleUname` AS `moduleUname`,`v_dashboard_email`.`emailType` AS `emailType`,`v_dashboard_email`.`entity_type` AS `entity_type`,`v_dashboard_email`.`reply` AS `reply`,`v_dashboard_email`.`replyAll` AS `replyAll`,`v_dashboard_email`.`forward` AS `forward` from `v_dashboard_email` order by `v_dashboard_email`.`sent_time` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_campaignanalysischarts`
--

/*!50001 DROP TABLE IF EXISTS `v_campaignanalysischarts`*/;
/*!50001 DROP VIEW IF EXISTS `v_campaignanalysischarts`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_campaignanalysischarts` AS select `campaign`.`INSTANCE_ID` AS `instanceId`,`campaign`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`campaign`.`COMPANY_ID` AS `COMPANY_ID`,'1' AS `PARENT_INSTANCE_ID`,'CampaignAnalysis' AS `PARENT_MODULE_UNAME`,`campaign`.`ENTITY_VALUE_1` AS `CampaignName`,`campaign`.`ENTITY_VALUE_4` AS `Budget`,`campaign`.`ENTITY_VALUE_5` AS `Actual`,sum(`sales`.`ENTITY_VALUE_10`) AS `EstPotentialValue`,sum(`sales`.`ENTITY_VALUE_13`) AS `ActualValue`,`campaign`.`ENTITY_VALUE_2` AS `Status`,`campaign`.`ENTITY_VALUE_8` AS `EstTarget`,`campaign`.`OWNER` AS `owner`,`campaign`.`ACCESS` AS `access`,`campaign`.`SECURITY_LEVEL` AS `security_level` from (`cxm_entity_instance_52` `campaign` join `cxm_entity_instance_2` `sales` on((`sales`.`ENTITY_VALUE_19` = `campaign`.`INSTANCE_ID`))) group by `campaign`.`INSTANCE_ID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_accountallemails`
--

/*!50001 DROP TABLE IF EXISTS `v_accountallemails`*/;
/*!50001 DROP VIEW IF EXISTS `v_accountallemails`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_accountallemails` AS select `ac`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ac`.`COMPANY_ID` AS `COMPANY_ID`,`ac`.`parentModuleUname` AS `emailModName`,`ac`.`parentInstanceId` AS `emailModId`,`ac`.`update_date` AS `update_date`,`ac`.`last_action` AS `last_action`,`ac`.`parentInstanceId` AS `parent_instance_id`,`ac`.`parentModuleUname` AS `parent_module_uname` from `v_allemail` `ac` where (`ac`.`parentModuleUname` = 'Account') union select `ac`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ac`.`COMPANY_ID` AS `COMPANY_ID`,`ac`.`parentModuleUname` AS `emailModName`,`ac`.`parentInstanceId` AS `emailModId`,`ac`.`update_date` AS `update_date`,`ac`.`last_action` AS `last_action`,`s`.`PARENT_INSTANCE_ID` AS `parent_instance_id`,`s`.`PARENT_MODULE_UNAME` AS `parent_module_uname` from (`v_allemail` `ac` join `cxm_entity_instance_2` `s` on(((`ac`.`parentInstanceId` = `s`.`INSTANCE_ID`) and (`ac`.`parentModuleUname` = 'Sales') and (`s`.`PARENT_MODULE_UNAME` = 'Account')))) union select `ac`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ac`.`COMPANY_ID` AS `COMPANY_ID`,`ac`.`parentModuleUname` AS `emailModName`,`ac`.`parentInstanceId` AS `emailModId`,`ac`.`update_date` AS `update_date`,`ac`.`last_action` AS `last_action`,`c`.`PARENT_INSTANCE_ID` AS `parent_instance_id`,`c`.`PARENT_MODULE_UNAME` AS `parent_module_uname` from (`v_allemail` `ac` join `cxm_entity_instance_3` `c` on(((`ac`.`parentInstanceId` = `c`.`INSTANCE_ID`) and (`ac`.`parentModuleUname` = 'Contact') and (`c`.`PARENT_MODULE_UNAME` = 'Account')))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_campaignanalysisroi`
--

/*!50001 DROP TABLE IF EXISTS `v_campaignanalysisroi`*/;
/*!50001 DROP VIEW IF EXISTS `v_campaignanalysisroi`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_campaignanalysisroi` AS select `campaign`.`instanceId` AS `instanceId`,`campaign`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`campaign`.`COMPANY_ID` AS `COMPANY_ID`,`campaign`.`PARENT_INSTANCE_ID` AS `PARENT_INSTANCE_ID`,`campaign`.`PARENT_MODULE_UNAME` AS `PARENT_MODULE_UNAME`,`campaign`.`CampaignName` AS `CampaignName`,`campaign`.`Budget` AS `Budget`,`campaign`.`Actual` AS `Actual`,`campaign`.`EstTarget` AS `EstTarget`,`campaign`.`EstPotentialValue` AS `EstPotentialValue`,`campaign`.`ActualValue` AS `ActualValue`,`campaign`.`owner` AS `owner`,`campaign`.`access` AS `access`,`campaign`.`security_level` AS `security_level`,round(((`campaign`.`Actual` / ifnull(`campaign`.`ActualValue`,0)) * 100),2) AS `ROI` from `v_campaignanalysischarts` `campaign` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_util_views`
--

/*!50001 DROP TABLE IF EXISTS `v_util_views`*/;
/*!50001 DROP VIEW IF EXISTS `v_util_views`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_util_views` AS select `cxm_grid`.`TABLE_NAME` AS `view_name`,`cxm_grid`.`GRID_UNAME` AS `reference` from `cxm_grid` where (`cxm_grid`.`TABLE_NAME` like 'v_%') union select distinct `cxm_criteria`.`TABLE_NAME` AS `sp_name`,`cxm_criteria`.`CRITERIA_NAME` AS `reference` from `cxm_criteria` where (`cxm_criteria`.`TABLE_NAME` like 'v_%') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_tickettopcustbyage`
--

/*!50001 DROP TABLE IF EXISTS `v_tickettopcustbyage`*/;
/*!50001 DROP VIEW IF EXISTS `v_tickettopcustbyage`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tickettopcustbyage` AS select distinct `ticket`.`INSTANCE_ID` AS `instanceId`,`ticket`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ticket`.`COMPANY_ID` AS `COMPANY_ID`,`ticket`.`OWNER` AS `owner`,`ticket`.`ACCESS` AS `access`,`ticket`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`ticket`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,1 AS `row_number`,(to_days(now()) - to_days(`CXM_STR_TO_DATE`(`ticket`.`ORGANIZATION_ID`,`ticket`.`COMPANY_ID`,`ticket`.`ENTITY_VALUE_4`))) AS `Age`,(case `ticket`.`PARENT_MODULE_UNAME` when 'Account' then (select `acc`.`ENTITY_VALUE_2` from `cxm_entity_instance_1` `acc` where ((`acc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`acc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`acc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) when 'Contact' then (select concat(`cntc`.`ENTITY_VALUE_4`,' ',`cntc`.`ENTITY_VALUE_6`) from `cxm_entity_instance_3` `cntc` where ((`cntc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`cntc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`cntc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) else 'Unassigned' end) AS `parentName`,(case `ticket`.`PARENT_MODULE_UNAME` when 'Account' then (select convert(concat(`acc`.`ENTITY_VALUE_2`,'::',`acc`.`INSTANCE_ID`,'::Account') using utf8) from `cxm_entity_instance_1` `acc` where ((`acc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`acc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`acc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) when 'Contact' then (select convert(concat(`cntc`.`ENTITY_VALUE_4`,' ',`cntc`.`ENTITY_VALUE_6`,'::',`cntc`.`INSTANCE_ID`,'::Contact') using utf8) from `cxm_entity_instance_3` `cntc` where ((`cntc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`cntc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`cntc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) else 'Unassigned' end) AS `parentNameUrl` from `cxm_entity_instance_67` `ticket` where ((`ticket`.`ENTITY_VALUE_8` <> 'TICKET_STATUS06') and (`ticket`.`ENTITY_VALUE_8` <> 'TICKET_STATUS05')) limit 0,5 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_util_storedproc`
--

/*!50001 DROP TABLE IF EXISTS `v_util_storedproc`*/;
/*!50001 DROP VIEW IF EXISTS `v_util_storedproc`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_util_storedproc` AS select `cxm_grid`.`TABLE_NAME` AS `sp_name`,`cxm_grid`.`GRID_UNAME` AS `reference` from `cxm_grid` where (`cxm_grid`.`TABLE_NAME` like 'procedure%') union select distinct `cxm_page`.`ON_SUBMIT_PROCEDURE` AS `sp_name`,'page' AS `reference` from `cxm_page` union select distinct `cxm_action`.`FUNCTION_NAME` AS `sp_name`,'abl' AS `reference` from `cxm_action` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_acctmaingrid`
--

/*!50001 DROP TABLE IF EXISTS `v_acctmaingrid`*/;
/*!50001 DROP VIEW IF EXISTS `v_acctmaingrid`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_acctmaingrid` AS select `acc`.`INSTANCE_ID` AS `instanceId`,`acc`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`acc`.`COMPANY_ID` AS `COMPANY_ID`,`acc`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`acc`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,`acc`.`ENTITY_VALUE_4` AS `accMgr`,`acc`.`ENTITY_VALUE_1` AS `accountType`,`acc`.`ENTITY_VALUE_2` AS `accountName`,`acc`.`ENTITY_VALUE_2` AS `displayFieldName`,`acc`.`ENTITY_VALUE_10` AS `industry`,`acc`.`ENTITY_VALUE_11` AS `status`,`acc`.`ENTITY_VALUE_8` AS `website1`,(select `v_accountlastactivity`.`last_action` from `v_accountlastactivity` where ((`v_accountlastactivity`.`parentModuleUname` = 'Account') and (`v_accountlastactivity`.`parentInstanceId` = `acc`.`INSTANCE_ID`)) limit 1) AS `last_action`,(select `v_accountlastemail`.`last_action` from `v_accountlastemail` where ((`v_accountlastemail`.`parentModuleUname` = 'Account') and (`v_accountlastemail`.`parentInstanceId` = `acc`.`INSTANCE_ID`)) limit 1) AS `last_email`,concat(`ct`.`ENTITY_VALUE_4`,' ',`ct`.`ENTITY_VALUE_6`) AS `ctname`,convert(concat(`ct`.`ENTITY_VALUE_4`,' ',`ct`.`ENTITY_VALUE_6`,'::',`ct`.`INSTANCE_ID`,'::Contact') using utf8) AS `ctnameurl`,if(isnull(`ct`.`ENTITY_VALUE_12`),convert(concat(`ct`.`ENTITY_VALUE_11`,'') using utf8),convert(concat(`ct`.`ENTITY_VALUE_11`,`ct`.`ENTITY_VALUE_12`) using utf8)) AS `ctphone`,`ct`.`ENTITY_VALUE_24` AS `ctemail`,`ct`.`OWNER` AS `owner`,`ct`.`ACCESS` AS `access`,`acc`.`ENTITY_VALUE_12` AS `email`,`acc`.`SECURITY_LEVEL` AS `securityLevel`,`acc`.`ENTITY_VALUE_56` AS `state`,`acc`.`ENTITY_VALUE_48` AS `mainphone` from (`cxm_entity_instance_1` `acc` left join `cxm_entity_instance_3` `ct` on((`ct`.`INSTANCE_ID` = `acc`.`ENTITY_VALUE_21`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_leadsleadstatus`
--

/*!50001 DROP TABLE IF EXISTS `v_leadsleadstatus`*/;
/*!50001 DROP VIEW IF EXISTS `v_leadsleadstatus`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_leadsleadstatus` AS select `cxm_entity_instance_181`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`cxm_entity_instance_181`.`PARENT_INSTANCE_ID` AS `parentinstanceId`,`cxm_entity_instance_181`.`INSTANCE_ID` AS `instanceId`,`cxm_entity_instance_181`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`cxm_entity_instance_181`.`COMPANY_ID` AS `COMPANY_ID`,`cxm_entity_instance_181`.`OWNER` AS `owner`,`cxm_entity_instance_181`.`ACCESS` AS `access`,`cxm_entity_instance_181`.`SECURITY_LEVEL` AS `security_level`,`cxm_entity_instance_181`.`CREATE_USER` AS `create_user`,`cxm_entity_instance_181`.`ENTITY_VALUE_1` AS `leadStatus`,`cxm_entity_instance_181`.`ENTITY_VALUE_2` AS `startDate`,`cxm_entity_instance_181`.`ENTITY_VALUE_3` AS `endDate`,if((`cxm_entity_instance_181`.`ENTITY_VALUE_4` = 0),(to_days(curdate()) - to_days(str_to_date(`cxm_entity_instance_181`.`ENTITY_VALUE_2`,'%m/%d/%Y'))),`cxm_entity_instance_181`.`ENTITY_VALUE_4`) AS `noOfDays`,`cxm_entity_instance_181`.`ENTITY_VALUE_5` AS `lstage` from `cxm_entity_instance_181` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_contactallemails`
--

/*!50001 DROP TABLE IF EXISTS `v_contactallemails`*/;
/*!50001 DROP VIEW IF EXISTS `v_contactallemails`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_contactallemails` AS select `ac`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ac`.`COMPANY_ID` AS `COMPANY_ID`,`ac`.`parentModuleUname` AS `emailModName`,`ac`.`parentInstanceId` AS `emailModId`,`ac`.`update_date` AS `update_date`,`ac`.`last_action` AS `last_action`,`ac`.`parentInstanceId` AS `parent_instance_id`,`ac`.`parentModuleUname` AS `parent_module_uname` from `v_allemail` `ac` where (`ac`.`parentModuleUname` = 'Contact') union select `ac`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ac`.`COMPANY_ID` AS `COMPANY_ID`,`ac`.`parentModuleUname` AS `emailModName`,`ac`.`parentInstanceId` AS `emailModId`,`ac`.`update_date` AS `update_date`,`ac`.`last_action` AS `last_action`,`s`.`PARENT_INSTANCE_ID` AS `parent_instance_id`,`s`.`PARENT_MODULE_UNAME` AS `parent_module_uname` from (`v_allemail` `ac` join `cxm_entity_instance_2` `s` on(((`ac`.`parentInstanceId` = `s`.`INSTANCE_ID`) and (`ac`.`parentModuleUname` = 'Sales') and (`s`.`PARENT_MODULE_UNAME` = 'Contact')))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_history_activity`
--

/*!50001 DROP TABLE IF EXISTS `v_history_activity`*/;
/*!50001 DROP VIEW IF EXISTS `v_history_activity`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_history_activity` AS select `cxm_activity`.`ACTIVITY_ID` AS `instanceId`,`cxm_activity`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`cxm_activity`.`COMPANY_ID` AS `COMPANY_ID`,`cxm_activity`.`ACTIVITY_NAME` AS `ACTIVITY_NAME`,`cxm_activity`.`ACTIVITY_TYPE` AS `ACTIVITY_TYPE`,`cxm_activity`.`RESULT` AS `RESULT`,`cxm_activity`.`DESCRIPTION` AS `DESCRIPTION`,`cxm_activity`.`THRU_DATE` AS `THRU_DATE`,date_format(`cxm_activity`.`FROM_DATE`,'%m/%d/%Y') AS `FROM_DATE`,`cxm_activity`.`STATUS` AS `STATUS`,`cxm_activity`.`PRIORITY` AS `PRIORITY`,`cxm_activity`.`NOTES` AS `NOTES`,`cxm_activity`.`OWNER` AS `OWNER`,`cxm_activity`.`ACCESS` AS `ACCESS`,`cxm_activity`.`SECURITY_LEVEL` AS `SECURITY_LEVEL`,'activity' AS `moduleUname`,`ent`.`INSTANCE_ID` AS `parentInstanceId`,`ent`.`MODULE_UNAME` AS `parentModuleUname` from (`cxm_activity` join `cxm_activity_entity` `ent` on(((`cxm_activity`.`ACTIVITY_ID` = `ent`.`ACTIVITY_ID`) and (`cxm_activity`.`ORGANIZATION_ID` = `ent`.`ORGANIZATION_ID`) and (`cxm_activity`.`COMPANY_ID` = `ent`.`COMPANY_ID`)))) where (`cxm_activity`.`STATUS` = 'ACT_STATUS_COMPLETED') order by `cxm_activity`.`FROM_DATE` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_userlist`
--

/*!50001 DROP TABLE IF EXISTS `v_userlist`*/;
/*!50001 DROP VIEW IF EXISTS `v_userlist`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_userlist` AS select distinct `u`.`ORGANIZATION_ID` AS `organization_id`,`u`.`COMPANY_ID` AS `company_id`,`u`.`USER_ID` AS `instanceId`,concat(`u`.`FIRST_NAME`,' ',`u`.`LAST_NAME`) AS `name` from (`cxm_user` `u` join `cxm_user_stg_val` `s` on((`u`.`USER_ID` = `s`.`USER_ID`))) where ((`s`.`PROPERTY_UNAME` = 'userPosition') and (`s`.`PROPERTY_VALUE` like 'UP_%')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_sales_dashboard`
--

/*!50001 DROP TABLE IF EXISTS `v_sales_dashboard`*/;
/*!50001 DROP VIEW IF EXISTS `v_sales_dashboard`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_sales_dashboard` AS select distinct `salesoppurtunity`.`INSTANCE_ID` AS `INSTANCE_ID`,`salesoppurtunity`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`salesoppurtunity`.`COMPANY_ID` AS `COMPANY_ID`,'SuperAdmin' AS `owner`,'public' AS `access`,`salesoppurtunity`.`PARENT_MODULE_UNAME` AS `PARENT_MODULE_UNAME`,`salesoppurtunity`.`PARENT_INSTANCE_ID` AS `PARENT_INSTANCE_ID`,`salesoppurtunity`.`closeamount` AS `closeamount`,`salesoppurtunity`.`EstAmount` AS `EstAmount`,`salesoppurtunity`.`count` AS `count`,`salesoppurtunity`.`closedate` AS `closedate`,`salesoppurtunity`.`EstCloseDate` AS `EstCloseDate`,`salesoppurtunity`.`DateCreated` AS `DateCreated`,`salesoppurtunity`.`Status` AS `Status`,`comm`.`ENTITY_VALUE_1` AS `SalesPersonID` from (`v_sales_personcnt` `salesoppurtunity` join `cxm_entity_instance_165` `comm` on(((`comm`.`ORGANIZATION_ID` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`comm`.`COMPANY_ID` = `salesoppurtunity`.`COMPANY_ID`) and (`comm`.`PARENT_INSTANCE_ID` = `salesoppurtunity`.`INSTANCE_ID`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_myticketsimpleindvgrid`
--

/*!50001 DROP TABLE IF EXISTS `v_myticketsimpleindvgrid`*/;
/*!50001 DROP VIEW IF EXISTS `v_myticketsimpleindvgrid`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_myticketsimpleindvgrid` AS select distinct `ticket`.`INSTANCE_ID` AS `instanceId`,`ticket`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ticket`.`COMPANY_ID` AS `COMPANY_ID`,`ticket`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`ticket`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,`ticket`.`ENTITY_VALUE_71` AS `ticketID`,`ticket`.`ENTITY_VALUE_4` AS `recdDate`,`ticket`.`ENTITY_VALUE_21` AS `recdTime`,`ticket`.`ENTITY_VALUE_13` AS `ticketTitle`,`ticket`.`ENTITY_VALUE_70` AS `assignedType`,`ticket`.`ENTITY_VALUE_17` AS `assignedTo`,`ticket`.`ENTITY_VALUE_8` AS `status`,`ticket`.`ENTITY_VALUE_16` AS `ticketType`,`ticket`.`ENTITY_VALUE_14` AS `urgency`,concat(`pcntc`.`ENTITY_VALUE_4`,' ',`pcntc`.`ENTITY_VALUE_6`) AS `pconName`,convert(concat(`pcntc`.`ENTITY_VALUE_4`,' ',`pcntc`.`ENTITY_VALUE_6`,'::',`pcntc`.`INSTANCE_ID`,'::Contact') using utf8) AS `pconNameUrl`,convert(concat(`pcntc`.`ENTITY_VALUE_11`,`pcntc`.`ENTITY_VALUE_12`) using utf8) AS `phone`,`ticket`.`ENTITY_VALUE_22` AS `email`,`ticket`.`OWNER` AS `owner`,`ticket`.`ACCESS` AS `access`,`pcntc`.`ENTITY_VALUE_56` AS `state` from (`cxm_entity_instance_67` `ticket` left join `cxm_entity_instance_3` `pcntc` on(((`pcntc`.`INSTANCE_ID` = `ticket`.`ENTITY_VALUE_1`) and (`pcntc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`pcntc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`)))) where ((`ticket`.`ENTITY_VALUE_8` <> 'TICKET_STATUS06') and (`ticket`.`ENTITY_VALUE_8` <> 'TICKET_STATUS05') and (`ticket`.`ENTITY_VALUE_70` = 'INDIVIDUAL')) order by `ticket`.`ENTITY_VALUE_14`,`ticket`.`INSTANCE_ID` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_util_criteria`
--

/*!50001 DROP TABLE IF EXISTS `v_util_criteria`*/;
/*!50001 DROP VIEW IF EXISTS `v_util_criteria`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_util_criteria` AS (select `cxm_entity_field`.`CRITERIA_NAME` AS `CRITERIA_NAME` from `cxm_entity_field` where ((`cxm_entity_field`.`CRITERIA_NAME` <> ' ') and (`cxm_entity_field`.`FIELD_TYPE` like '%query%'))) union (select `cxm_grid`.`CRITERIA_NAME` AS `CRITERIA_NAME` from `cxm_grid` where (`cxm_grid`.`CRITERIA_NAME` <> ' ')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_campaignmgrgrid`
--

/*!50001 DROP TABLE IF EXISTS `v_campaignmgrgrid`*/;
/*!50001 DROP VIEW IF EXISTS `v_campaignmgrgrid`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_campaignmgrgrid` AS select distinct `campaign`.`INSTANCE_ID` AS `instanceId`,`campaign`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`campaign`.`COMPANY_ID` AS `COMPANY_ID`,'1' AS `PARENT_INSTANCE_ID`,'CampaignAnalysis' AS `PARENT_MODULE_UNAME`,`campaign`.`ENTITY_VALUE_1` AS `CampaignName`,convert(concat(`campaign`.`ENTITY_VALUE_1`,'::',`campaign`.`INSTANCE_ID`,'::Campaign') using utf8) AS `CampaignNameUrl`,(select `cxm_lookup`.`LVALUE` from `cxm_lookup` where ((`cxm_lookup`.`LKEY` = convert(`campaign`.`ENTITY_VALUE_2` using utf8)) and (`cxm_lookup`.`LTYPE` = 'CAMP_STATUS') and (`cxm_lookup`.`ORGANIZATION_ID` = `campaign`.`ORGANIZATION_ID`) and (`cxm_lookup`.`COMPANY_ID` = `campaign`.`COMPANY_ID`))) AS `Stat`,(select `cxm_lookup`.`LVALUE` from `cxm_lookup` where ((`cxm_lookup`.`LKEY` = convert(`campaign`.`ENTITY_VALUE_3` using utf8)) and (`cxm_lookup`.`LTYPE` = 'CAMP_TYPE') and (`cxm_lookup`.`ORGANIZATION_ID` = `campaign`.`ORGANIZATION_ID`) and (`cxm_lookup`.`COMPANY_ID` = `campaign`.`COMPANY_ID`))) AS `Type`,`campaign`.`ENTITY_VALUE_4` AS `Budget`,`campaign`.`ENTITY_VALUE_5` AS `Actual`,`campaign`.`ENTITY_VALUE_6` AS `StartDate`,`campaign`.`ENTITY_VALUE_7` AS `StopDate`,`campaign`.`ENTITY_VALUE_8` AS `EstTarget`,`campaign`.`ENTITY_VALUE_9` AS `CampaignManager`,(select concat(concat(`cxm_user`.`FIRST_NAME`,' '),`cxm_user`.`LAST_NAME`) from `cxm_user` where ((`cxm_user`.`USER_ID` = convert(`campaign`.`ENTITY_VALUE_9` using utf8)) and (`cxm_user`.`ORGANIZATION_ID` = `campaign`.`ORGANIZATION_ID`) and (`cxm_user`.`COMPANY_ID` = `campaign`.`COMPANY_ID`))) AS `CampaignManagerName`,count(`sales`.`INSTANCE_ID`) AS `SalesOpportunities`,sum(`sales`.`ENTITY_VALUE_10`) AS `EstPotentialValue`,sum(`sales`.`ENTITY_VALUE_13`) AS `ActualValue`,`campaign`.`OWNER` AS `owner`,`campaign`.`ACCESS` AS `access`,`campaign`.`CREATE_USER` AS `CREATE_USER`,`campaign`.`UPDATE_USER` AS `UPDATE_USER`,`campaign`.`CREATE_DATE` AS `CREATE_DATE`,`campaign`.`UPDATE_DATE` AS `UPDATE_DATE`,`campaign`.`ENTITY_VALUE_3` AS `TypeLKEY`,`campaign`.`ENTITY_VALUE_2` AS `StatusLKEY`,sum(if((`sales`.`ENTITY_VALUE_6` = 'OPPORTUNITY2'),`sales`.`ENTITY_VALUE_13`,0)) AS `rev`,sum(if((`sales`.`ENTITY_VALUE_6` = 'OPPORTUNITY2'),1,0)) AS `closeso`,sum((to_days(`cxm_str_to_date`(`campaign`.`ORGANIZATION_ID`,`campaign`.`COMPANY_ID`,`sales`.`ENTITY_VALUE_12`)) - to_days(`cxm_str_to_date`(`campaign`.`ORGANIZATION_ID`,`campaign`.`COMPANY_ID`,`sales`.`ENTITY_VALUE_5`)))) AS `totaldays` from (`cxm_entity_instance_52` `campaign` join `cxm_entity_instance_2` `sales` on(((`sales`.`ENTITY_VALUE_19` = `campaign`.`INSTANCE_ID`) and (`sales`.`ORGANIZATION_ID` = `campaign`.`ORGANIZATION_ID`) and (`sales`.`COMPANY_ID` = `campaign`.`COMPANY_ID`)))) group by `campaign`.`INSTANCE_ID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_sales_personcnt`
--

/*!50001 DROP TABLE IF EXISTS `v_sales_personcnt`*/;
/*!50001 DROP VIEW IF EXISTS `v_sales_personcnt`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_sales_personcnt` AS select `salesoppurtunity`.`INSTANCE_ID` AS `INSTANCE_ID`,`salesoppurtunity`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`salesoppurtunity`.`COMPANY_ID` AS `COMPANY_ID`,`salesoppurtunity`.`PARENT_MODULE_UNAME` AS `PARENT_MODULE_UNAME`,`salesoppurtunity`.`PARENT_INSTANCE_ID` AS `PARENT_INSTANCE_ID`,`salesoppurtunity`.`ENTITY_VALUE_13` AS `closeamount`,`salesoppurtunity`.`ENTITY_VALUE_10` AS `EstAmount`,`salesoppurtunity`.`ENTITY_VALUE_12` AS `closedate`,`salesoppurtunity`.`ENTITY_VALUE_9` AS `EstCloseDate`,`salesoppurtunity`.`ENTITY_VALUE_5` AS `DateCreated`,`salesoppurtunity`.`ENTITY_VALUE_6` AS `Status`,(select count(0) from `cxm_entity_instance_165` `comm` where ((`comm`.`PARENT_INSTANCE_ID` = `salesoppurtunity`.`INSTANCE_ID`) and (`comm`.`PARENT_MODULE_UNAME` = 'Sales') and (`salesoppurtunity`.`ORGANIZATION_ID` = `comm`.`ORGANIZATION_ID`) and (`salesoppurtunity`.`COMPANY_ID` = `comm`.`COMPANY_ID`))) AS `count` from `cxm_entity_instance_2` `salesoppurtunity` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_customerservice_users`
--

/*!50001 DROP TABLE IF EXISTS `v_customerservice_users`*/;
/*!50001 DROP VIEW IF EXISTS `v_customerservice_users`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_customerservice_users` AS select `u`.`USER_ID` AS `instanceId`,`u`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`u`.`COMPANY_ID` AS `COMPANY_ID`,`u`.`USER_UNAME` AS `UName`,concat(`u`.`FIRST_NAME`,' ',`u`.`LAST_NAME`) AS `Name` from (`cxm_user` `u` join `cxm_user_stg_val` `s` on(((`u`.`USER_ID` = `s`.`USER_ID`) and (`s`.`PROPERTY_UNAME` = 'userPosition') and (`s`.`PROPERTY_VALUE` in ('UP_CSR','UP_CSMGR')) and (`u`.`STATUS` = 'A')))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_accountmaxactivity`
--

/*!50001 DROP TABLE IF EXISTS `v_accountmaxactivity`*/;
/*!50001 DROP VIEW IF EXISTS `v_accountmaxactivity`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_accountmaxactivity` AS select `v_accountallcompletedactivity`.`parent_module_uname` AS `parent_module_uname`,`v_accountallcompletedactivity`.`parent_instance_id` AS `parent_instance_id`,max(`v_accountallcompletedactivity`.`update_date`) AS `update_date` from `v_accountallcompletedactivity` group by `v_accountallcompletedactivity`.`parent_module_uname`,`v_accountallcompletedactivity`.`parent_instance_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_manager_list`
--

/*!50001 DROP TABLE IF EXISTS `v_manager_list`*/;
/*!50001 DROP VIEW IF EXISTS `v_manager_list`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_manager_list` AS select `u`.`ORGANIZATION_ID` AS `organization_id`,`u`.`COMPANY_ID` AS `company_id`,`ur`.`USER_ID` AS `USER_ID`,`u`.`FIRST_NAME` AS `FIRST_NAME`,`u`.`LAST_NAME` AS `last_name` from ((`cxm_role_user_rel` `ur` join `cxm_user` `u` on((`ur`.`USER_ID` = `u`.`USER_ID`))) join `cxm_role` `r` on((`ur`.`ROLE_ID` = `r`.`ROLE_ID`))) where ((`r`.`IS_SUPERVISOR` = 1) and (`u`.`STATUS` = 'A')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_history_audit`
--

/*!50001 DROP TABLE IF EXISTS `v_history_audit`*/;
/*!50001 DROP VIEW IF EXISTS `v_history_audit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_history_audit` AS select `cxm_audit_log`.`LOG_ID` AS `instanceId`,`cxm_audit_log`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`cxm_audit_log`.`COMPANY_ID` AS `COMPANY_ID`,'SuperAdmin' AS `owner`,'public' AS `access`,`cxm_audit_log`.`AUDIT_LEVEL` AS `AUDIT_LEVEL`,`cxm_audit_log`.`SESSION_ID` AS `SESSION_ID`,`cxm_audit_log`.`DATE_TIME_GROUP` AS `DATE_TIME_GROUP`,`cxm_audit_log`.`USER_UNAME` AS `USER_UNAME`,`cxm_audit_log`.`USER_IP` AS `USER_IP`,`cxm_audit_log`.`USER_ACTION` AS `USER_ACTION`,`cxm_audit_log`.`APPLICATION_NAME` AS `APPLICATION_NAME`,`cxm_audit_log`.`TYPE_OF_EVENT` AS `TYPE_OF_EVENT`,`cxm_audit_log`.`ENTITY_TYPE` AS `parentModuleUname`,`cxm_audit_log`.`ENTITY_ID` AS `parentInstanceId`,`cxm_audit_log`.`PARENT_ENTITY_TYPE` AS `PARENT_ENTITY_TYPE`,`cxm_audit_log`.`PARENT_ENTITY_ID` AS `PARENT_ENTITY_ID`,`cxm_audit_log`.`ACTION_STATUS` AS `ACTION_STATUS`,`cxm_audit_log`.`TIME_TAKEN` AS `TIME_TAKEN`,`cxm_audit_log_details`.`ATTRIBUTE_NAME` AS `attribute_name`,concat(`cxm_audit_log_details`.`ATTRIBUTE_INITIAL_VALUE`,' to ',`cxm_audit_log_details`.`ATTRIBUTE_CHANGED_VALUE`) AS `attrValue` from (`cxm_audit_log` left join `cxm_audit_log_details` on((`cxm_audit_log`.`LOG_ID` = `cxm_audit_log_details`.`LOG_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_customerservice_mgrs`
--

/*!50001 DROP TABLE IF EXISTS `v_customerservice_mgrs`*/;
/*!50001 DROP VIEW IF EXISTS `v_customerservice_mgrs`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_customerservice_mgrs` AS select `u`.`USER_ID` AS `instanceId`,`u`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`u`.`COMPANY_ID` AS `COMPANY_ID`,concat(`u`.`FIRST_NAME`,' ',`u`.`LAST_NAME`) AS `Name` from (`cxm_user` `u` join `cxm_user_stg_val` `s` on(((`u`.`USER_ID` = `s`.`USER_ID`) and (`s`.`PROPERTY_UNAME` = 'userPosition') and (`s`.`PROPERTY_VALUE` = 'UP_CSMGR') and (`u`.`STATUS` = 'A')))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_allcompletedactivity`
--

/*!50001 DROP TABLE IF EXISTS `v_allcompletedactivity`*/;
/*!50001 DROP VIEW IF EXISTS `v_allcompletedactivity`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_allcompletedactivity` AS select `a`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`a`.`COMPANY_ID` AS `COMPANY_ID`,`ae`.`MODULE_UNAME` AS `activityModName`,`ae`.`INSTANCE_ID` AS `activityModId`,`a`.`UPDATE_DATE` AS `update_date`,`a`.`ACTIVITY_TYPE` AS `activity_type` from (`cxm_activity` `a` join `cxm_activity_entity` `ae` on((`a`.`ACTIVITY_ID` = `ae`.`ACTIVITY_ID`))) where (`a`.`STATUS` = 'ACT_STATUS_COMPLETED') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_countylist`
--

/*!50001 DROP TABLE IF EXISTS `v_countylist`*/;
/*!50001 DROP VIEW IF EXISTS `v_countylist`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_countylist` AS select distinct trim(`cxm_entity_instance_4`.`ENTITY_VALUE_6`) AS `name` from `cxm_entity_instance_4` where ((`cxm_entity_instance_4`.`ENTITY_VALUE_6` is not null) and (trim(`cxm_entity_instance_4`.`ENTITY_VALUE_6`) <> '')) union select distinct trim(`cxm_entity_instance_1`.`ENTITY_VALUE_55`) AS `name` from `cxm_entity_instance_1` where ((`cxm_entity_instance_1`.`ENTITY_VALUE_55` is not null) and (trim(`cxm_entity_instance_1`.`ENTITY_VALUE_55`) <> '')) union select distinct trim(`cxm_entity_instance_3`.`ENTITY_VALUE_65`) AS `name` from `cxm_entity_instance_3` where ((`cxm_entity_instance_3`.`ENTITY_VALUE_55` is not null) and (trim(`cxm_entity_instance_3`.`ENTITY_VALUE_55`) <> '')) union select distinct trim(`cxm_entity_instance_6`.`ENTITY_VALUE_51`) AS `name` from `cxm_entity_instance_6` where ((`cxm_entity_instance_6`.`ENTITY_VALUE_51` is not null) and (trim(`cxm_entity_instance_6`.`ENTITY_VALUE_51`) <> '')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_rpt_tickets_simple`
--

/*!50001 DROP TABLE IF EXISTS `v_rpt_tickets_simple`*/;
/*!50001 DROP VIEW IF EXISTS `v_rpt_tickets_simple`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_rpt_tickets_simple` AS select distinct `ticket`.`INSTANCE_ID` AS `instanceId`,`ticket`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ticket`.`COMPANY_ID` AS `COMPANY_ID`,`ticket`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`ticket`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,`ticket`.`ENTITY_VALUE_71` AS `ticketID`,`ticket`.`ENTITY_VALUE_4` AS `recdDate`,`ticket`.`ENTITY_VALUE_21` AS `recdTime`,`ticket`.`ENTITY_VALUE_5` AS `dateNeeded`,`ticket`.`ENTITY_VALUE_24` AS `timeNeeded`,`ticket`.`ENTITY_VALUE_13` AS `ticketTitle`,`ticket`.`ENTITY_VALUE_11` AS `severity`,`ticket`.`ENTITY_VALUE_8` AS `ticketStatus`,`ticket`.`ENTITY_VALUE_16` AS `ticketType`,`ticket`.`ENTITY_VALUE_14` AS `urgency`,`ticket`.`ENTITY_VALUE_3` AS `category`,`ticket`.`ENTITY_VALUE_17` AS `assignedTo`,`ticket`.`ENTITY_VALUE_18` AS `touchPoint`,`ticket`.`ENTITY_VALUE_2` AS `ticketMgr`,`ticket`.`ENTITY_VALUE_1` AS `pconid`,`ticket`.`ENTITY_VALUE_19` AS `account`,`ticket`.`ENTITY_VALUE_20` AS `contact`,`ticket`.`UPDATE_DATE` AS `updateDate`,`ticket`.`CREATE_DATE` AS `createDate`,`ticket`.`ENTITY_VALUE_25` AS `compDate`,`ticket`.`OWNER` AS `owner`,`ticket`.`ACCESS` AS `access` from `cxm_entity_instance_67` `ticket` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_salesaccountcontactlist`
--

/*!50001 DROP TABLE IF EXISTS `v_salesaccountcontactlist`*/;
/*!50001 DROP VIEW IF EXISTS `v_salesaccountcontactlist`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_salesaccountcontactlist` AS select `c`.`INSTANCE_ID` AS `instanceId`,`c`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`c`.`COMPANY_ID` AS `COMPANY_ID`,`c`.`OWNER` AS `owner`,`c`.`ACCESS` AS `access`,`c`.`SECURITY_LEVEL` AS `security_level`,'Sales' AS `parentModuleUname`,if((`s`.`PARENT_INSTANCE_ID` = 0),0,`s`.`INSTANCE_ID`) AS `parentInstanceId`,`l`.`LVALUE` AS `contactType`,`c`.`ENTITY_VALUE_24` AS `email`,concat(`c`.`ENTITY_VALUE_4`,' ',`c`.`ENTITY_VALUE_6`) AS `full_name`,`c`.`ENTITY_VALUE_11` AS `business`,`c`.`ENTITY_VALUE_17` AS `cell`,`c`.`ENTITY_VALUE_8` AS `title`,`c`.`ENTITY_VALUE_12` AS `ext`,`s`.`PARENT_MODULE_UNAME` AS `PARENT_MODULE_UNAME`,`s`.`PARENT_INSTANCE_ID` AS `PARENT_INSTANCE_ID` from ((`cxm_entity_instance_3` `c` left join `cxm_lookup` `l` on(((`c`.`ORGANIZATION_ID` = `l`.`ORGANIZATION_ID`) and (`c`.`COMPANY_ID` = `l`.`COMPANY_ID`) and (`c`.`ENTITY_VALUE_1` = `l`.`LKEY`) and (`l`.`LTYPE` = 'CONTACT_TYPE')))) join `cxm_entity_instance_2` `s` on((`c`.`PARENT_INSTANCE_ID` = `s`.`PARENT_INSTANCE_ID`))) where ((`c`.`PARENT_MODULE_UNAME` = `s`.`PARENT_MODULE_UNAME`) and (`c`.`PARENT_INSTANCE_ID` = `s`.`PARENT_INSTANCE_ID`)) order by `l`.`SORT_ORDER` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_calendarsettingforuser`
--

/*!50001 DROP TABLE IF EXISTS `v_calendarsettingforuser`*/;
/*!50001 DROP VIEW IF EXISTS `v_calendarsettingforuser`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_calendarsettingforuser` AS select `a`.`CALENDAR_UNAME` AS `calendar_uname`,`b`.`USER_UNAME` AS `user_uname` from (`cxm_calendar` `a` join `cxm_user` `b`) where ((`a`.`OWNER` = `b`.`USER_UNAME`) and (`a`.`ACCESS` = 'private')) union select `a`.`CALENDAR_UNAME` AS `calendar_uname`,`b`.`USER_UNAME` AS `user_uname` from (((`cxm_calendar` `a` join `cxm_user` `b`) join `cxm_role_user_rel` `c`) join `cxm_calendar_role_privileges` `y`) where ((`a`.`ACCESS` = 'public') and `c`.`ROLE_ID` in (select `cxm_calendar_role_privileges`.`ROLE_ID` from `cxm_calendar_role_privileges` where (`cxm_calendar_role_privileges`.`PRIVILEGES_C_RM_RA_UM_UA_DM_DA` > 0))) union select `a`.`CALENDAR_UNAME` AS `calendar_uname`,`b`.`USER_UNAME` AS `user_uname` from (`cxm_calendar` `a` join `cxm_user` `b`) where `b`.`USER_UNAME` in (select `c`.`USER_UNAME` from (((`cxm_role` `d` join `cxm_user` `c`) join `cxm_role_user_rel` `z`) join `cxm_calendar_role_privileges` `y`) where ((`d`.`ROLE_ID` = `z`.`ROLE_ID`) and (`c`.`USER_ID` = `z`.`USER_ID`) and `d`.`ROLE_ID` in (select `cxm_calendar_role_privileges`.`ROLE_ID` from `cxm_calendar_role_privileges` where (`cxm_calendar_role_privileges`.`PRIVILEGES_C_RM_RA_UM_UA_DM_DA` > 0)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_calendarsettinguid`
--

/*!50001 DROP TABLE IF EXISTS `v_calendarsettinguid`*/;
/*!50001 DROP VIEW IF EXISTS `v_calendarsettinguid`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_calendarsettinguid` AS select distinct `c`.`USER_ID` AS `user_id`,`c`.`CALENDAR_SETTING_UNAME` AS `calendar_setting_uname` from `cxm_user_calendar_settings` `c` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_tickettopcustbyopencases`
--

/*!50001 DROP TABLE IF EXISTS `v_tickettopcustbyopencases`*/;
/*!50001 DROP VIEW IF EXISTS `v_tickettopcustbyopencases`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tickettopcustbyopencases` AS select distinct `ticket`.`INSTANCE_ID` AS `instanceId`,`ticket`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ticket`.`COMPANY_ID` AS `COMPANY_ID`,`ticket`.`OWNER` AS `owner`,`ticket`.`ACCESS` AS `access`,`ticket`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`ticket`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,1 AS `row_number`,count(`ticket`.`INSTANCE_ID`) AS `numTickets`,(case `ticket`.`PARENT_MODULE_UNAME` when 'Account' then (select `acc`.`ENTITY_VALUE_2` from `cxm_entity_instance_1` `acc` where ((`acc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`acc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`acc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) when 'Contact' then (select concat(`cntc`.`ENTITY_VALUE_4`,' ',`cntc`.`ENTITY_VALUE_6`) from `cxm_entity_instance_3` `cntc` where ((`cntc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`cntc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`cntc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) else 'Unassigned' end) AS `parentName`,(case `ticket`.`PARENT_MODULE_UNAME` when 'Account' then (select convert(concat(`acc`.`ENTITY_VALUE_2`,'::',`acc`.`INSTANCE_ID`,'::Account') using utf8) from `cxm_entity_instance_1` `acc` where ((`acc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`acc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`acc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) when 'Contact' then (select convert(concat(`cntc`.`ENTITY_VALUE_4`,' ',`cntc`.`ENTITY_VALUE_6`,'::',`cntc`.`INSTANCE_ID`,'::Contact') using utf8) from `cxm_entity_instance_3` `cntc` where ((`cntc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`cntc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`cntc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) else 'Unassigned' end) AS `parentNameUrl` from `cxm_entity_instance_67` `ticket` where ((`ticket`.`ENTITY_VALUE_8` <> 'TICKET_STATUS06') and (`ticket`.`ENTITY_VALUE_8` <> 'TICKET_STATUS05')) group by `ticket`.`PARENT_MODULE_UNAME`,`ticket`.`PARENT_INSTANCE_ID` order by count(`ticket`.`INSTANCE_ID`) desc limit 0,5 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_ticket_parts`
--

/*!50001 DROP TABLE IF EXISTS `v_ticket_parts`*/;
/*!50001 DROP VIEW IF EXISTS `v_ticket_parts`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ticket_parts` AS select `p`.`INSTANCE_ID` AS `instanceId`,`p`.`PARENT_INSTANCE_ID` AS `TTId`,`tt`.`PARENT_INSTANCE_ID` AS `TaskId`,`p`.`ENTITY_VALUE_2` AS `pcode`,`p`.`ENTITY_VALUE_4` AS `pdesc`,`p`.`ENTITY_VALUE_3` AS `pnum`,`p`.`ENTITY_VALUE_6` AS `psn1`,`p`.`ENTITY_VALUE_7` AS `psn2`,`p`.`ENTITY_VALUE_9` AS `totalCost`,`p`.`ENTITY_VALUE_11` AS `psla`,`p`.`ENTITY_VALUE_12` AS `prma`,`p`.`ENTITY_VALUE_13` AS `billable`,`p`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`p`.`COMPANY_ID` AS `COMPANY_ID`,`p`.`OWNER` AS `owner`,`p`.`ACCESS` AS `access`,`p`.`SECURITY_LEVEL` AS `security_level`,(select `cxm_entity_instance_159`.`PARENT_INSTANCE_ID` from `cxm_entity_instance_159` where (`cxm_entity_instance_159`.`INSTANCE_ID` = `tt`.`PARENT_INSTANCE_ID`)) AS `parentInstanceId`,'Ticket' AS `parentModuleUname` from (`cxm_entity_instance_63` `p` join `cxm_entity_instance_160` `tt` on((`tt`.`INSTANCE_ID` = `p`.`PARENT_INSTANCE_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_util_eventlist`
--

/*!50001 DROP TABLE IF EXISTS `v_util_eventlist`*/;
/*!50001 DROP VIEW IF EXISTS `v_util_eventlist`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_util_eventlist` AS select `cxm_page`.`MODULE_UNAME` AS `module_uname`,`cxm_page`.`EVENT_ON_LOAD` AS `event_name` from `cxm_page` union select `cxm_page`.`MODULE_UNAME` AS `module_uname`,`cxm_page`.`EVENT_ON_SUBMIT` AS `event_name` from `cxm_page` union select `cxm_page`.`MODULE_UNAME` AS `module_uname`,`cxm_page`.`ON_DELETE_EVENT` AS `event_name` from `cxm_page` union select `cxm_page`.`MODULE_UNAME` AS `module_uname`,`cxm_page`.`ON_ADD_EVENT` AS `event_name` from `cxm_page` union select `cxm_page`.`MODULE_UNAME` AS `module_uname`,`cxm_page`.`ON_CANCEL_EVENT` AS `event_name` from `cxm_page` union select `cxm_page_field_for_view`.`MODULE_UNAME` AS `module_uname`,`cxm_page_field_for_view`.`EVENT_ON_CHANGE` AS `event_name` from `cxm_page_field_for_view` union select '' AS `module_uname`,`cxm_grid_fields`.`EVENT_ON_CHANGE` AS `event_name` from `cxm_grid_fields` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_leads`
--

/*!50001 DROP TABLE IF EXISTS `v_leads`*/;
/*!50001 DROP VIEW IF EXISTS `v_leads`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_leads` AS select `cxm_entity_instance_6`.`INSTANCE_ID` AS `instanceId`,`cxm_entity_instance_6`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`cxm_entity_instance_6`.`COMPANY_ID` AS `COMPANY_ID`,`cxm_entity_instance_6`.`ACCESS` AS `ACCESS`,'' AS `PARENT_MODULE_UNAME`,0 AS `PARENT_INSTANCE_ID`,`cxm_entity_instance_6`.`ENTITY_VALUE_1` AS `Account`,`cxm_entity_instance_6`.`ENTITY_VALUE_4` AS `Address`,`cxm_entity_instance_6`.`ENTITY_VALUE_12` AS `AssignedDate`,`cxm_entity_instance_6`.`ENTITY_VALUE_13` AS `AssignedTo`,`cxm_entity_instance_6`.`ENTITY_VALUE_5` AS `City`,`cxm_entity_instance_6`.`ENTITY_VALUE_9` AS `email`,`cxm_entity_instance_6`.`ENTITY_VALUE_2` AS `firstName`,`cxm_entity_instance_6`.`ENTITY_VALUE_3` AS `lastName`,`cxm_entity_instance_6`.`ENTITY_VALUE_15` AS `leadStatus`,`cxm_entity_instance_6`.`ENTITY_VALUE_71` AS `RecordsCreated`,`cxm_entity_instance_6`.`ENTITY_VALUE_34` AS `leadRanking`,`GETIMAGEFROMLOOKUP`(`cxm_entity_instance_6`.`ENTITY_VALUE_34`) AS `leadRankingImage`,(select convert(concat(convert(`v_lastactivity`.`last_action_type` using utf8),':',convert(`v_lastactivity`.`last_action` using utf8)) using utf8) from `v_lastactivity` where ((`v_lastactivity`.`parentModuleUname` = 'Leads') and (`v_lastactivity`.`parentInstanceId` = `cxm_entity_instance_6`.`INSTANCE_ID`) and (`cxm_entity_instance_6`.`ORGANIZATION_ID` = `cxm_entity_instance_6`.`ORGANIZATION_ID`) and (`cxm_entity_instance_6`.`COMPANY_ID` = `cxm_entity_instance_6`.`COMPANY_ID`)) order by `v_lastactivity`.`last_action` desc limit 0,1) AS `last_action`,(select `v_lastemail`.`last_action` from `v_lastemail` where ((`v_lastemail`.`parentModuleUname` = 'Leads') and (`v_lastemail`.`parentInstanceId` = `cxm_entity_instance_6`.`INSTANCE_ID`) and (`cxm_entity_instance_6`.`ORGANIZATION_ID` = `cxm_entity_instance_6`.`ORGANIZATION_ID`) and (`cxm_entity_instance_6`.`COMPANY_ID` = `cxm_entity_instance_6`.`COMPANY_ID`)) order by `v_lastemail`.`last_action` desc limit 0,1) AS `last_email`,`cxm_entity_instance_6`.`ENTITY_VALUE_8` AS `Phone`,`CXM_STR_TO_DATE`(1,1,`cxm_entity_instance_6`.`ENTITY_VALUE_11`) AS `ReceivedDate`,`cxm_entity_instance_6`.`ENTITY_VALUE_10` AS `source`,`cxm_entity_instance_6`.`ENTITY_VALUE_6` AS `State`,`cxm_entity_instance_6`.`ENTITY_VALUE_16` AS `SalesStage`,`cxm_entity_instance_6`.`ENTITY_VALUE_55` AS `salesStageStatus`,`cxm_entity_instance_6`.`OWNER` AS `owner`,'scriptCall' AS `scriptCall` from `cxm_entity_instance_6` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_contactmaingrid`
--

/*!50001 DROP TABLE IF EXISTS `v_contactmaingrid`*/;
/*!50001 DROP VIEW IF EXISTS `v_contactmaingrid`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_contactmaingrid` AS select `cont`.`INSTANCE_ID` AS `instanceId`,`cont`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`cont`.`COMPANY_ID` AS `COMPANY_ID`,`cont`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`cont`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,`cont`.`ENTITY_VALUE_4` AS `firstName`,`cont`.`ENTITY_VALUE_6` AS `lastName`,`cont`.`ENTITY_VALUE_2` AS `accountInContact`,`cont`.`ENTITY_VALUE_4` AS `displayFieldName`,`cont`.`ENTITY_VALUE_9` AS `department`,`cont`.`ENTITY_VALUE_8` AS `title`,`cont`.`ENTITY_VALUE_11` AS `business`,`cont`.`ENTITY_VALUE_17` AS `mobile`,`cont`.`ENTITY_VALUE_24` AS `email1`,`cont`.`ENTITY_VALUE_23` AS `contactRole`,`cont`.`ENTITY_VALUE_3` AS `accMgrId`,`cont`.`ENTITY_VALUE_3` AS `manager`,`cont`.`OWNER` AS `owner`,`cont`.`ACCESS` AS `ACCESS`,(select `v_contactlastactivity`.`last_action` from `v_contactlastactivity` where ((`v_contactlastactivity`.`parentModuleUname` = 'Contact') and (`v_contactlastactivity`.`parentInstanceId` = `cont`.`INSTANCE_ID`)) limit 1) AS `last_action`,(select `v_contactlastemail`.`last_action` from `v_contactlastemail` where ((`v_contactlastemail`.`parentModuleUname` = 'Contact') and (`v_contactlastemail`.`parentInstanceId` = `cont`.`INSTANCE_ID`)) limit 1) AS `last_email`,`cont`.`SECURITY_LEVEL` AS `securityLevel`,`cont`.`ENTITY_VALUE_56` AS `state` from `cxm_entity_instance_3` `cont` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_reassign_users`
--

/*!50001 DROP TABLE IF EXISTS `v_reassign_users`*/;
/*!50001 DROP VIEW IF EXISTS `v_reassign_users`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_reassign_users` AS select `u`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`u`.`COMPANY_ID` AS `COMPANY_ID`,`u`.`LKEY` AS `lkey`,`u`.`LVALUE` AS `lvalue` from `cxm_lookup` `u` where ((`u`.`LTYPE` = 'USR_POSITION') and (`u`.`STATUS` = 'A')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_salesclosedoppcurrmonth`
--

/*!50001 DROP TABLE IF EXISTS `v_salesclosedoppcurrmonth`*/;
/*!50001 DROP VIEW IF EXISTS `v_salesclosedoppcurrmonth`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_salesclosedoppcurrmonth` AS select distinct `sales`.`INSTANCE_ID` AS `instanceId`,`sales`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`sales`.`COMPANY_ID` AS `COMPANY_ID`,`sales`.`OWNER` AS `owner`,`sales`.`ACCESS` AS `access`,`sales`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`sales`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,`sales`.`INSTANCE_ID` AS `opportunityName`,1 AS `row_number`,`sales`.`ENTITY_VALUE_13` AS `sumAmount` from `cxm_entity_instance_2` `sales` where ((`sales`.`ENTITY_VALUE_6` = 'OPPORTUNITY2') and (`CXM_STR_TO_DATE`(`sales`.`ORGANIZATION_ID`,`sales`.`COMPANY_ID`,`sales`.`ENTITY_VALUE_5`) between `CXM_STR_TO_DATE`(`sales`.`ORGANIZATION_ID`,`sales`.`COMPANY_ID`,date_format(now(),'%m/01/%Y')) and now())) order by cast(`sales`.`ENTITY_VALUE_13` as unsigned) desc limit 10 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_user_groups`
--

/*!50001 DROP TABLE IF EXISTS `v_user_groups`*/;
/*!50001 DROP VIEW IF EXISTS `v_user_groups`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_groups` AS select distinct `g`.`GROUP_ID` AS `instanceId`,`g`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`g`.`COMPANY_ID` AS `COMPANY_ID`,`g`.`GROUP_NAME` AS `name` from `cxm_group` `g` where (`g`.`TYPE` = 'User') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_leadsdashboardbystage`
--

/*!50001 DROP TABLE IF EXISTS `v_leadsdashboardbystage`*/;
/*!50001 DROP VIEW IF EXISTS `v_leadsdashboardbystage`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_leadsdashboardbystage` AS select `leads`.`INSTANCE_ID` AS `instanceId`,`leads`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`leads`.`COMPANY_ID` AS `COMPANY_ID`,`leads`.`OWNER` AS `owner`,`leads`.`ACCESS` AS `ACCESS`,`leads`.`ENTITY_VALUE_50` AS `leadParentStage`,`leads`.`ENTITY_VALUE_23` AS `leadStage`,count(0) AS `leadStageCount`,(select count(0) from `cxm_entity_instance_6` `leads`) AS `total`,cast(((count(0) * 100) / (select count(0) from `cxm_entity_instance_6` `leads`)) as decimal(10,2)) AS `percentage`,round(((select sum(if((`cxm_entity_instance_181`.`ENTITY_VALUE_4` = 0),(to_days(now()) - to_days(`CXM_STR_TO_DATE`(`leads`.`ORGANIZATION_ID`,`leads`.`COMPANY_ID`,`cxm_entity_instance_181`.`ENTITY_VALUE_2`))),`cxm_entity_instance_181`.`ENTITY_VALUE_4`)) from `cxm_entity_instance_181` where ((`cxm_entity_instance_181`.`PARENT_INSTANCE_ID` = `leads`.`INSTANCE_ID`) and (`cxm_entity_instance_181`.`PARENT_MODULE_UNAME` = 'Leads'))) / count(0)),1) AS `avgLeadTime` from `cxm_entity_instance_6` `leads` group by `leads`.`ENTITY_VALUE_50`,`leads`.`ENTITY_VALUE_23` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_util_event`
--

/*!50001 DROP TABLE IF EXISTS `v_util_event`*/;
/*!50001 DROP VIEW IF EXISTS `v_util_event`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_util_event` AS (select `cxm_grid_fields`.`EVENT_ON_CHANGE` AS `EVENT_NAME` from `cxm_grid_fields` where (`cxm_grid_fields`.`EVENT_ON_CHANGE` <> ' ')) union (select concat(`cxm_page`.`EVENT_ON_LOAD`,`cxm_page`.`EVENT_ON_SUBMIT`,`cxm_page`.`ON_CANCEL_EVENT`,`cxm_page`.`ON_ADD_EVENT`,`cxm_page`.`ON_DELETE_EVENT`) AS `EVENT_NAME` from `cxm_page`) union (select `cxm_page_field_for_view`.`EVENT_ON_CHANGE` AS `EVENT_NAME` from `cxm_page_field_for_view` where (`cxm_page_field_for_view`.`EVENT_ON_CHANGE` <> ' ')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_salesperson_list`
--

/*!50001 DROP TABLE IF EXISTS `v_salesperson_list`*/;
/*!50001 DROP VIEW IF EXISTS `v_salesperson_list`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_salesperson_list` AS select distinct `u`.`ORGANIZATION_ID` AS `organization_id`,`u`.`COMPANY_ID` AS `company_id`,`ur`.`USER_ID` AS `USER_ID`,`u`.`USER_UNAME` AS `USER_UNAME`,`u`.`FIRST_NAME` AS `FIRST_NAME`,`u`.`LAST_NAME` AS `LAST_NAME` from ((`cxm_role_user_rel` `ur` join `cxm_user` `u` on((`ur`.`USER_ID` = `u`.`USER_ID`))) join `cxm_role` `r` on((`ur`.`ROLE_ID` = `r`.`ROLE_ID`))) where ((`r`.`ROLE_NAME` like 'Sales%') and (`u`.`STATUS` = 'A')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_calendarsettingforoutlook`
--

/*!50001 DROP TABLE IF EXISTS `v_calendarsettingforoutlook`*/;
/*!50001 DROP VIEW IF EXISTS `v_calendarsettingforoutlook`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_calendarsettingforoutlook` AS select distinct `cxm_calendar`.`CALENDAR_UNAME` AS `calendar_uname` from `cxm_calendar` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_util_grids`
--

/*!50001 DROP TABLE IF EXISTS `v_util_grids`*/;
/*!50001 DROP VIEW IF EXISTS `v_util_grids`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_util_grids` AS (select `cxm_entity_field`.`FIELD_UNAME` AS `GRID_UNAME` from `cxm_entity_field` where (`cxm_entity_field`.`FIELD_TYPE` like '%Grid')) union (select `cxm_page_field_for_view`.`GRID_UNAME` AS `GRID_UNAME` from `cxm_page_field_for_view` where (`cxm_page_field_for_view`.`GRID_UNAME` <> ' ')) union (select `cxm_module`.`GRID_UNAME` AS `GRID_UNAME` from `cxm_module` where (`cxm_module`.`GRID_UNAME` <> ' ')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_lastactivity`
--

/*!50001 DROP TABLE IF EXISTS `v_lastactivity`*/;
/*!50001 DROP VIEW IF EXISTS `v_lastactivity`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_lastactivity` AS select concat((select `cxm_lookup`.`LVALUE` from `cxm_lookup` where ((`cxm_lookup`.`LKEY` = convert(`v_a`.`activity_type` using utf8)) and (`cxm_lookup`.`LTYPE` = 'ACTIVITY_TYPE') and (`cxm_lookup`.`ORGANIZATION_ID` = `v_a`.`ORGANIZATION_ID`) and (`cxm_lookup`.`COMPANY_ID` = `v_a`.`COMPANY_ID`))),':',convert(`CXM_DATE_FORMAT`(`v_a`.`ORGANIZATION_ID`,`v_a`.`COMPANY_ID`,`v_a`.`update_date`) using utf8)) AS `last_action`,'Activity' AS `last_action_type`,`v_a`.`activityModName` AS `parentModuleUname`,`v_a`.`activityModId` AS `parentInstanceId` from (`v_allcompletedactivity` `v_a` join `v_maxactivity` on(((`v_a`.`activityModName` = `v_maxactivity`.`activityModName`) and (`v_a`.`activityModId` = `v_maxactivity`.`activityModId`) and (`v_a`.`update_date` = `v_maxactivity`.`update_date`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_dashboard_email_sent`
--

/*!50001 DROP TABLE IF EXISTS `v_dashboard_email_sent`*/;
/*!50001 DROP VIEW IF EXISTS `v_dashboard_email_sent`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_dashboard_email_sent` AS select 1 AS `row_num`,`a`.`EMAIL_ID` AS `instanceId`,`b`.`ENTITY_TYPE` AS `parentModuleUname`,`b`.`ENTITY_ID` AS `parentInstanceId`,`a`.`ORGANIZATION_ID` AS `organization_id`,`a`.`COMPANY_ID` AS `company_id`,`a`.`SUBJECT` AS `subject`,date_format(`a`.`SENT_DATA_TIME`,'%m/%d/%Y') AS `sdate`,`a`.`EMAIL_NAME` AS `email_name`,`a`.`OWNER` AS `owner`,`a`.`ACCESS` AS `access`,`a`.`SECURITY_LEVEL` AS `securityLevel`,`b`.`ENTITY_ID` AS `user_id`,`u`.`USER_UNAME` AS `user_name`,`a`.`SENT_DATA_TIME` AS `sent_time`,`b`.`EMAIL_ADDRESS` AS `email_from`,`c`.`EMAIL_ADDRESS` AS `email_to`,'emailHistory' AS `moduleUname`,'Sent' AS `emailType`,`b`.`ENTITY_TYPE` AS `entity_type`,1 AS `reply`,1 AS `replyAll`,1 AS `forward` from (((`cxm_email` `a` join `cxm_email_entity` `b` on((`a`.`EMAIL_ID` = `b`.`EMAIL_ID`))) join `cxm_email_entity` `c` on(((`b`.`EMAIL_ID` = `c`.`EMAIL_ID`) and (`b`.`HEADER_TYPE` = 'FROM') and (`c`.`HEADER_TYPE` = 'TO')))) left join `cxm_user` `u` on((`u`.`USER_ID` = `b`.`ENTITY_ID`))) where (`b`.`ENTITY_TYPE` = 'Users') order by `a`.`SENT_DATA_TIME` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_util_lookup`
--

/*!50001 DROP TABLE IF EXISTS `v_util_lookup`*/;
/*!50001 DROP VIEW IF EXISTS `v_util_lookup`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_util_lookup` AS select distinct `cxm_entity_field`.`CRITERIA_NAME` AS `criteria_name` from `cxm_entity_field` where ((length(`cxm_entity_field`.`CRITERIA_NAME`) > 0) and (`cxm_entity_field`.`FIELD_TYPE` like '%lookup%')) union select substr(`cxm_grid_fields`.`FORMAT_MASK`,9) AS `substring((``cxm_grid_fields``.``FORMAT_MASK``),9)` from `cxm_grid_fields` where (`cxm_grid_fields`.`FORMAT_MASK` like 'lookup%') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_ticketsimplemaingrid`
--

/*!50001 DROP TABLE IF EXISTS `v_ticketsimplemaingrid`*/;
/*!50001 DROP VIEW IF EXISTS `v_ticketsimplemaingrid`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ticketsimplemaingrid` AS select distinct '1' AS `row_num`,`ticket`.`INSTANCE_ID` AS `instanceId`,`ticket`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ticket`.`COMPANY_ID` AS `COMPANY_ID`,`ticket`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`ticket`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,`ticket`.`ENTITY_VALUE_71` AS `ticketID`,`ticket`.`ENTITY_VALUE_4` AS `recdDate`,`ticket`.`ENTITY_VALUE_21` AS `recdTime`,`ticket`.`ENTITY_VALUE_13` AS `ticketTitle`,`ticket`.`ENTITY_VALUE_7` AS `completeTime`,(case when (`ticket`.`ENTITY_VALUE_70` = 'INDIVIDUAL') then (select concat(`cxm_user`.`FIRST_NAME`,' ',`cxm_user`.`LAST_NAME`) from `cxm_user` where (`cxm_user`.`USER_ID` = `ticket`.`ENTITY_VALUE_17`)) when (`ticket`.`ENTITY_VALUE_70` = 'GROUPS') then (select `cxm_group`.`GROUP_NAME` from `cxm_group` where (`cxm_group`.`GROUP_ID` = `ticket`.`ENTITY_VALUE_17`)) when (`ticket`.`ENTITY_VALUE_70` = 'USR_POSITION') then (select `cxm_lookup`.`LVALUE` from `cxm_lookup` where (`cxm_lookup`.`LKEY` = convert(`ticket`.`ENTITY_VALUE_17` using utf8))) end) AS `assignedTo`,(case when (`ticket`.`ENTITY_VALUE_70` = 'INDIVIDUAL') then (select concat(`cxm_user`.`FIRST_NAME`,' ',`cxm_user`.`LAST_NAME`) from `cxm_user` where (`cxm_user`.`USER_ID` = `ticket`.`ENTITY_VALUE_12`)) when (`ticket`.`ENTITY_VALUE_70` = 'GROUPS') then (select `cxm_group`.`GROUP_NAME` from `cxm_group` where (`cxm_group`.`GROUP_ID` = `ticket`.`ENTITY_VALUE_12`)) when (`ticket`.`ENTITY_VALUE_70` = 'USR_POSITION') then (select `cxm_lookup`.`LVALUE` from `cxm_lookup` where (`cxm_lookup`.`LKEY` = convert(`ticket`.`ENTITY_VALUE_12` using utf8))) end) AS `assignedToIndividual`,`ticket`.`ENTITY_VALUE_8` AS `status`,`ticket`.`ENTITY_VALUE_16` AS `typeCall`,`ticket`.`ENTITY_VALUE_14` AS `urgency`,`ticket`.`ENTITY_VALUE_19` AS `account`,concat(`pcntc`.`ENTITY_VALUE_4`,' ',`pcntc`.`ENTITY_VALUE_6`) AS `pconName`,convert(concat(`pcntc`.`ENTITY_VALUE_4`,' ',`pcntc`.`ENTITY_VALUE_6`,'::',`pcntc`.`INSTANCE_ID`,'::Contact') using utf8) AS `pconNameUrl`,convert(concat(`pcntc`.`ENTITY_VALUE_11`,`pcntc`.`ENTITY_VALUE_12`) using utf8) AS `phone`,`ticket`.`ENTITY_VALUE_22` AS `email`,`ticket`.`OWNER` AS `owner`,`ticket`.`ACCESS` AS `access`,`pcntc`.`ENTITY_VALUE_56` AS `state` from (`cxm_entity_instance_67` `ticket` left join `cxm_entity_instance_3` `pcntc` on(((`pcntc`.`INSTANCE_ID` = `ticket`.`ENTITY_VALUE_1`) and (`pcntc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`pcntc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`)))) order by `ticket`.`INSTANCE_ID` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_salesopenopportunities`
--

/*!50001 DROP TABLE IF EXISTS `v_salesopenopportunities`*/;
/*!50001 DROP VIEW IF EXISTS `v_salesopenopportunities`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_salesopenopportunities` AS select distinct `sales`.`INSTANCE_ID` AS `instanceId`,`sales`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`sales`.`COMPANY_ID` AS `COMPANY_ID`,`sales`.`OWNER` AS `owner`,`sales`.`ACCESS` AS `access`,`sales`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`sales`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,`sales`.`INSTANCE_ID` AS `opportunityName`,'1' AS `row_number`,`sales`.`ENTITY_VALUE_10` AS `sumAmount` from `cxm_entity_instance_2` `sales` where ((`sales`.`ENTITY_VALUE_6` not in ('OPPORTUNITY4','OPPORTUNITY3','OPPORTUNITY2')) and (`CXM_STR_TO_DATE`(`sales`.`ORGANIZATION_ID`,`sales`.`COMPANY_ID`,`sales`.`ENTITY_VALUE_9`) between `CXM_STR_TO_DATE`(`sales`.`ORGANIZATION_ID`,`sales`.`COMPANY_ID`,date_format(now(),'%m/01/%Y')) and (`CXM_STR_TO_DATE`(`sales`.`ORGANIZATION_ID`,`sales`.`COMPANY_ID`,date_format(now(),'%m/01/%Y')) + interval 1 month))) order by `sales`.`ENTITY_VALUE_7` desc,cast(`sales`.`ENTITY_VALUE_10` as unsigned) desc limit 10 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_accountlastactivity`
--

/*!50001 DROP TABLE IF EXISTS `v_accountlastactivity`*/;
/*!50001 DROP VIEW IF EXISTS `v_accountlastactivity`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_accountlastactivity` AS select concat((select `cxm_lookup`.`LVALUE` from `cxm_lookup` where ((`cxm_lookup`.`LKEY` = convert(`v_a`.`activity_type` using utf8)) and (`cxm_lookup`.`LTYPE` = 'ACTIVITY_TYPE') and (`cxm_lookup`.`ORGANIZATION_ID` = `v_a`.`ORGANIZATION_ID`) and (`cxm_lookup`.`COMPANY_ID` = `v_a`.`COMPANY_ID`))),':',convert(`CXM_date_format`(`v_a`.`ORGANIZATION_ID`,`v_a`.`COMPANY_ID`,`v_a`.`update_date`) using utf8)) AS `last_action`,'Activity' AS `last_action_type`,`v_m`.`parent_module_uname` AS `parentModuleUname`,`v_m`.`parent_instance_id` AS `parentInstanceId` from (`v_accountallcompletedactivity` `v_a` join `v_accountmaxactivity` `v_m` on(((`v_a`.`update_date` = `v_m`.`update_date`) and (`v_a`.`parent_instance_id` = `v_m`.`parent_instance_id`) and (`v_a`.`parent_module_uname` = `v_m`.`parent_module_uname`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_contactmaxactivity`
--

/*!50001 DROP TABLE IF EXISTS `v_contactmaxactivity`*/;
/*!50001 DROP VIEW IF EXISTS `v_contactmaxactivity`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_contactmaxactivity` AS select `v_contactallcompletedactivity`.`parent_module_uname` AS `parent_module_uname`,`v_contactallcompletedactivity`.`parent_instance_id` AS `parent_instance_id`,max(`v_contactallcompletedactivity`.`update_date`) AS `update_date` from `v_contactallcompletedactivity` group by `v_contactallcompletedactivity`.`parent_module_uname`,`v_contactallcompletedactivity`.`parent_instance_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_ticket_line_items`
--

/*!50001 DROP TABLE IF EXISTS `v_ticket_line_items`*/;
/*!50001 DROP VIEW IF EXISTS `v_ticket_line_items`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ticket_line_items` AS select `tt`.`INSTANCE_ID` AS `instanceId`,`tt`.`INSTANCE_ID` AS `ttid`,`tt`.`PARENT_INSTANCE_ID` AS `TaskId`,`tt`.`ENTITY_VALUE_1` AS `ttdate`,`tt`.`ENTITY_VALUE_2` AS `ttstart`,`tt`.`ENTITY_VALUE_3` AS `ttstop`,`tt`.`ENTITY_VALUE_71` AS `tttotal`,(select `cxm_lookup`.`LVALUE` from `cxm_lookup` where ((`cxm_lookup`.`LKEY` = convert(`tt`.`ENTITY_VALUE_5` using utf8)) and (`cxm_lookup`.`LTYPE` = 'TICKET_ACTION'))) AS `ttaction`,(select `cxm_lookup`.`LVALUE` from `cxm_lookup` where ((`cxm_lookup`.`LKEY` = convert(`tt`.`ENTITY_VALUE_6` using utf8)) and (`cxm_lookup`.`LTYPE` = 'TICKET_STATUS'))) AS `ttstatus`,`tt`.`ENTITY_VALUE_7` AS `ttworkby`,`name`.`FIRST_NAME` AS `fname`,`name`.`LAST_NAME` AS `lname`,`tt`.`ENTITY_VALUE_81` AS `ttproblem`,`tt`.`ENTITY_VALUE_82` AS `ttresolution`,`tt`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`tt`.`COMPANY_ID` AS `COMPANY_ID`,`tt`.`OWNER` AS `owner`,`tt`.`ACCESS` AS `access`,`tt`.`SECURITY_LEVEL` AS `security_level`,`tt`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,`tt`.`PARENT_MODULE_UNAME` AS `parentModuleUname` from (`cxm_entity_instance_160` `tt` left join `cxm_user` `name` on((`name`.`USER_ID` = `tt`.`ENTITY_VALUE_7`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_sales_report`
--

/*!50001 DROP TABLE IF EXISTS `v_sales_report`*/;
/*!50001 DROP VIEW IF EXISTS `v_sales_report`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_sales_report` AS select distinct `salesoppurtunity`.`INSTANCE_ID` AS `INSTANCE_ID`,`salesoppurtunity`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`salesoppurtunity`.`COMPANY_ID` AS `COMPANY_ID`,`salesoppurtunity`.`PARENT_MODULE_UNAME` AS `PARENT_MODULE_UNAME`,`salesoppurtunity`.`PARENT_INSTANCE_ID` AS `PARENT_INSTANCE_ID`,`salesoppurtunity`.`ENTITY_VALUE_1` AS `oppName`,(case `salesoppurtunity`.`PARENT_MODULE_UNAME` when 'Account' then (select `acc`.`ENTITY_VALUE_2` from `cxm_entity_instance_1` `acc` where ((`acc`.`INSTANCE_ID` = `salesoppurtunity`.`PARENT_INSTANCE_ID`) and (`acc`.`ORGANIZATION_ID` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`acc`.`COMPANY_ID` = `salesoppurtunity`.`COMPANY_ID`))) when 'Contact' then (select concat(`cntc`.`ENTITY_VALUE_4`,' ',`cntc`.`ENTITY_VALUE_6`) from `cxm_entity_instance_3` `cntc` where ((`cntc`.`INSTANCE_ID` = `salesoppurtunity`.`PARENT_INSTANCE_ID`) and (`cntc`.`ORGANIZATION_ID` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`cntc`.`COMPANY_ID` = `salesoppurtunity`.`COMPANY_ID`))) else 'Unassigned' end) AS `name`,(case `salesoppurtunity`.`PARENT_MODULE_UNAME` when 'Account' then (select `acc`.`ENTITY_VALUE_11` from `cxm_entity_instance_1` `acc` where ((`acc`.`INSTANCE_ID` = `salesoppurtunity`.`PARENT_INSTANCE_ID`) and (`acc`.`ORGANIZATION_ID` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`acc`.`COMPANY_ID` = `salesoppurtunity`.`COMPANY_ID`))) end) AS `account_status`,`salesoppurtunity`.`ENTITY_VALUE_7` AS `EstProb`,`salesoppurtunity`.`ENTITY_VALUE_13` AS `closeamount`,`salesoppurtunity`.`ENTITY_VALUE_10` AS `EstAmount`,`salesoppurtunity`.`ENTITY_VALUE_12` AS `closedate`,`salesoppurtunity`.`ENTITY_VALUE_9` AS `EstCloseDate`,`salesoppurtunity`.`ENTITY_VALUE_5` AS `DateCreated`,`salesoppurtunity`.`ENTITY_VALUE_22` AS `SO_No`,`salesoppurtunity`.`ENTITY_VALUE_81` AS `NOTES`,if((`salesoppurtunity`.`PARENT_MODULE_UNAME` = 'Account'),(select `v_accountlastactivity`.`last_action` from `v_accountlastactivity` where ((`v_accountlastactivity`.`parentModuleUname` = 'Account') and (`v_accountlastactivity`.`parentInstanceId` = `salesoppurtunity`.`PARENT_INSTANCE_ID`)) limit 1),(select `v_contactlastactivity`.`last_action` from `v_contactlastactivity` where ((`v_contactlastactivity`.`parentModuleUname` = 'Contact') and (`v_contactlastactivity`.`parentInstanceId` = `salesoppurtunity`.`PARENT_INSTANCE_ID`)) limit 1)) AS `last_action`,(select `cxm_user`.`DEFAULT_SUPERVISOR` from `cxm_user` where ((`cxm_user`.`USER_ID` = `salesoppurtunity`.`ENTITY_VALUE_23`) and (`cxm_user`.`ORGANIZATION_ID` = `cxm_user`.`ORGANIZATION_ID`) and (`cxm_user`.`COMPANY_ID` = `cxm_user`.`COMPANY_ID`))) AS `ManagerId`,(select `cxm_lookup`.`LVALUE` from `cxm_lookup` where ((`cxm_lookup`.`LKEY` = `salesoppurtunity`.`ENTITY_VALUE_6`) and (`cxm_lookup`.`ORGANIZATION_ID` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`cxm_lookup`.`COMPANY_ID` = `salesoppurtunity`.`COMPANY_ID`) and (`cxm_lookup`.`LTYPE` = 'OPPORTUNITY_STATUS'))) AS `OPSTAGE` from `cxm_entity_instance_2` `salesoppurtunity` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_ticketsimpleavgrestimebypriority`
--

/*!50001 DROP TABLE IF EXISTS `v_ticketsimpleavgrestimebypriority`*/;
/*!50001 DROP VIEW IF EXISTS `v_ticketsimpleavgrestimebypriority`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ticketsimpleavgrestimebypriority` AS select `ticket`.`INSTANCE_ID` AS `instanceId`,`ticket`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ticket`.`COMPANY_ID` AS `COMPANY_ID`,`ticket`.`OWNER` AS `owner`,`ticket`.`ACCESS` AS `access`,1 AS `row_number`,`ticket`.`ENTITY_VALUE_14` AS `priority`,avg((to_days(`CXM_STR_TO_DATE`(`ticket`.`ORGANIZATION_ID`,`ticket`.`COMPANY_ID`,`ticket`.`ENTITY_VALUE_25`)) - to_days(`CXM_STR_TO_DATE`(`ticket`.`ORGANIZATION_ID`,`ticket`.`COMPANY_ID`,`ticket`.`ENTITY_VALUE_4`)))) AS `age` from `cxm_entity_instance_67` `ticket` where (((`ticket`.`ENTITY_VALUE_8` = 'TICKET_STATUS06') or (`ticket`.`ENTITY_VALUE_8` = 'TICKET_STATUS05')) and (`CXM_STR_TO_DATE`(`ticket`.`ORGANIZATION_ID`,`ticket`.`COMPANY_ID`,`ticket`.`ENTITY_VALUE_25`) between `CXM_STR_TO_DATE`(`ticket`.`ORGANIZATION_ID`,`ticket`.`COMPANY_ID`,date_format((now() - interval 1 year),'%m/%d/%Y')) and now())) group by (select `cxm_lookup`.`LVALUE` from `cxm_lookup` where ((`cxm_lookup`.`LKEY` = convert(`ticket`.`ENTITY_VALUE_14` using utf8)) and (`cxm_lookup`.`LTYPE` = 'URGENCY') and (`cxm_lookup`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`cxm_lookup`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_salescloseddealleader`
--

/*!50001 DROP TABLE IF EXISTS `v_salescloseddealleader`*/;
/*!50001 DROP VIEW IF EXISTS `v_salescloseddealleader`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_salescloseddealleader` AS select distinct `sales`.`INSTANCE_ID` AS `instanceId`,`sales`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`sales`.`COMPANY_ID` AS `COMPANY_ID`,`sales`.`OWNER` AS `owner`,`sales`.`ACCESS` AS `access`,`sales`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`sales`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,1 AS `row_number`,(select concat(`cxm_user`.`FIRST_NAME`,' ',`cxm_user`.`LAST_NAME`) from `cxm_user` where (`cxm_user`.`USER_ID` = `sales`.`ENTITY_VALUE_23`)) AS `SalesPerson`,sum(`sales`.`ENTITY_VALUE_13`) AS `sumAmount`,count(`sales`.`INSTANCE_ID`) AS `numRecords` from `cxm_entity_instance_2` `sales` where (`sales`.`ENTITY_VALUE_6` = 'OPPORTUNITY2') group by `sales`.`ENTITY_VALUE_23` order by sum(`sales`.`ENTITY_VALUE_13`) desc limit 10 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_contactlastemail`
--

/*!50001 DROP TABLE IF EXISTS `v_contactlastemail`*/;
/*!50001 DROP VIEW IF EXISTS `v_contactlastemail`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_contactlastemail` AS select `v_a`.`last_action` AS `last_action`,'Email' AS `last_action_type`,`v_m`.`parent_module_uname` AS `parentModuleUname`,`v_m`.`parent_instance_id` AS `parentInstanceId` from (`v_contactallemails` `v_a` join `v_contactmaxemails` `v_m` on(((`v_a`.`update_date` = `v_m`.`update_date`) and (`v_a`.`parent_instance_id` = `v_m`.`parent_instance_id`) and (`v_a`.`parent_module_uname` = `v_m`.`parent_module_uname`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_groupmembers`
--

/*!50001 DROP TABLE IF EXISTS `v_groupmembers`*/;
/*!50001 DROP VIEW IF EXISTS `v_groupmembers`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_groupmembers` AS select `g`.`GROUP_ID` AS `GROUP_ID`,`g`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`g`.`COMPANY_ID` AS `COMPANY_ID`,`g`.`TYPE` AS `parentModuleUname`,`ge`.`ENTITY_ID` AS `parentInstanceId`,`ge`.`UPDATE_USER` AS `addedBy`,`ge`.`UPDATE_DATE` AS `addedDate`,`g`.`GROUP_NAME` AS `name`,`ge`.`GROUP_ENTITY_ID` AS `instanceId`,`ge`.`CREATE_USER` AS `owner`,'public' AS `access` from (`cxm_group` `g` join `cxm_group_entity` `ge` on((`ge`.`GROUP_ID` = `g`.`GROUP_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_maxactivity`
--

/*!50001 DROP TABLE IF EXISTS `v_maxactivity`*/;
/*!50001 DROP VIEW IF EXISTS `v_maxactivity`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_maxactivity` AS select `ae`.`MODULE_UNAME` AS `activityModName`,`ae`.`INSTANCE_ID` AS `activityModId`,max(`a`.`UPDATE_DATE`) AS `update_date` from (`cxm_activity` `a` join `cxm_activity_entity` `ae` on((`a`.`ACTIVITY_ID` = `ae`.`ACTIVITY_ID`))) where ((`a`.`STATUS` = 'ACT_STATUS_COMPLETED') and ((`a`.`FROM_DATE` < now()) or (`a`.`UPDATE_DATE` < now()))) group by `ae`.`MODULE_UNAME`,`ae`.`INSTANCE_ID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_modules`
--

/*!50001 DROP TABLE IF EXISTS `v_modules`*/;
/*!50001 DROP VIEW IF EXISTS `v_modules`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_modules` AS select `cxm_module`.`MODULE_UNAME` AS `MODULE_UNAME`,`cxm_module`.`DISPLAY_NAME` AS `displayModule` from `cxm_module` where ((`cxm_module`.`MODULE_TYPE` = 'MODULE') or (`cxm_module`.`MODULE_TYPE` = 'SUBMODULE') or ((`cxm_module`.`MODULE_TYPE` = 'ENTITY') and (length(`cxm_module`.`MENU_LOCATION`) > 1))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_salesclosedopportunities`
--

/*!50001 DROP TABLE IF EXISTS `v_salesclosedopportunities`*/;
/*!50001 DROP VIEW IF EXISTS `v_salesclosedopportunities`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_salesclosedopportunities` AS select distinct `sales`.`INSTANCE_ID` AS `instanceId`,`sales`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`sales`.`COMPANY_ID` AS `COMPANY_ID`,`sales`.`OWNER` AS `owner`,`sales`.`ACCESS` AS `access`,`sales`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`sales`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,`sales`.`INSTANCE_ID` AS `opportunityName`,1 AS `row_number`,`sales`.`ENTITY_VALUE_13` AS `sumAmount` from `cxm_entity_instance_2` `sales` where ((`sales`.`ENTITY_VALUE_6` = 'OPPORTUNITY2') and (`CXM_STR_TO_DATE`(`sales`.`ORGANIZATION_ID`,`sales`.`COMPANY_ID`,`sales`.`ENTITY_VALUE_5`) between `CXM_STR_TO_DATE`(`sales`.`ORGANIZATION_ID`,`sales`.`COMPANY_ID`,date_format(now(),'01/01/%Y')) and now())) order by cast(`sales`.`ENTITY_VALUE_13` as unsigned) desc limit 10 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_salesoppresultsgrid`
--

/*!50001 DROP TABLE IF EXISTS `v_salesoppresultsgrid`*/;
/*!50001 DROP VIEW IF EXISTS `v_salesoppresultsgrid`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_salesoppresultsgrid` AS select distinct (case `salesoppurtunity`.`PARENT_MODULE_UNAME` when 'Account' then (select `acc`.`ENTITY_VALUE_2` from `cxm_entity_instance_1` `acc` where ((`acc`.`INSTANCE_ID` = `salesoppurtunity`.`PARENT_INSTANCE_ID`) and (`acc`.`ORGANIZATION_ID` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`acc`.`COMPANY_ID` = `salesoppurtunity`.`COMPANY_ID`))) when 'Contact' then (select concat(`cntc`.`ENTITY_VALUE_4`,' ',`cntc`.`ENTITY_VALUE_6`) from `cxm_entity_instance_3` `cntc` where ((`cntc`.`INSTANCE_ID` = `salesoppurtunity`.`PARENT_INSTANCE_ID`) and (`cntc`.`ORGANIZATION_ID` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`cntc`.`COMPANY_ID` = `salesoppurtunity`.`COMPANY_ID`))) else 'Unassigned' end) AS `parentName`,(select convert(concat(`cntc`.`ENTITY_VALUE_4`,' ',`cntc`.`ENTITY_VALUE_6`) using utf8) from `cxm_entity_instance_3` `cntc` where (`cntc`.`INSTANCE_ID` = `salesoppurtunity`.`ENTITY_VALUE_24`)) AS `primcontactName`,`salesoppurtunity`.`ENTITY_VALUE_1` AS `oppName`,(select concat(`cxm_user`.`FIRST_NAME`,' ',`cxm_user`.`LAST_NAME`) from `cxm_user` where (`cxm_user`.`USER_ID` = `salesoppurtunity`.`ENTITY_VALUE_23`)) AS `SalesPerson`,`salesoppurtunity`.`ENTITY_VALUE_22` AS `SO_No`,`salesoppurtunity`.`ENTITY_VALUE_5` AS `DateCreated`,(select `cxm_lookup`.`LVALUE` from `cxm_lookup` where (`cxm_lookup`.`LKEY` = `salesoppurtunity`.`ENTITY_VALUE_16`)) AS `SalesStageName`,(select `cxm_lookup`.`LVALUE` from `cxm_lookup` where (`cxm_lookup`.`LKEY` = `salesoppurtunity`.`ENTITY_VALUE_15`)) AS `LeadStageName`,`salesoppurtunity`.`ENTITY_VALUE_9` AS `EstCloseDate`,`salesoppurtunity`.`ENTITY_VALUE_10` AS `EstAmount`,`salesoppurtunity`.`ENTITY_VALUE_7` AS `EstProb`,`salesoppurtunity`.`ENTITY_VALUE_12` AS `closedate`,`salesoppurtunity`.`ENTITY_VALUE_13` AS `closeamount`,if((`salesoppurtunity`.`PARENT_MODULE_UNAME` = 'Account'),`salesoppurtunity`.`PARENT_INSTANCE_ID`,0) AS `Account`,if((`salesoppurtunity`.`PARENT_MODULE_UNAME` = 'Contact'),`salesoppurtunity`.`PARENT_INSTANCE_ID`,0) AS `contact`,`salesoppurtunity`.`ENTITY_VALUE_24` AS `primcontact`,`salesoppurtunity`.`ENTITY_VALUE_6` AS `opportunityStatus`,`salesoppurtunity`.`ENTITY_VALUE_16` AS `SalesStage`,`salesoppurtunity`.`ENTITY_VALUE_15` AS `LeadStage`,`salesoppurtunity`.`ENTITY_VALUE_4` AS `region`,`salesoppurtunity`.`ENTITY_VALUE_18` AS `lsource`,`salesoppurtunity`.`ENTITY_VALUE_17` AS `opptype`,`salesoppurtunity`.`ENTITY_VALUE_19` AS `campaign`,`salesoppurtunity`.`UPDATE_DATE` AS `updateDate`,`salesoppurtunity`.`PARENT_MODULE_UNAME` AS `salesParent`,ifnull(`salesoppurtunity`.`ENTITY_VALUE_23`,0) AS `SalesPersonID`,(select `cxm_user`.`DEFAULT_SUPERVISOR` from `cxm_user` where (`cxm_user`.`USER_ID` = `salesoppurtunity`.`ENTITY_VALUE_23`)) AS `ManagerId`,(select concat(`cxm_user`.`FIRST_NAME`,' ',`cxm_user`.`LAST_NAME`) from `cxm_user` where (`cxm_user`.`USER_ID` = (select `cxm_user`.`DEFAULT_SUPERVISOR` from `cxm_user` where (`cxm_user`.`USER_ID` = `salesoppurtunity`.`ENTITY_VALUE_23`)))) AS `SalesMgr`,`salesoppurtunity`.`PARENT_MODULE_UNAME` AS `PARENT_MODULE_UNAME`,`salesoppurtunity`.`PARENT_INSTANCE_ID` AS `PARENT_INSTANCE_ID`,`salesoppurtunity`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`salesoppurtunity`.`OWNER` AS `owner`,`salesoppurtunity`.`ACCESS` AS `access`,`salesoppurtunity`.`COMPANY_ID` AS `COMPANY_ID`,`salesoppurtunity`.`INSTANCE_ID` AS `instanceId` from `cxm_entity_instance_2` `salesoppurtunity` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_dashboard_email`
--

/*!50001 DROP TABLE IF EXISTS `v_dashboard_email`*/;
/*!50001 DROP VIEW IF EXISTS `v_dashboard_email`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_dashboard_email` AS select 1 AS `row_num`,`a`.`EMAIL_ID` AS `instanceId`,`c`.`ENTITY_TYPE` AS `parentModuleUname`,`c`.`ENTITY_ID` AS `parentInstanceId`,`a`.`ORGANIZATION_ID` AS `organization_id`,`a`.`COMPANY_ID` AS `company_id`,`a`.`SUBJECT` AS `subject`,date_format(`a`.`SENT_DATA_TIME`,'%m/%d/%Y') AS `sdate`,`a`.`EMAIL_NAME` AS `email_name`,`a`.`OWNER` AS `owner`,`a`.`ACCESS` AS `access`,`a`.`SECURITY_LEVEL` AS `securityLevel`,`c`.`ENTITY_ID` AS `user_id`,`u`.`USER_UNAME` AS `user_name`,`a`.`SENT_DATA_TIME` AS `sent_time`,`b`.`EMAIL_ADDRESS` AS `email_from`,`c`.`EMAIL_ADDRESS` AS `email_to`,'emailHistory' AS `moduleUname`,'Inbox' AS `emailType`,`c`.`ENTITY_TYPE` AS `entity_type`,1 AS `reply`,1 AS `replyAll`,1 AS `forward` from (((`cxm_email` `a` join `cxm_email_entity` `b` on((`a`.`EMAIL_ID` = `b`.`EMAIL_ID`))) join `cxm_email_entity` `c` on(((`b`.`EMAIL_ID` = `c`.`EMAIL_ID`) and (`b`.`HEADER_TYPE` = 'FROM') and (`c`.`HEADER_TYPE` = 'TO')))) join `cxm_user` `u` on((`u`.`USER_ID` = `c`.`ENTITY_ID`))) where (`c`.`ENTITY_TYPE` = 'Users') union select 1 AS `row_num`,`a`.`EMAIL_ID` AS `instanceId`,`c`.`ENTITY_TYPE` AS `parentModuleUname`,`c`.`ENTITY_ID` AS `parentInstanceId`,`a`.`ORGANIZATION_ID` AS `organization_id`,`a`.`COMPANY_ID` AS `company_id`,`a`.`SUBJECT` AS `subject`,date_format(`a`.`SENT_DATA_TIME`,'%m/%d/%Y') AS `sdate`,`a`.`EMAIL_NAME` AS `email_name`,`a`.`OWNER` AS `owner`,`a`.`ACCESS` AS `access`,`a`.`SECURITY_LEVEL` AS `securityLevel`,`c`.`ENTITY_ID` AS `user_id`,`u`.`USER_UNAME` AS `user_name`,`a`.`SENT_DATA_TIME` AS `sent_time`,`b`.`EMAIL_ADDRESS` AS `email_from`,`c`.`EMAIL_ADDRESS` AS `email_to`,'emailHistory' AS `moduleUname`,'InboxCC' AS `emailType`,`c`.`ENTITY_TYPE` AS `entity_type`,1 AS `reply`,1 AS `replyAll`,1 AS `forward` from (((`cxm_email` `a` join `cxm_email_entity` `b` on((`a`.`EMAIL_ID` = `b`.`EMAIL_ID`))) join `cxm_email_entity` `c` on(((`b`.`EMAIL_ID` = `c`.`EMAIL_ID`) and (`b`.`HEADER_TYPE` = 'FROM') and (`c`.`HEADER_TYPE` = 'CC')))) join `cxm_user` `u` on((`u`.`USER_ID` = `c`.`ENTITY_ID`))) where (`c`.`ENTITY_TYPE` = 'Users') union select 1 AS `row_num`,`a`.`EMAIL_ID` AS `instanceId`,`c`.`ENTITY_TYPE` AS `parentModuleUname`,`c`.`ENTITY_ID` AS `parentInstanceId`,`a`.`ORGANIZATION_ID` AS `organization_id`,`a`.`COMPANY_ID` AS `company_id`,`a`.`SUBJECT` AS `subject`,date_format(`a`.`SENT_DATA_TIME`,'%m/%d/%Y') AS `sdate`,`a`.`EMAIL_NAME` AS `email_name`,`a`.`OWNER` AS `owner`,`a`.`ACCESS` AS `access`,`a`.`SECURITY_LEVEL` AS `securityLevel`,`c`.`ENTITY_ID` AS `user_id`,`u`.`USER_UNAME` AS `user_name`,`a`.`SENT_DATA_TIME` AS `sent_time`,`b`.`EMAIL_ADDRESS` AS `email_from`,`c`.`EMAIL_ADDRESS` AS `email_to`,'emailHistory' AS `moduleUname`,'InboxCC' AS `emailType`,`c`.`ENTITY_TYPE` AS `entity_type`,1 AS `reply`,1 AS `replyAll`,1 AS `forward` from (((`cxm_email` `a` join `cxm_email_entity` `b` on((`a`.`EMAIL_ID` = `b`.`EMAIL_ID`))) join `cxm_email_entity` `c` on(((`b`.`EMAIL_ID` = `c`.`EMAIL_ID`) and (`b`.`HEADER_TYPE` = 'FROM') and (`c`.`HEADER_TYPE` = 'BCC')))) join `cxm_user` `u` on((`u`.`USER_ID` = `c`.`ENTITY_ID`))) where (`c`.`ENTITY_TYPE` = 'Users') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_activestdproblems`
--

/*!50001 DROP TABLE IF EXISTS `v_activestdproblems`*/;
/*!50001 DROP VIEW IF EXISTS `v_activestdproblems`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_activestdproblems` AS select `cxm_entity_instance_163`.`INSTANCE_ID` AS `instanceId`,`cxm_entity_instance_163`.`ENTITY_VALUE_2` AS `title` from `cxm_entity_instance_163` where (`cxm_entity_instance_163`.`ENTITY_VALUE_3` = 'true') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_salesopenoppcurrmonth`
--

/*!50001 DROP TABLE IF EXISTS `v_salesopenoppcurrmonth`*/;
/*!50001 DROP VIEW IF EXISTS `v_salesopenoppcurrmonth`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_salesopenoppcurrmonth` AS select distinct `sales`.`INSTANCE_ID` AS `instanceId`,`sales`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`sales`.`COMPANY_ID` AS `COMPANY_ID`,`sales`.`OWNER` AS `owner`,`sales`.`ACCESS` AS `access`,`sales`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`sales`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,`sales`.`INSTANCE_ID` AS `opportunityName`,1 AS `row_number`,`sales`.`ENTITY_VALUE_10` AS `sumAmount` from `cxm_entity_instance_2` `sales` where (`sales`.`ENTITY_VALUE_6` not in ('OPPORTUNITY4','OPPORTUNITY3','OPPORTUNITY2')) order by `sales`.`ENTITY_VALUE_7` desc,cast(`sales`.`ENTITY_VALUE_10` as unsigned) desc limit 10 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_accountmaxemails`
--

/*!50001 DROP TABLE IF EXISTS `v_accountmaxemails`*/;
/*!50001 DROP VIEW IF EXISTS `v_accountmaxemails`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_accountmaxemails` AS select `v_accountallemails`.`parent_module_uname` AS `parent_module_uname`,`v_accountallemails`.`parent_instance_id` AS `parent_instance_id`,max(`v_accountallemails`.`update_date`) AS `update_date` from `v_accountallemails` group by `v_accountallemails`.`parent_module_uname`,`v_accountallemails`.`parent_instance_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_salesoppstages`
--

/*!50001 DROP TABLE IF EXISTS `v_salesoppstages`*/;
/*!50001 DROP VIEW IF EXISTS `v_salesoppstages`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_salesoppstages` AS select `cxm_entity_instance_181`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`cxm_entity_instance_181`.`PARENT_INSTANCE_ID` AS `parentinstanceId`,`cxm_entity_instance_181`.`INSTANCE_ID` AS `instanceId`,`cxm_entity_instance_181`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`cxm_entity_instance_181`.`COMPANY_ID` AS `COMPANY_ID`,`cxm_entity_instance_181`.`OWNER` AS `owner`,`cxm_entity_instance_181`.`ACCESS` AS `access`,`cxm_entity_instance_181`.`SECURITY_LEVEL` AS `security_level`,(select `cxm_lookup`.`LVALUE` from `cxm_lookup` where ((`cxm_lookup`.`LKEY` = convert(`cxm_entity_instance_181`.`ENTITY_VALUE_1` using utf8)) and (`cxm_lookup`.`ORGANIZATION_ID` = `cxm_lookup`.`ORGANIZATION_ID`) and (`cxm_lookup`.`COMPANY_ID` = `cxm_lookup`.`COMPANY_ID`) and (`cxm_lookup`.`LTYPE` = 'OPPORTUNITY_STEPS'))) AS `opportunityStep`,`cxm_entity_instance_181`.`ENTITY_VALUE_2` AS `startDate`,`cxm_entity_instance_181`.`ENTITY_VALUE_3` AS `endDate`,if((`cxm_entity_instance_181`.`ENTITY_VALUE_4` = 0),(to_days(curdate()) - to_days(str_to_date(`cxm_entity_instance_181`.`ENTITY_VALUE_2`,'%m/%d/%Y'))),`cxm_entity_instance_181`.`ENTITY_VALUE_4`) AS `noOfDays`,(select `cxm_lookup`.`LVALUE` from `cxm_lookup` where ((`cxm_lookup`.`LKEY` = convert(`cxm_entity_instance_181`.`ENTITY_VALUE_5` using utf8)) and (`cxm_lookup`.`ORGANIZATION_ID` = `cxm_lookup`.`ORGANIZATION_ID`) and (`cxm_lookup`.`COMPANY_ID` = `cxm_lookup`.`COMPANY_ID`) and (`cxm_lookup`.`LTYPE` = 'STAGE_STATUS'))) AS `sstatus` from `cxm_entity_instance_181` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_ticketsimpletopcustbyage`
--

/*!50001 DROP TABLE IF EXISTS `v_ticketsimpletopcustbyage`*/;
/*!50001 DROP VIEW IF EXISTS `v_ticketsimpletopcustbyage`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ticketsimpletopcustbyage` AS select distinct `ticket`.`INSTANCE_ID` AS `instanceId`,`ticket`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ticket`.`OWNER` AS `owner`,`ticket`.`ACCESS` AS `access`,`ticket`.`COMPANY_ID` AS `COMPANY_ID`,`ticket`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`ticket`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,1 AS `row_number`,(to_days(now()) - to_days(`CXM_STR_TO_DATE`(`ticket`.`ORGANIZATION_ID`,`ticket`.`COMPANY_ID`,`ticket`.`ENTITY_VALUE_4`))) AS `Age`,(case `ticket`.`PARENT_MODULE_UNAME` when 'Account' then (select `acc`.`ENTITY_VALUE_2` from `cxm_entity_instance_1` `acc` where ((`acc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`acc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`acc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) when 'Contact' then (select concat(`cntc`.`ENTITY_VALUE_4`,' ',`cntc`.`ENTITY_VALUE_6`) from `cxm_entity_instance_3` `cntc` where ((`cntc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`cntc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`cntc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) else 'Unassigned' end) AS `parentName`,(case `ticket`.`PARENT_MODULE_UNAME` when 'Account' then (select convert(concat(`acc`.`ENTITY_VALUE_2`,'::',`acc`.`INSTANCE_ID`,'::Account') using utf8) from `cxm_entity_instance_1` `acc` where ((`acc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`acc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`acc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) when 'Contact' then (select convert(concat(`cntc`.`ENTITY_VALUE_4`,' ',`cntc`.`ENTITY_VALUE_6`,'::',`cntc`.`INSTANCE_ID`,'::Contact') using utf8) from `cxm_entity_instance_3` `cntc` where ((`cntc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`cntc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`cntc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) else 'Unassigned' end) AS `parentNameUrl` from `cxm_entity_instance_67` `ticket` where ((`ticket`.`ENTITY_VALUE_8` <> 'TICKET_STATUS06') and (`ticket`.`ENTITY_VALUE_8` <> 'TICKET_STATUS05')) order by (to_days(now()) - to_days(`CXM_STR_TO_DATE`(`ticket`.`ORGANIZATION_ID`,`ticket`.`COMPANY_ID`,`ticket`.`ENTITY_VALUE_4`))) desc limit 0,5 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_ticketsimpletopcustbyopencases`
--

/*!50001 DROP TABLE IF EXISTS `v_ticketsimpletopcustbyopencases`*/;
/*!50001 DROP VIEW IF EXISTS `v_ticketsimpletopcustbyopencases`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ticketsimpletopcustbyopencases` AS select distinct `ticket`.`INSTANCE_ID` AS `instanceId`,`ticket`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ticket`.`COMPANY_ID` AS `COMPANY_ID`,`ticket`.`PARENT_MODULE_UNAME` AS `parentModuleUname`,`ticket`.`PARENT_INSTANCE_ID` AS `parentInstanceId`,1 AS `row_number`,count(`ticket`.`INSTANCE_ID`) AS `numTickets`,(case `ticket`.`PARENT_MODULE_UNAME` when 'Account' then (select `acc`.`ENTITY_VALUE_2` from `cxm_entity_instance_1` `acc` where ((`acc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`acc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`acc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) when 'Contact' then (select concat(`cntc`.`ENTITY_VALUE_4`,' ',`cntc`.`ENTITY_VALUE_6`) from `cxm_entity_instance_3` `cntc` where ((`cntc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`cntc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`cntc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) else 'Unassigned' end) AS `parentName`,(case `ticket`.`PARENT_MODULE_UNAME` when 'Account' then (select convert(concat(`acc`.`ENTITY_VALUE_2`,'::',`acc`.`INSTANCE_ID`,'::Account') using utf8) from `cxm_entity_instance_1` `acc` where ((`acc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`acc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`acc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) when 'Contact' then (select convert(concat(`cntc`.`ENTITY_VALUE_4`,' ',`cntc`.`ENTITY_VALUE_6`,'::',`cntc`.`INSTANCE_ID`,'::Contact') using utf8) from `cxm_entity_instance_3` `cntc` where ((`cntc`.`INSTANCE_ID` = `ticket`.`PARENT_INSTANCE_ID`) and (`cntc`.`ORGANIZATION_ID` = `ticket`.`ORGANIZATION_ID`) and (`cntc`.`COMPANY_ID` = `ticket`.`COMPANY_ID`))) else 'Unassigned' end) AS `parentNameUrl`,`ticket`.`OWNER` AS `owner`,`ticket`.`ACCESS` AS `access` from `cxm_entity_instance_67` `ticket` where ((`ticket`.`ENTITY_VALUE_8` <> 'TICKET_STATUS06') and (`ticket`.`ENTITY_VALUE_8` <> 'TICKET_STATUS05')) group by `ticket`.`PARENT_MODULE_UNAME`,`ticket`.`PARENT_INSTANCE_ID` order by count(`ticket`.`INSTANCE_ID`) desc limit 0,5 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_campaignanalysiswinloss`
--

/*!50001 DROP TABLE IF EXISTS `v_campaignanalysiswinloss`*/;
/*!50001 DROP VIEW IF EXISTS `v_campaignanalysiswinloss`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_campaignanalysiswinloss` AS select `campaign`.`INSTANCE_ID` AS `instanceId`,`campaign`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`campaign`.`COMPANY_ID` AS `COMPANY_ID`,'1' AS `PARENT_INSTANCE_ID`,'CampaignAnalysis' AS `PARENT_MODULE_UNAME`,`campaign`.`ENTITY_VALUE_1` AS `CampaignName`,sum(if((`sales`.`ENTITY_VALUE_6` = 'OPPORTUNITY2'),1,0)) AS `Win`,sum(if((`sales`.`ENTITY_VALUE_6` = 'OPPORTUNITY3'),1,0)) AS `Loss`,`campaign`.`OWNER` AS `owner`,`campaign`.`ACCESS` AS `access`,`campaign`.`SECURITY_LEVEL` AS `security_level` from (`cxm_entity_instance_52` `campaign` left join `cxm_entity_instance_2` `sales` on((`sales`.`ENTITY_VALUE_19` = `campaign`.`INSTANCE_ID`))) group by `campaign`.`INSTANCE_ID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_user_list`
--

/*!50001 DROP TABLE IF EXISTS `v_user_list`*/;
/*!50001 DROP VIEW IF EXISTS `v_user_list`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_list` AS select `u`.`ORGANIZATION_ID` AS `organization_id`,`u`.`COMPANY_ID` AS `company_id`,`u`.`USER_ID` AS `USER_ID`,`u`.`FIRST_NAME` AS `FIRST_NAME`,`u`.`LAST_NAME` AS `last_name`,`u`.`USER_UNAME` AS `USER_UNAME` from `cxm_user` `u` where (`u`.`STATUS` = 'A') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_contactmaxemails`
--

/*!50001 DROP TABLE IF EXISTS `v_contactmaxemails`*/;
/*!50001 DROP VIEW IF EXISTS `v_contactmaxemails`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_contactmaxemails` AS select `v_contactallemails`.`parent_module_uname` AS `parent_module_uname`,`v_contactallemails`.`parent_instance_id` AS `parent_instance_id`,max(`v_contactallemails`.`update_date`) AS `update_date` from `v_contactallemails` group by `v_contactallemails`.`parent_module_uname`,`v_contactallemails`.`parent_instance_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_contactallcompletedactivity`
--

/*!50001 DROP TABLE IF EXISTS `v_contactallcompletedactivity`*/;
/*!50001 DROP VIEW IF EXISTS `v_contactallcompletedactivity`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_contactallcompletedactivity` AS select `ac`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ac`.`COMPANY_ID` AS `COMPANY_ID`,`ac`.`activityModName` AS `activityModName`,`ac`.`activityModId` AS `activityModId`,`ac`.`update_date` AS `update_date`,`ac`.`activity_type` AS `activity_type`,`ac`.`activityModId` AS `parent_instance_id`,`ac`.`activityModName` AS `parent_module_uname` from `v_allcompletedactivity` `ac` where (`ac`.`activityModName` = 'Contact') union select `ac`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`ac`.`COMPANY_ID` AS `COMPANY_ID`,`ac`.`activityModName` AS `activityModName`,`ac`.`activityModId` AS `activityModId`,`ac`.`update_date` AS `update_date`,`ac`.`activity_type` AS `activity_type`,`s`.`PARENT_INSTANCE_ID` AS `parent_instance_id`,`s`.`PARENT_MODULE_UNAME` AS `parent_module_uname` from (`v_allcompletedactivity` `ac` join `cxm_entity_instance_2` `s` on(((`ac`.`activityModId` = `s`.`INSTANCE_ID`) and (`ac`.`activityModName` = 'Sales') and (`s`.`PARENT_MODULE_UNAME` = 'Contact')))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_allactions`
--

/*!50001 DROP TABLE IF EXISTS `v_allactions`*/;
/*!50001 DROP VIEW IF EXISTS `v_allactions`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_allactions` AS select `v_allactionbytype`.`organization_id` AS `organization_id`,`v_allactionbytype`.`company_id` AS `company_id`,`v_allactionbytype`.`parentInstanceId` AS `parentInstanceId`,`v_allactionbytype`.`last_action` AS `last_action`,`v_allactionbytype`.`last_action_type` AS `last_action_type`,`v_allactionbytype`.`detail` AS `detail`,`v_allactionbytype`.`adate` AS `adate`,`v_allactionbytype`.`owner` AS `owner`,`v_allactionbytype`.`access` AS `access`,`v_allactionbytype`.`instanceId` AS `instanceId`,`v_allactionbytype`.`moduleUname` AS `moduleUname`,`v_allactionbytype`.`parentModuleUname` AS `parentModuleUname` from `v_allactionbytype` order by `v_allactionbytype`.`adate` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_util_pageview`
--

/*!50001 DROP TABLE IF EXISTS `v_util_pageview`*/;
/*!50001 DROP VIEW IF EXISTS `v_util_pageview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_util_pageview` AS select `cxm_module`.`TREEVIEW_NAME` AS `pageview_uname` from `cxm_module` union select `cxm_module`.`QUICK_SEARCH_TREEVIEW_NAME` AS `pageview_uname` from `cxm_module` union select `cxm_module`.`DEFAULT_PAGE_VIEW` AS `pageview_uname` from `cxm_module` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_salesopp_list`
--

/*!50001 DROP TABLE IF EXISTS `v_salesopp_list`*/;
/*!50001 DROP VIEW IF EXISTS `v_salesopp_list`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_salesopp_list` AS select distinct `salesoppurtunity`.`INSTANCE_ID` AS `INSTANCE_ID`,`salesoppurtunity`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`salesoppurtunity`.`COMPANY_ID` AS `COMPANY_ID`,`salesoppurtunity`.`PARENT_MODULE_UNAME` AS `PARENT_MODULE_UNAME`,`salesoppurtunity`.`PARENT_INSTANCE_ID` AS `PARENT_INSTANCE_ID`,`salesoppurtunity`.`ENTITY_VALUE_1` AS `oppName`,if((`salesoppurtunity`.`PARENT_MODULE_UNAME` = 'Account'),`salesoppurtunity`.`PARENT_INSTANCE_ID`,0) AS `Account`,if((`salesoppurtunity`.`PARENT_MODULE_UNAME` = 'Contact'),`salesoppurtunity`.`PARENT_INSTANCE_ID`,0) AS `contact`,`salesoppurtunity`.`ENTITY_VALUE_13` AS `closeamount`,`salesoppurtunity`.`ENTITY_VALUE_10` AS `EstAmount`,`salesoppurtunity`.`ENTITY_VALUE_12` AS `closedate`,`salesoppurtunity`.`ENTITY_VALUE_9` AS `EstCloseDate`,`salesoppurtunity`.`ENTITY_VALUE_5` AS `DateCreated`,`salesoppurtunity`.`ENTITY_VALUE_6` AS `opportunityStatus`,`salesoppurtunity`.`ENTITY_VALUE_17` AS `opptype`,`salesoppurtunity`.`ENTITY_VALUE_16` AS `SalesStage`,`salesoppurtunity`.`ENTITY_VALUE_15` AS `LeadStage`,`salesoppurtunity`.`ENTITY_VALUE_7` AS `EstProb`,`salesoppurtunity`.`ENTITY_VALUE_4` AS `region`,`salesoppurtunity`.`ENTITY_VALUE_18` AS `lsource`,`salesoppurtunity`.`ENTITY_VALUE_19` AS `campaign`,`salesoppurtunity`.`ENTITY_VALUE_22` AS `SO_No`,`salesoppurtunity`.`ENTITY_VALUE_24` AS `primcontact`,`salesoppurtunity`.`OWNER` AS `owner`,`salesoppurtunity`.`ACCESS` AS `access`,`comm`.`ENTITY_VALUE_1` AS `SalesPersonID`,`comm`.`ENTITY_VALUE_7` AS `ManagerId` from (`cxm_entity_instance_2` `salesoppurtunity` left join `cxm_entity_instance_165` `comm` on(((`comm`.`ORGANIZATION_ID` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`comm`.`COMPANY_ID` = `salesoppurtunity`.`COMPANY_ID`) and (`comm`.`PARENT_MODULE_UNAME` = 'Sales') and (`comm`.`PARENT_INSTANCE_ID` = `salesoppurtunity`.`INSTANCE_ID`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_history_email`
--

/*!50001 DROP TABLE IF EXISTS `v_history_email`*/;
/*!50001 DROP VIEW IF EXISTS `v_history_email`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_history_email` AS select `a`.`SUBJECT` AS `subject`,date_format(`a`.`SENT_DATA_TIME`,'%m/%d/%Y') AS `sdate`,`a`.`EMAIL_NAME` AS `email_name`,`a`.`EMAIL_ID` AS `instanceId`,`b`.`ENTITY_TYPE` AS `parentModuleUname`,`b`.`ENTITY_ID` AS `parentInstanceId`,`a`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`a`.`COMPANY_ID` AS `COMPANY_ID`,`a`.`OWNER` AS `owner`,`a`.`ACCESS` AS `access`,`a`.`SECURITY_LEVEL` AS `security_level` from (`cxm_email` `a` join `cxm_email_entity` `b`) where (`a`.`EMAIL_ID` = `b`.`EMAIL_ID`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_rpt_salesopp`
--

/*!50001 DROP TABLE IF EXISTS `v_rpt_salesopp`*/;
/*!50001 DROP VIEW IF EXISTS `v_rpt_salesopp`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_rpt_salesopp` AS select `salesoppurtunity`.`INSTANCE_ID` AS `INSTANCE_ID`,`salesoppurtunity`.`ORGANIZATION_ID` AS `ORGANIZATION_ID`,`salesoppurtunity`.`COMPANY_ID` AS `COMPANY_ID`,`salesoppurtunity`.`PARENT_MODULE_UNAME` AS `PARENT_MODULE_UNAME`,`salesoppurtunity`.`PARENT_INSTANCE_ID` AS `PARENT_INSTANCE_ID`,`salesoppurtunity`.`ENTITY_VALUE_1` AS `oppName`,`salesoppurtunity`.`ENTITY_VALUE_5` AS `oppDate`,`salesoppurtunity`.`ENTITY_VALUE_7` AS `probability`,`salesoppurtunity`.`ENTITY_VALUE_9` AS `potClose`,`salesoppurtunity`.`ENTITY_VALUE_10` AS `amountpot`,`salesoppurtunity`.`ENTITY_VALUE_81` AS `notes`,(select `cxm_lookup`.`LVALUE` from `cxm_lookup` where ((`cxm_lookup`.`LKEY` = `salesoppurtunity`.`ENTITY_VALUE_15`) and (`cxm_lookup`.`ORGANIZATION_ID` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`cxm_lookup`.`COMPANY_ID` = `salesoppurtunity`.`COMPANY_ID`) and (`cxm_lookup`.`LTYPE` = 'LEAD_STAGE'))) AS `leadstage`,(select `cxm_lookup`.`LVALUE` from `cxm_lookup` where ((`cxm_lookup`.`LKEY` = `salesoppurtunity`.`ENTITY_VALUE_18`) and (`cxm_lookup`.`ORGANIZATION_ID` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`cxm_lookup`.`COMPANY_ID` = `salesoppurtunity`.`COMPANY_ID`) and (`cxm_lookup`.`LTYPE` = 'LEAD_SOURCE'))) AS `leadsource`,(select `cxm_lookup`.`LVALUE` from `cxm_lookup` where ((`cxm_lookup`.`LKEY` = `salesoppurtunity`.`ENTITY_VALUE_51`) and (`cxm_lookup`.`ORGANIZATION_ID` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`cxm_lookup`.`COMPANY_ID` = `salesoppurtunity`.`COMPANY_ID`) and (`cxm_lookup`.`LTYPE` = 'STAGE_STATUS'))) AS `salestage`,(select `cxm_lookup`.`LVALUE` from `cxm_lookup` where ((`cxm_lookup`.`LKEY` = `salesoppurtunity`.`ENTITY_VALUE_73`) and (`cxm_lookup`.`ORGANIZATION_ID` = `salesoppurtunity`.`ORGANIZATION_ID`) and (`cxm_lookup`.`COMPANY_ID` = `salesoppurtunity`.`COMPANY_ID`) and (`cxm_lookup`.`LTYPE` = 'PROD_TYPE'))) AS `prodType`,`acc`.`ENTITY_VALUE_2` AS `accName`,`salesoppurtunity`.`ENTITY_VALUE_23` AS `salesperson`,`salesname`.`FIRST_NAME` AS `safname`,`salesname`.`LAST_NAME` AS `salname`,`salesoppurtunity`.`ENTITY_VALUE_24` AS `contact`,`salesoppurtunity`.`ENTITY_VALUE_3` AS `primary2contact`,`contname`.`ENTITY_VALUE_4` AS `cofname`,`contname`.`ENTITY_VALUE_6` AS `colname`,`contname`.`ENTITY_VALUE_11` AS `phonenum`,`contname`.`ENTITY_VALUE_24` AS `email` from (((`cxm_entity_instance_2` `salesoppurtunity` left join `cxm_entity_instance_1` `acc` on((`acc`.`INSTANCE_ID` = `salesoppurtunity`.`PARENT_INSTANCE_ID`))) left join `cxm_user` `salesname` on((`salesname`.`USER_ID` = `salesoppurtunity`.`ENTITY_VALUE_23`))) left join `cxm_entity_instance_3` `contname` on((`contname`.`INSTANCE_ID` = `salesoppurtunity`.`ENTITY_VALUE_3`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_accountlastemail`
--

/*!50001 DROP TABLE IF EXISTS `v_accountlastemail`*/;
/*!50001 DROP VIEW IF EXISTS `v_accountlastemail`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`cxm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_accountlastemail` AS select `v_a`.`last_action` AS `last_action`,'Email' AS `last_action_type`,`v_m`.`parent_module_uname` AS `parentModuleUname`,`v_m`.`parent_instance_id` AS `parentInstanceId` from (`v_accountallemails` `v_a` join `v_accountmaxemails` `v_m` on(((`v_a`.`update_date` = `v_m`.`update_date`) and (`v_a`.`parent_instance_id` = `v_m`.`parent_instance_id`) and (`v_a`.`parent_module_uname` = `v_m`.`parent_module_uname`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:19
