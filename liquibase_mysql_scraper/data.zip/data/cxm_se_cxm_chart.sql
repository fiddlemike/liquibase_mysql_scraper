-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_chart`
--

LOCK TABLES `cxm_chart` WRITE;
/*!40000 ALTER TABLE `cxm_chart` DISABLE KEYS */;
INSERT INTO `cxm_chart` VALUES (1,1,'acctBarChart','',NULL,'','','\0','','','Chris',NULL,NULL,NULL,NULL),(1,1,'chart1','Potential Value',NULL,'','','\0','\0','','Chris',NULL,NULL,NULL,NULL),(1,1,'chart1line','Actual vs Budget',NULL,'','','\0','\0','','Chris',NULL,NULL,NULL,NULL),(1,1,'chart2','Sales Potential Value',NULL,'','','\0','','','Chris',NULL,NULL,NULL,NULL),(1,1,'chart3','Sales Actual Value',NULL,'','','\0','\0','','Chris',NULL,NULL,NULL,NULL),(1,1,'chart4','Potential vs Actual',NULL,'','','\0','\0','','Chris',NULL,NULL,NULL,NULL),(1,1,'chart5','Win vs Loss',NULL,'','','\0','','','Chris',NULL,NULL,NULL,NULL),(1,1,'chart6','ROI',NULL,'','','\0','','','Chris',NULL,NULL,NULL,NULL),(1,1,'prodTypeBarChart','',NULL,'','','\0','','','Chris',NULL,NULL,NULL,NULL),(1,1,'salesSalesStagePieChart','Sales Stage Ratio',NULL,'','','\0','\0','','Chris',NULL,NULL,NULL,NULL),(1,1,'salesWonLossPieChart','Win/Loss Ratio',NULL,'','','\0','\0','','Chris',NULL,NULL,NULL,NULL),(1,1,'sd2potbarchart','Potential Opportunity by Stage',NULL,'','','\0','','','Chris',NULL,NULL,NULL,NULL),(1,1,'sdbarchart','Projected vs Actual',NULL,'','','\0','','','Chris',NULL,NULL,NULL,NULL),(1,1,'sdpiechart','Sales Actual',NULL,'','','\0','\0','','Chris',NULL,NULL,NULL,NULL),(1,1,'ticketSimpleStatusBarChart','Open Cases by Status',NULL,'\0','','\0','','','Chris',NULL,NULL,NULL,NULL),(1,1,'ticketSimpleUrgencyBarChart','Open Cases by Priority',NULL,'\0','','\0','','','Chris',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `cxm_chart` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:08
