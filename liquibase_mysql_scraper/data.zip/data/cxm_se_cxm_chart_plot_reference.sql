-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_chart_plot_reference`
--

LOCK TABLES `cxm_chart_plot_reference` WRITE;
/*!40000 ALTER TABLE `cxm_chart_plot_reference` DISABLE KEYS */;
INSERT INTO `cxm_chart_plot_reference` VALUES (1,1,'acctBarChart','acctBarPlot',NULL,NULL,NULL,NULL),(1,1,'chart1','plot1',NULL,NULL,NULL,NULL),(1,1,'chart1line','plot1line',NULL,NULL,NULL,NULL),(1,1,'chart2','plot2',NULL,NULL,NULL,NULL),(1,1,'chart3','plot3',NULL,NULL,NULL,NULL),(1,1,'chart4','plot4',NULL,NULL,NULL,NULL),(1,1,'chart5','plot5',NULL,NULL,NULL,NULL),(1,1,'chart6','plot6',NULL,NULL,NULL,NULL),(1,1,'prodTypeBarChart','prodTypeBarPlot',NULL,NULL,NULL,NULL),(1,1,'salesSalesStagePieChart','salesSalesStagePlot',NULL,NULL,NULL,NULL),(1,1,'salesWonLossPieChart','salesWonLossPie',NULL,NULL,NULL,NULL),(1,1,'sd2potbarchart','sd2potbarplot',NULL,NULL,NULL,NULL),(1,1,'sdbarchart','sdbarplot',NULL,NULL,NULL,NULL),(1,1,'sdpiechart','sdpieplot',NULL,NULL,NULL,NULL),(1,1,'ticketSimpleStatusBarChart','ticketSimpleStatusBarPlot',NULL,NULL,NULL,NULL),(1,1,'ticketSimpleUrgencyBarChart','ticketSimpleUrgencyBarPlot',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `cxm_chart_plot_reference` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:06
