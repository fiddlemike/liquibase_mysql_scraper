-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_abl`
--

LOCK TABLES `cxm_abl` WRITE;
/*!40000 ALTER TABLE `cxm_abl` DISABLE KEYS */;
INSERT INTO `cxm_abl` VALUES (1,1,'1BusinessDayPriorSendAutomatedEmailToParticipants','1BusinessDayPriorSendAutomatedEmailToParticipants',NULL,'ET_SALES','1 business day prior: Send automated email to participants.',NULL,'',NULL,'\0','\0','\0','2014-09-26 06:00:02','\0',14,NULL,'SuperAdmin','public',NULL,'SuperAdmin','2014-09-29 14:24:38','SuperAdmin','2014-01-22 03:54:31','SuperAdmin','2015-02-27 23:55:09'),(1,1,'Call1Completed','Call1Completed',NULL,'ET_SALES','When Activity of type Lead Cold Call and subtype of Call 1 completed, created Call 2',NULL,'\0',NULL,'\0','','\0','2014-09-26 09:49:54','\0',0,NULL,'SuperAdmin','public',NULL,'SuperAdmin','2014-12-29 14:43:09','SuperAdmin','2014-04-01 09:26:44','SuperAdmin','2014-12-29 14:43:09'),(1,1,'CreateTicketFromIncomingEmail','CreateTicketFromIncomingEmail',NULL,'ET_SRVC','Create a Ticket when an Incoming Email is received',NULL,'\0',NULL,'','\0','\0',NULL,'',0,NULL,'SuperAdmin','public',NULL,NULL,NULL,'SuperAdmin','2014-02-10 16:03:38','SuperAdmin','2015-04-24 16:33:24'),(1,1,'IfActivityIsDeletedOrCancelled','IfActivityIsDeletedOrCancelled',NULL,'ET_SALES','If activity is deleted or canceled on the same day send notification to CXM users. Also on the same day send automated email to CXM users to confirm that the activity was canceled. Confirmation should include original date/time',NULL,'\0',NULL,'\0','\0','','2014-04-28 10:36:29','\0',0,NULL,'SuperAdmin','public',NULL,NULL,NULL,'SuperAdmin','2014-01-22 04:11:15','SuperAdmin','2014-05-20 16:31:17'),(1,1,'IFActivityIsRescheduled','IFActivityIsRescheduled',NULL,'ET_SALES','IF activity is rescheduled - Same day send automated email Reminder for scheduled demo.',NULL,'\0',NULL,'\0','','\0','2014-04-09 13:57:21','\0',0,NULL,'SuperAdmin','public',NULL,'SuperAdmin','2014-04-28 10:27:56','SuperAdmin','2014-01-22 04:06:47','SuperAdmin','2014-06-24 15:09:52'),(1,1,'Lead6DayNotification','Lead6DayNotification',NULL,'ET_MRKT','lead has not been made into a SO/Account/Contact after 6 days',NULL,'',NULL,'\0','\0','\0','2014-09-25 07:01:02','\0',31,NULL,'SuperAdmin','public',NULL,NULL,NULL,'SuperAdmin','2013-12-12 10:06:21','SuperAdmin','2014-09-26 06:59:59'),(1,1,'NewLeadAssigned','NewLeadAssigned',NULL,'ET_MRKT','New Lead is Assigned to the Account Manager',NULL,'\0',NULL,'\0','','\0','2014-09-24 14:32:01','\0',0,NULL,'SuperAdmin','public',NULL,'SuperAdmin','2014-10-14 07:46:57','SuperAdmin','2014-09-12 13:16:46','SuperAdmin','2014-10-14 07:46:57'),(1,1,'NewLeadCreated','NewLeadCreated',NULL,'ET_MRKT','NewLeadCreated',NULL,'\0',NULL,'','\0','\0','2015-05-06 16:23:18','',0,NULL,'SuperAdmin','public',NULL,NULL,NULL,'SuperAdmin','2014-01-14 23:41:21','SuperAdmin','2015-05-06 16:23:18'),(1,1,'OnLeadRejectedReassigned','OnLeadRejectedReassigned',NULL,'ET_MRKT','OnLeadRejectedReassigned',NULL,'\0',NULL,'\0','','\0','2014-09-26 08:25:06','\0',0,NULL,'SuperAdmin','public',NULL,'SuperAdmin','2014-05-22 11:36:09','SuperAdmin','2014-05-14 14:28:01','SuperAdmin','2014-09-26 08:25:06'),(1,1,'WhenADemoIsScheduled','WhenADemoIsScheduled',NULL,'ET_SALES','When an activity is created on CXM calendar (Activity Type = Sales, Sub-Type = Demo) Sent Email to all participants.',NULL,'\0',NULL,'','\0','\0','2014-09-22 06:58:29','\0',0,NULL,'SuperAdmin','public',NULL,'tfryer','2014-03-18 02:32:05','SuperAdmin','2014-01-22 02:53:03','SuperAdmin','2014-09-22 06:58:29'),(1,1,'WhenTicketAssignedIndividual','WhenTicketAssignedIndividual',NULL,'ET_SRVC','WhenTicketAssignedIndividual not synergy',NULL,'\0',NULL,'','','\0',NULL,'\0',0,NULL,'SuperAdmin','public',NULL,NULL,NULL,'SuperAdmin','2014-08-26 14:51:36','SuperAdmin','2014-08-28 12:02:35'),(1,1,'WhenTicketAssignedSynergy','WhenTicketAssignedSynergy',NULL,'ET_SRVC','WhenTicketAssignedSynergy',NULL,'\0',NULL,'','','\0',NULL,'\0',0,NULL,'SuperAdmin','public',NULL,NULL,NULL,'SuperAdmin','2014-08-26 14:54:04','SuperAdmin','2014-08-27 12:31:24'),(1,1,'WhenTicketClosed','WhenTicketClosed',NULL,'ET_SRVC','WhenTicketClosed',NULL,'\0',NULL,'\0','','\0',NULL,'',0,NULL,'SuperAdmin','public',NULL,NULL,NULL,'SuperAdmin','2014-08-26 13:30:03','SuperAdmin','2015-05-14 19:57:28'),(1,1,'WhenTicketNew','WhenTicketNew',NULL,'ET_SRVC','WhenTicketNew',NULL,'\0',NULL,'','\0','\0','2014-09-11 14:41:14','\0',0,NULL,'SuperAdmin','public',NULL,'SuperAdmin','2014-08-28 12:02:44','SuperAdmin','2014-08-27 11:02:48','SuperAdmin','2014-09-11 14:41:14'),(1,1,'WhenTicketOnHold','WhenTicketOnHold',NULL,'ET_SRVC','WhenTicketOnHold',NULL,'\0',NULL,'\0','','\0',NULL,'\0',0,NULL,'SuperAdmin','public',NULL,NULL,NULL,'SuperAdmin','2014-08-26 13:31:31','SuperAdmin','2014-08-28 12:20:11');
/*!40000 ALTER TABLE `cxm_abl` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:13
