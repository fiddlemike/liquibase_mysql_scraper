-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_user`
--

LOCK TABLES `cxm_user` WRITE;
/*!40000 ALTER TABLE `cxm_user` DISABLE KEYS */;
INSERT INTO `cxm_user` VALUES (1,1,1,'SuperAdmin','CHuUe8/4JqXwJoqM90Hi0Q==','','2012-12-07','',NULL,'public','Clark','','Kent','admin12@creedenz.com','MOBILE_DESKTOP','smtp','208.43.76.146','587','creedenz','5RrkIy8rjBXAadWuw7xruQ==','NSM_Window','A','\0',NULL,'2013-10-09 00:00:00','2013-10-16 01:37:34','\0','SuperAdmin','2015-03-26 14:04:40','SuperAdmin','2012-12-07 10:14:26','SuperAdmin','2015-05-12 12:49:30'),(2,1,1,'ot1','CHuUe8/4JqXwJoqM90Hi0Q==','','2012-12-07','',NULL,'public','Ot','','One','ot1@creedenz.com','DESKTOP','smtp','smtp.sendgrid.net','587','admin12','5RrkIy8rjBWtvwisbW1UuA==','NSM_Window','A','\0',NULL,'2013-10-09 00:00:00','2013-10-11 01:37:28','\0','SuperAdmin','2013-10-17 13:49:16','SuperAdmin','2012-12-07 10:14:26','SuperAdmin','2014-06-04 17:13:43'),(3,1,1,'awebb','CHuUe8/4JqXwJoqM90Hi0Q==','','2013-07-30','DT_EXEC',NULL,'public','Allen','M','Webb','awebb@cxmcrm.com','DESKTOP','smtp','','','','','NSM_Window','A','\0',NULL,'2014-11-11 00:00:00','2014-11-16 01:37:29','\0','awebb','2015-05-12 09:17:43',NULL,'2013-07-30 11:47:38','awebb','2015-05-12 12:48:49'),(4,1,1,'dstephen','M2FHJnXxze0m6AOQ9Xu9cA==','3','2013-07-30','DT_SALES',NULL,'public','Dessie','K','Stephen','dstephen@cxmcrm.com','','smtp','smtp.sendgrid.net','587','creedenz','5RrkIy8rjBWtvwisbW1UuA==','NSM_Window','A','\0',NULL,'2013-08-08 00:00:00','2013-08-09 01:37:33','\0','SuperAdmin','2013-08-16 11:38:18',NULL,'2013-07-30 11:57:43','SuperAdmin','2014-04-26 10:46:35'),(5,1,1,'bsampson','jCkupy4hA95sN2eW14dvjA==','3','2013-07-30','DT_SALES',NULL,'public','Brock','','Sampson','bsampson@cxmcrm.com','','smtp','','','','','','A','\0','20','2013-08-08 00:00:00','2013-08-10 01:37:36','\0','SuperAdmin','2014-04-25 10:05:42',NULL,'2013-07-30 11:58:56','SuperAdmin','2014-04-25 10:05:42'),(6,1,1,'jsmith','EF4XxVTLzNw=','3','2013-07-30','DT_SALES',NULL,'public','Justin','T','Smith','ot1@creedenz.com','DESKTOP','smtp','smtp.sendgrid.net','587','creedenz','5RrkIy8rjBWtvwisbW1UuA==','NSM_Window','A','\0',NULL,'2013-08-08 00:00:00','2013-08-15 01:37:34','\0',NULL,NULL,NULL,'2013-07-30 11:59:50','SuperAdmin','2015-03-26 14:22:42'),(7,1,1,'jcarter','pevtf0+xTSY=','3','2013-07-30','DT_SALES',NULL,'public','John','','Carter','jcarter@cxmcrm.com','DESKTOP','smtp','','','','','NSM_All','A','\0',NULL,'2013-08-08 00:00:00','2013-08-12 01:37:34','\0',NULL,NULL,NULL,'2013-07-30 12:00:56','SuperAdmin','2015-03-26 14:26:41'),(9,1,1,'CXMAdmin','yGpe/fSJfM8iigJB9BgmrQ==','','2014-09-27','DT_EXEC',NULL,'public','CXM','','Admin','admin12@creedenz.com','DESKTOP','smtp','','','','','NSM_Window','A','\0',NULL,'2015-03-26 00:00:00','2015-03-27 01:37:34','\0','SuperAdmin','2015-04-12 17:28:34',NULL,'2014-09-27 10:33:51','SuperAdmin','2015-04-12 17:28:34'),(10,1,1,'cward','CHuUe8/4JqXwJoqM90Hi0Q==','','2013-07-30','DT_CS',NULL,'public','Cory','V','Ward','cward@cxmcrm.com','DESKTOP','smtp','','','','','NSM_Window','A','\0',NULL,'2013-08-08 00:00:00','2013-08-14 01:37:29','\0',NULL,NULL,NULL,'2013-07-30 12:31:51','SuperAdmin','2015-05-12 09:10:49'),(11,1,1,'glopes','1AUMAEA/KwE=','10','2013-07-30','DT_CS',NULL,'public','Glen','H','Lopes','glopes@cxmcrm.com',NULL,'smtp','','','','','','A','\0',NULL,'2013-10-28 00:00:00','2013-10-29 01:37:31',NULL,NULL,NULL,NULL,'2013-07-30 12:32:35','SuperAdmin','2013-10-28 11:26:06'),(12,1,1,'sjoseph','WDczQY03M4k=','10','2013-07-30','DT_CS',NULL,'public','Sylvia','','Joseph','sjoseph@cxmcrm.com','DESKTOP','smtp','','','','','NSM_Window','A','\0',NULL,'2013-10-28 00:00:00','2013-10-30 01:37:34','\0',NULL,NULL,NULL,'2013-07-30 12:33:39','SuperAdmin','2015-03-26 14:23:37'),(13,1,1,'kajal','HfGVTk0V1q0=','','2015-04-27','',NULL,'public','kajal','','','kaajl@gmail.com','DESKTOP','smtp','','','','','NSM_Window','D','\0',NULL,NULL,NULL,'\0',NULL,NULL,NULL,'2015-04-27 15:15:50',NULL,'2015-04-27 15:16:03');
/*!40000 ALTER TABLE `cxm_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:09
