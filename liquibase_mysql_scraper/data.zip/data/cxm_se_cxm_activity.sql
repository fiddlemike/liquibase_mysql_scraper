-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_activity`
--

LOCK TABLES `cxm_activity` WRITE;
/*!40000 ALTER TABLE `cxm_activity` DISABLE KEYS */;
INSERT INTO `cxm_activity` VALUES (1,1,1,'testing Leads','AT_PERSONAL','','','2015-04-20 15:13:00','2015-04-03 14:43:00','ACT_STATUS_PENDING','PRIOR_LOW','','','My Calendar','',NULL,'RS1_ONHOLD','','','Testing of activity from Leads','SuperAdmin','public',NULL,NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-03 14:44:45','SuperAdmin','2015-04-03 14:44:45','SuperAdmin','2015-04-03 14:44:45',' ','','2::Leads',NULL),(2,1,1,'testing Contacts','AT_PERSONAL','','Testing of activity from contacts','2015-04-20 15:20:00','2015-04-03 14:50:00','ACT_STATUS_PENDING','PRIOR_LOW','','','My Calendar','',NULL,'','','','Testing of activity from contacts','SuperAdmin','public',NULL,NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-03 14:51:19','SuperAdmin','2015-04-03 14:50:54','SuperAdmin','2015-04-03 14:51:19','Kajal Agarwal-Creedenz','','1::Contact',NULL),(3,1,1,'testing Account','AT_PERSONAL','','Testing of activity from Account','2015-04-13 15:25:00','2015-04-03 14:55:00','ACT_STATUS_PENDING','PRIOR_LOW','','','My Calendar','',NULL,'','','','Testing of activity from Account','SuperAdmin','public',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-03 14:55:53','SuperAdmin','2015-04-03 14:55:53',NULL,NULL,'::Contact',NULL),(4,1,1,'Test1 ','AT_SALES','','','2015-04-10 01:21:00','2015-04-10 00:51:00','ACT_STATUS_PENDING','PRIOR_LOW','','','','\0',NULL,'RS1_NOTINTER','','','','awebb','public',NULL,NULL,NULL,NULL,NULL,'awebb','2015-04-10 00:49:26','awebb','2015-04-10 00:49:25','awebb','2015-04-10 00:49:26','Kajal Agarwal-Creedenz','4675637894','1::Contact',NULL),(6,1,1,'Phone Call','AT_CALLOUT','AT2_COLD',NULL,'2015-04-21 13:47:23','2015-04-21 13:17:23','ACT_STATUS_PENDING','PRIOR_MEDIUM',NULL,NULL,'','\0',NULL,NULL,NULL,NULL,'test2','SuperAdmin','public',NULL,0,NULL,NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-21 13:17:23','SuperAdmin','2015-04-21 13:17:23',NULL,NULL,NULL,NULL),(7,1,1,'Phone Call','AT_CALLOUT','AT2_COLD',NULL,'2015-04-24 16:36:27','2015-04-24 16:06:27','ACT_STATUS_COMPLETED','PRIOR_MEDIUM',NULL,NULL,'','\0',NULL,NULL,NULL,NULL,'this is a test phone call','SuperAdmin','public',NULL,0,NULL,NULL,NULL,NULL,NULL,'SuperAdmin','2015-04-24 16:06:27','SuperAdmin','2015-04-24 16:06:27',NULL,NULL,NULL,NULL),(8,1,1,'Test Activity','AT_SALES','','Test Activity Description Ticket','2015-05-03 13:42:00','2015-05-03 13:12:00','ACT_STATUS_ONHOLD','PRIOR_LOW','','','','\0',NULL,'','','','Test Activity Notes','SuperAdmin','public',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'SuperAdmin','2015-05-03 00:39:51','SuperAdmin','2015-05-03 09:16:01',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `cxm_activity` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:15
