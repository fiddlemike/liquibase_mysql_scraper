-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.110    Database: cxm_se
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cxm_context_parameter`
--

LOCK TABLES `cxm_context_parameter` WRITE;
/*!40000 ALTER TABLE `cxm_context_parameter` DISABLE KEYS */;
INSERT INTO `cxm_context_parameter` VALUES (1,1,'EMAIL_RULE','EmailTest',1,'incomingEmail','host','216.35.196.47',NULL,'2013-12-26 08:49:18',NULL,'2013-12-26 08:49:18'),(1,1,'EMAIL_RULE','EmailTest',2,'incomingEmail','port','110',NULL,'2013-12-26 08:49:18',NULL,'2013-12-26 08:49:18'),(1,1,'EMAIL_RULE','EmailTest',3,'incomingEmail','protocol','POP3',NULL,'2013-12-26 08:49:18',NULL,'2013-12-26 08:49:18'),(1,1,'EMAIL_RULE','EmailTest',4,'incomingEmail','username','demo.user2@creedenz.com',NULL,'2013-12-26 08:49:19',NULL,'2013-12-26 08:49:19'),(1,1,'EMAIL_RULE','EmailTest',5,'incomingEmail','password','QwOlJuCTbUrG5Qkrq4YhsQ==',NULL,'2013-12-26 08:49:19',NULL,'2013-12-26 08:49:19'),(1,1,'EMAIL_RULE','GetEmailTest',1,'incomingEmail','KEYWORD_ATTRIBUTE','keywordWeight',NULL,'2014-01-02 07:39:10',NULL,'2014-01-02 07:39:10'),(1,1,'ENTITY_RULE','1BusinessDayPriorSendAutomatedEmailToParticipants',7,'activity','KEYWORD_ATTRIBUTE','none',NULL,'2014-09-12 15:04:29',NULL,'2014-09-12 15:04:29'),(1,1,'ENTITY_RULE','AccountTest',3,'Account','protocol','POP3',NULL,'2014-01-02 07:18:48',NULL,'2014-01-02 07:18:48'),(1,1,'ENTITY_RULE','AccountTest',6,'Account','isSSLEnabled','false',NULL,'2014-01-02 07:18:48',NULL,'2014-01-02 07:18:48'),(1,1,'ENTITY_RULE','Call1Completed',7,'activity','KEYWORD_ATTRIBUTE','none',NULL,'2014-09-13 16:48:03',NULL,'2014-09-13 16:48:03'),(1,1,'ENTITY_RULE','ContactTest2',3,'incomingEmail','protocol','POP3',NULL,'2013-12-27 10:26:05',NULL,'2013-12-27 10:26:05'),(1,1,'ENTITY_RULE','CreateTicketFromIncomingEmail',7,'incomingEmail','KEYWORD_ATTRIBUTE','none',NULL,'2015-04-24 16:33:24',NULL,'2015-04-24 16:33:24'),(1,1,'ENTITY_RULE','IfActivityIsDeletedOrCancelled',7,'activity','KEYWORD_ATTRIBUTE','none',NULL,'2014-04-28 10:20:45',NULL,'2014-04-28 10:20:45'),(1,1,'ENTITY_RULE','IFActivityIsRescheduled',7,'activity','KEYWORD_ATTRIBUTE','none',NULL,'2014-02-27 21:38:03',NULL,'2014-02-27 21:38:03'),(1,1,'ENTITY_RULE','Lead6DayNotification',3,'Leads','protocol','POP3',NULL,'2014-06-27 11:39:13',NULL,'2014-06-27 11:39:13'),(1,1,'ENTITY_RULE','Lead6DayNotification',7,'Leads','KEYWORD_ATTRIBUTE','none',NULL,'2014-06-27 11:39:13',NULL,'2014-06-27 11:39:13'),(1,1,'ENTITY_RULE','LeadInitNotification',3,'incomingEmail','protocol','POP3',NULL,'2013-12-12 09:51:46',NULL,'2013-12-12 09:51:46'),(1,1,'ENTITY_RULE','LeadsTestABL',3,'incomingEmail','protocol','POP3',NULL,'2013-12-09 12:53:41',NULL,'2013-12-09 12:53:41'),(1,1,'ENTITY_RULE','NewLeadAssigned',7,'Leads','KEYWORD_ATTRIBUTE','none',NULL,'2014-09-13 11:30:34',NULL,'2014-09-13 11:30:34'),(1,1,'ENTITY_RULE','NewLeadCreated',7,'Leads','KEYWORD_ATTRIBUTE','none',NULL,'2014-10-13 15:03:31',NULL,'2014-10-13 15:03:31'),(1,1,'ENTITY_RULE','OnLeadRejectedReassigned',7,'Leads','KEYWORD_ATTRIBUTE','none',NULL,'2014-05-22 11:36:09',NULL,'2014-05-22 11:36:09'),(1,1,'ENTITY_RULE','SalesOpTest',3,'incomingEmail','protocol','POP3',NULL,'2013-12-27 08:33:15',NULL,'2013-12-27 08:33:15'),(1,1,'ENTITY_RULE','WhenADemoIsScheduled',7,'activity','KEYWORD_ATTRIBUTE','none',NULL,'2014-02-28 14:58:14',NULL,'2014-02-28 14:58:14'),(1,1,'ENTITY_RULE','WhenTicketAssignedIndividual',7,'TicketSimple','KEYWORD_ATTRIBUTE','none',NULL,'2014-08-27 12:35:13',NULL,'2014-08-27 12:35:13'),(1,1,'ENTITY_RULE','WhenTicketAssignedSynergy',7,'TicketSimple','KEYWORD_ATTRIBUTE','none',NULL,'2014-08-27 12:31:24',NULL,'2014-08-27 12:31:24'),(1,1,'ENTITY_RULE','WhenTicketClosed',7,'TicketSimple','KEYWORD_ATTRIBUTE','none',NULL,'2015-05-14 19:57:28',NULL,'2015-05-14 19:57:28'),(1,1,'ENTITY_RULE','WhenTicketNew',7,'TicketSimple','KEYWORD_ATTRIBUTE','none',NULL,'2014-08-28 12:00:44',NULL,'2014-08-28 12:00:44'),(1,1,'ENTITY_RULE','WhenTicketOnHold',7,'TicketSimple','KEYWORD_ATTRIBUTE','none',NULL,'2014-08-28 12:20:11',NULL,'2014-08-28 12:20:11');
/*!40000 ALTER TABLE `cxm_context_parameter` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-24 10:32:10
